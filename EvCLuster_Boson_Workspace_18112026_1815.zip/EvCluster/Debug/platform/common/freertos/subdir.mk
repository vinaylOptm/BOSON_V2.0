################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../platform/common/freertos/freertosqueue.cpp \
../platform/common/freertos/mem-freertos-default.cpp \
../platform/common/freertos/mem-freertos.cpp \
../platform/common/freertos/mem_info.cpp 

CPP_DEPS += \
./platform/common/freertos/freertosqueue.d \
./platform/common/freertos/mem-freertos-default.d \
./platform/common/freertos/mem-freertos.d \
./platform/common/freertos/mem_info.d 

OBJS += \
./platform/common/freertos/freertosqueue.o \
./platform/common/freertos/mem-freertos-default.o \
./platform/common/freertos/mem-freertos.o \
./platform/common/freertos/mem_info.o 


# Each subdirectory must supply rules for building sources it contributes
platform/common/freertos/%.o: ../platform/common/freertos/%.cpp platform/common/freertos/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C++ Compiler'
	arm-none-eabi-c++ -std=gnu++14 -DEEPROM=0 -DNAV_MULTIFUNCTION=1 -DCPU_MIMXRT1176DVMAA -DCPU_MIMXRT1176DVMAA_cm7 -DSDK_OS_BAREMETAL -DSERIAL_PORT_TYPE_UART=1 -DSDK_DEBUGCONSOLE=1 -DSDK_OS_FREE_RTOS -D__USE_CMSIS -DDEBUG -D__NEWLIB__ -DBOARD_MIPI_PANEL_TOUCH_IRQ=GPIO2_Combined_16_31_IRQn -DBOARD_MIPI_PANEL_TOUCH_IRQ_HANDLER=GPIO2_Combined_16_31_IRQHandler -DCPP_NO_HEAP -DPRINTF_ADVANCED_ENABLE=0 -DFSL_RTOS_FREE_RTOS -DPRINTF_FLOAT_ENABLE=0 -DSCANF_ADVANCED_ENABLE=0 -DSCANF_FLOAT_ENABLE=0 -DSKIP_SYSCLK_INIT -DUSE_SDRAM -DSDK_I2C_BASED_COMPONENT_USED=1 -DXIP_BOOT_HEADER_ENABLE=1 -DXIP_EXTERNAL_FLASH=1 -DXIP_BOOT_HEADER_DCD_ENABLE=1 -DVGLITE_POINT_FILTERING_FOR_SIMPLE_SCALE -DQUL_STD_STRING_SUPPORT -DUDS_SERVICE_ENABLE=0 -DCLUSTER_HW_VERSION=2 -DCLUSTER_DISPLAY=2 -DCLUSTER_DISPLAY_INTERFACE=0 -DCLUSTER_PANEL_HEIGHT=480 -DCLUSTER_PANEL_WIDTH=800 -DENABLE_PWM_CONTROL=0 -DCLUSTER_NAVIGATION_SWITCH_ENABLE=1 -DCLUSTER_KEYIGNITION_SUPPORTED=0 -DCLUSTER_SWITCH_WAKE=1 -DVG_TARGET_FAST_CLEAR=0 -DVG_COMMAND_CALL=1 -DCUSTOM_VGLITE_MEMORY_CONFIG=0 -DDATA_SECTION_IS_CACHEABLE=1 -DUSE_RTOS=1 -DMCUXPRESSO_SDK -DMCUX_META_BUILD -DMIMXRT1176_cm7_SERIES -DOSA_USED -DCR_INTEGER_PRINTF -DFSL_SDK_DRIVER_QUICK_ACCESS_ENABLE=1 -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\board" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\source" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\component\serial_manager" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\device" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\drivers" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\component\uart" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\xip" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\utilities" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\freertos\freertos-kernel\include" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\freertos\freertos-kernel\portable\GCC\ARM_CM4F" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\CMSIS" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\video" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\startup" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\gt911" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\vglite\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\vglite\VGLite\rtos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\vglite\VGLiteKernel" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\vglite\VGLiteKernel\rtos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\cluster" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\cluster\common" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\cluster\config" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\cluster\controller\hal\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\cluster\controller\manager\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\cluster\controller\hmi\inc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\cluster\controller\plf\inc" -I"C:\Qt\QtMCUs\2.11.1\include" -I"C:\Qt\QtMCUs\2.11.1\src\3rdparty\qoi" -I"C:\Qt\QtMCUs\2.11.1\src\3rdparty\minihdlc" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\platform\common" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\platform\boards\nxp\mimxrt1170-evkb-freertos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\platform\boards\nxp\mimxrt1170-evkb-freertos\display" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\Workspace_Boson\GeneratedHmi\boson_ui" -I"C:\Qt\QtMCUs\2.11.1\src\3rdparty\nanopb" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\source" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\platform\boards\nxp\mimxrt1170-evkb-freertos" -I"D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\platform\boards\nxp" -O0 -fno-common -g1 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -ffreestanding -fno-builtin -fno-rtti -fno-exceptions -imacros "D:\Cluster_Workspace\Grav_Blinq_Liger\Boson\EvCLuster_Boson_Workspace_10112026_2011\EvCluster\source\mcux_config.h" -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m7 -mfpu=fpv5-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-platform-2f-common-2f-freertos

clean-platform-2f-common-2f-freertos:
	-$(RM) ./platform/common/freertos/freertosqueue.d ./platform/common/freertos/freertosqueue.o ./platform/common/freertos/mem-freertos-default.d ./platform/common/freertos/mem-freertos-default.o ./platform/common/freertos/mem-freertos.d ./platform/common/freertos/mem-freertos.o ./platform/common/freertos/mem_info.d ./platform/common/freertos/mem_info.o

.PHONY: clean-platform-2f-common-2f-freertos

