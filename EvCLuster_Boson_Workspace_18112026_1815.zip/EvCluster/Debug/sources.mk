################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ASM_SRCS := 
C++_SRCS := 
CC_SRCS := 
CPP_SRCS := 
CXX_SRCS := 
C_SRCS := 
C_UPPER_SRCS := 
OBJ_SRCS := 
O_SRCS := 
S_SRCS := 
S_UPPER_SRCS := 
C++_DEPS := 
CC_DEPS := 
CPP_DEPS := 
CXX_DEPS := 
C_DEPS := 
C_UPPER_DEPS := 
EXECUTABLES := 
OBJS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
board \
boson_ui \
boson_ui/resources \
cluster/controller/hal/src \
cluster/controller/hmi/src \
cluster/controller/manager/src \
cluster/controller/plf/src \
cluster/main \
component/serial_manager \
component/uart \
device \
drivers \
freertos/freertos-kernel \
freertos/freertos-kernel/portable/GCC/ARM_CM4F \
freertos/freertos-kernel/portable/MemMang \
gt911 \
nanopb \
nanopb/spm-test/objc \
platform/boards/nxp/common/freertos \
platform/boards/nxp/mimxrt1170-evkb-freertos/display \
platform/boards/nxp/mimxrt1170-evkb-freertos \
platform/common \
platform/common/freertos \
startup \
utilities \
vglite/VGLite \
vglite/VGLite/rtos \
vglite/VGLiteKernel/rtos \
vglite/VGLiteKernel \
video \
xip \

