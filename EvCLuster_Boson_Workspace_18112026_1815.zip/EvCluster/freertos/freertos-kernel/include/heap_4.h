/*
 * Copyright 2021 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef _HEAP_4_H_
#define _HEAP_4_H_

/*******************************************************************************
 * Definitions
 ******************************************************************************/

#if defined(__cplusplus)
extern "C" {
#endif /* __cplusplus */

/*******************************************************************************
 * API
 ******************************************************************************/
/*!
 * @brief BOARD SDIO configurations.
 * @param card card descriptor
 * @param cardInt card interrupt
 */
void * pvPortMalloc( size_t xWantedSize );

void vPortFree( void * pv );

#if defined(__cplusplus)
}
#endif /* __cplusplus */

#endif /* _HEAP_4_H_ */
