/*
 * Copyright 2019-2021, 2023 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "display_support.h"
#include "fsl_dc_fb_lcdifv2.h"

/*******************************************************************************
 * Function
 ******************************************************************************/
