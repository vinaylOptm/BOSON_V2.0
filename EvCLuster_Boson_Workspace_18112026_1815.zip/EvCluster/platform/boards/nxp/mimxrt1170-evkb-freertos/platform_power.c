// Copyright (C) 2024 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial
#include "platform_power.h"

// Empty for now since entering low power mode causes problems with flashing & debugging
void enterSleepMode() {}
