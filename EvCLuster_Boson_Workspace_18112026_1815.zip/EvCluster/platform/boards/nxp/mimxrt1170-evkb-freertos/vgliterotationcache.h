// Copyright (C) 2024 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial
#pragma once
#include <platforminterface/allocator.h>

namespace Qul {
namespace Platform {
namespace Private {

size_t preprocessCacheSize();

class VgliteRotationCache
{
public:
    struct Node
    {
        ~Node();

        uint16_t timestamp() const;
        vg_lite_buffer_t *buffer();

    private:
        uint64_t _timestamp;
        vg_lite_buffer_t _buffer;
    };

    bool available(const unsigned char *original);
    VgliteRotationCache::Node *get(const unsigned char *original);
    VgliteRotationCache::Node *add(const unsigned char *original, vg_lite_buffer_t *texture);
    void remove(const unsigned char *original);

private:
    void removeOldest();

    using ContainerType = PlatformInterface::Map<const unsigned char *, Node>;
    ContainerType _container;
};

} // namespace Private
} // namespace Platform
} // namespace Qul
