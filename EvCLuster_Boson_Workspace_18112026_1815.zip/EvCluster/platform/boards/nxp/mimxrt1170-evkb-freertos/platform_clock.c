// Copyright (C) 2024 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial
#include "platform_os.h"
void SysTick_Handler();

void SysTick_Handler()
{
    systick();
}

// Force linker to add this file, including SysTick_Handler, to the binary.
// When linkedn the linker finds the strong symbol and links successfully to
// our SysTick_Handler implementation.
int sys_clock_c;
