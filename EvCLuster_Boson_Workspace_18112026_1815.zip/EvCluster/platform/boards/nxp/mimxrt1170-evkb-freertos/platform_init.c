// Copyright (C) 2024 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial

int __wrap_atexit(void __attribute__((__unused__)) (*function)(void) );

// Note: wrap for atexit is only for testing purposes
// Calls for malloc are checked by wrapping malloc function
// Default implementation of atexit uses malloc so it needs to be wrapped
int __wrap_atexit(void __attribute__((__unused__)) (*function)(void) )
{
    return -1;
}
