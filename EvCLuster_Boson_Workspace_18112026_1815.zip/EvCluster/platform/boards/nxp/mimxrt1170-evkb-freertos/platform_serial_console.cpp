// Copyright (C) 2024 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial
#include "platform_serial_console.h"
#include <platform/devicelink.h>

#include "fsl_debug_console.h"

extern "C" int _write(int file, char *ptr, int len)
{
    (void) file;

    auto deviceLink = Qul::Platform::DeviceLink::instance();
    if (deviceLink) {
        deviceLink->printMessage(ptr, len);
    } else {
        for (int i = 0; i < len; i++)
            DbgConsole_Putchar(*ptr++);
    }

    return len;
}

namespace Qul {
namespace Platform {
namespace Private {

void writeChar(char &character)
{
    _write(0 /*unused*/, &character, 1);
}

} // namespace Private
} // namespace Platform
} // namespace Qul
