// Copyright (C) 2024 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial
#pragma once

#include <platform/private/fixedsizeblockallocator.h>

#include <platforminterface/memoryallocator.h>

namespace Qul {
namespace Platform {
namespace Private {

class NonCacheableAllocator : public FixedSizeBlockAllocator<16 * 1024>
{
public:
    NonCacheableAllocator();
};

PlatformInterface::MemoryAllocator *preprocessAllocator();
PlatformInterface::MemoryAllocator *memoryAllocator(PlatformInterface::MemoryAllocator::AllocationType type);
void preloadModuleResourceData();

} // namespace Private
} // namespace Platform
} // namespace Qul
