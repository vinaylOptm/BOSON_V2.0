// Copyright (C) 2024 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial
#pragma once

#include <stddef.h>
#include <utility>

namespace Qul {
namespace Platform {
namespace Private {
std::pair<char *, char *> preprocessCacheRange();
size_t preprocessCacheSize();
void cleanInvalidateDCacheByAddr(void *addr, int size);
} // namespace Private
} // namespace Platform
} // namespace Qul
