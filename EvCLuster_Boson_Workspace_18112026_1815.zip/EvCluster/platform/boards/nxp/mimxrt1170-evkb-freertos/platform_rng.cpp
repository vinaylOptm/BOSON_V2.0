// Copyright (C) 2024 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial
#include "platform_rng.h"

#include <random>

namespace Qul {
namespace Platform {
namespace Private {

static std::minstd_rand randomEngine;

double rand()
{
    return randomEngine() / (randomEngine.max() + 1.0);
}

} // namespace Private
} // namespace Platform
} // namespace Qul
