// Copyright (C) 2024 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial
#pragma once

#include <stdint.h>

#ifdef __cplusplus

constexpr uint64_t SEMAPHORE_SUSPEND_INTERVAL_MAX = std::numeric_limits<uint64_t>::max();

extern "C" {
#endif
typedef enum { MAINLOOP_SEMAPHORE, LCD_PXP_SEMAPHORE } SemaphoreType;

void setInterruptPriorities();

void initSuspension();
void suspend(SemaphoreType semaphoreType, uint64_t timeout);
void resume(SemaphoreType semaphoreType);
void systick(void);
#ifdef __cplusplus
}
#endif
