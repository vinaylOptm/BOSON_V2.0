// Copyright (C) 2024 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial
#pragma once

namespace Qul {
namespace Platform {
namespace Private {

double rand();

} // namespace Private
} // namespace Platform
} // namespace Qul
