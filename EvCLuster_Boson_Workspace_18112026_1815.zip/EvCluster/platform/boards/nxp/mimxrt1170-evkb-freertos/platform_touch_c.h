// Copyright (C) 2024 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void handleTouchInterrupt();

#ifdef __cplusplus
} // extern "C"
#endif
