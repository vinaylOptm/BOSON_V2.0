// Copyright (C) 2024 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial
#pragma once

#include <qul/eventqueue.h>
#include <platform/singlepointtoucheventdispatcher.h>

namespace Qul {
namespace Platform {
namespace Private {

class SinglePointTouchEventQueue : public EventQueue<SinglePointTouchEvent>
{
public:
    virtual void onEvent(const SinglePointTouchEvent &event) { touchEventDispatcher.dispatch(event); }

private:
    SinglePointTouchEventDispatcher touchEventDispatcher;
};

void BOARD_Touch_Init();
void requestTouchData();

} // namespace Private
} // namespace Platform
} // namespace Qul
