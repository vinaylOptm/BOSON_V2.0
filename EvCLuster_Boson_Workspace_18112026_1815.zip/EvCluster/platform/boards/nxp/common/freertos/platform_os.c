// Copyright (C) 2024 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial
#include "platform_os.h"

#include <FreeRTOS.h>
#include <semphr.h>
#include <task.h>
#include <portmacro.h>
#include "FreeRTOSConfig.h"
#include "fsl_common.h"

#include <stdint.h>
#include <limits.h>

void enterSleepMode();
void qul_delayMs(uint32_t ms);

static SemaphoreHandle_t mainloopSemaphore = NULL;
static SemaphoreHandle_t lcdPxpSemaphore = NULL;

void initSuspension()
{
    mainloopSemaphore = xSemaphoreCreateBinary();
    lcdPxpSemaphore = xSemaphoreCreateBinary();
}

void suspend(SemaphoreType semaphoreType, uint64_t timeout)
{
    SemaphoreHandle_t semaphore;
    switch (semaphoreType) {
    case MAINLOOP_SEMAPHORE:
        semaphore = mainloopSemaphore;
        break;
    case LCD_PXP_SEMAPHORE:
        semaphore = lcdPxpSemaphore;
        break;
    default:
        semaphore = NULL;
    }

    TickType_t timeoutTicks = 0;

#if configUSE_16_BIT_TICKS == 1
    timeoutTicks = (timeout >= USHRT_MAX) ? portMAX_DELAY : (timeout / portTICK_PERIOD_MS);
#else
    timeoutTicks = (TickType_t)((timeout >= UINT_MAX) ? portMAX_DELAY : (timeout / portTICK_PERIOD_MS));
#endif

    if (semaphore)
        xSemaphoreTake(semaphore, timeoutTicks);
}

void resume(SemaphoreType semaphoreType)
{
    SemaphoreHandle_t semaphore;
    switch (semaphoreType) {
    case MAINLOOP_SEMAPHORE:
        semaphore = mainloopSemaphore;
        break;
    case LCD_PXP_SEMAPHORE:
        semaphore = lcdPxpSemaphore;
        break;
    default:
        semaphore = NULL;
    }

    if (semaphore) {
        if (xPortIsInsideInterrupt() == pdTRUE)
        {
			BaseType_t xHigherPriorityTaskWoken = pdFALSE;
			xSemaphoreGiveFromISR(semaphore, &xHigherPriorityTaskWoken);

			portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
        }
        else
        {
            xSemaphoreGive(semaphore);
        }
    }
}

__attribute__((weak)) void vApplicationIdleHook()
{
    enterSleepMode();
}

#if (INCLUDE_xTaskGetSchedulerState != 1)
#error INCLUDE_xTaskGetSchedulerState FreeRTOS feature must be enabled
#endif /* INCLUDE_xTaskGetSchedulerState */
extern void xPortSysTickHandler();
void systick(void)
{
    if (xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED) {
        xPortSysTickHandler();
    }
}

__attribute__((noinline)) static void Qul_DelayAtLeastUs(uint32_t delayTime_us)
{
    SDK_DelayAtLeastUs(delayTime_us, SystemCoreClock);
}

void qul_delayMs(uint32_t ms)
{
    TickType_t ticks;
    ticks = (ms * configTICK_RATE_HZ) / 1000;
    if (!ms || !ticks) {
        return;
    } else if (xTaskGetSchedulerState() == taskSCHEDULER_NOT_STARTED) {
        // Fall back to basic delay loop if scheduler is not yet running.
        while (ms--) {
            Qul_DelayAtLeastUs(1000);
        }
    } else {
        vTaskDelay(ticks);
    }
}
