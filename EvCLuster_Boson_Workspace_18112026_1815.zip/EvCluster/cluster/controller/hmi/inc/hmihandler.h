#ifndef HMIHANDLER_H
#define HMIHANDLER_H

#include <qul/singleton.h>
#include <qul/property.h>
#include <qul/eventqueue.h>
#include <string>
#include <stdint.h>

typedef std::basic_string<char, std::char_traits<char>,
		Qul::PlatformInterface::Allocator<char> > QulString;
struct HmiHandler: public Qul::Singleton<HmiHandler> {
	friend struct Qul::Singleton<HmiHandler>;

	Qul::Property<QulString> sSwVer;
	Qul::Property<QulString> sHwVer;
	Qul::Property<QulString> sSerialNum;
	Qul::Property<QulString> sErrorMsg;
	Qul::Property<QulString> sMultiHeader;
	Qul::Property<QulString> sMultiMsg;

	enum ClusterEvents_t {
		Event_None 			= 0,
		Event_Motor 		= 1,
		Event_Battery 		= 2,
		Event_Charge 		= 3,
		Event_Adc 			= 4,
		Event_Time 			= 5,
		Event_DriveMode 	= 6,
		Event_NavSwitch 	= 7,
		Event_HwIndicator 	= 8,
		Event_Message 		= 9,
		//BLE
		Event_Call 			= 10,
		Event_BTMessage 	= 11,
		Event_TurnByTurnNav = 12,
		Event_DeviceStatus 	= 13,
		// Alert
		Event_Alert 		= 14,
		Event_DeviceVersion = 15,
		// Mirror
		Event_Image 		= 16,
		//status
		Event_Status0 		= 17,
		Event_Status1 		= 18,
		// Custom
		Event_MultiFault 	= 19,
		Event_Max 			= 20,
	};

	Qul::Signal<void(bool menable)> faultmessageChanged;
	Qul::Signal<void(int mmsgid)> messageChanged;
	Qul::Signal<void(bool menable)> btMessageChanged;
	Qul::Signal<void(int mkey, int mmodesel, int mmodeval)> navSwitchStatusChanged;
	Qul::Signal<void(int mid, int mcode)> alertInfoChanged;
	Qul::Signal<void(int mdrive, int mgear)> driveModeChanged;
	Qul::Signal<void(bool menable)> deviceVersionChanged;
	Qul::Signal<void(bool mstatus)> lvStatusChanged;
	Qul::Signal<void(int mid, int mstatus)> deviceStatusChanged;
	Qul::Signal<void(int mdir, int mdist, Qul::Private::String smsg)> tbtNavInfoChanged;
	Qul::Signal<void(int msoc, int mrange, int mbattemp, int mbatvoltage,int mbatcurrent)> battInfoChanged;
	Qul::Signal<void(int mstatus, int mctime,bool mttcenable, bool mchargeenable, bool mlowsoc)> chargeInfoChanged;
	Qul::Signal<void(int mspeed, int mrpm, int modo, int mtripa, int mtripb,
					 int mwd, int moperhrs, bool moperhrenable, int mspeedunit,int msoc)> motorInfoChanged;
	Qul::Signal<void(int mmode, Qul::Private::String mnum,
					Qul::Private::String mmsg)> callInfoChanged;
	Qul::Signal<void(int mday, int mmonth, int myear, int mhour, int mminute,
					bool mPM, int medit, int mstate, bool menable)> dateTimeChanged;
	Qul::Signal<void(bool mpowertrain, bool mbatfault, bool mservice, bool mpark,
					bool mhazard, bool mconnect, bool mcellular, bool minternet)> status0InfoChanged;
	Qul::Signal<void(bool minput1, bool minput2, bool minput3, bool minput4,
					bool minput5, bool minput6, bool minput7, bool minput8,
					bool minput9, bool minput10)> hwStatusChanged;
	Qul::Signal<void(bool mhdrenable, bool mmsgenable)> multiFaultInfoChanged;
	void updatePlatform(int eEvent, void *pEventParam);
	void updateUI(int eEvent, void *pEventParam);

private:
	HmiHandler();
	HmiHandler(const HmiHandler&);
	HmiHandler& operator=(const HmiHandler&);
};

#define HMI_EVENT_DATA_SIZE 252U

struct HmiEvent {
	int command;
	uint8_t sData[HMI_EVENT_DATA_SIZE];
};

class HmiEventQueue: public Qul::Singleton<HmiEventQueue>,
		public Qul::EventQueue<HmiEvent, Qul::EventQueueOverrunPolicy_Discard,	250>
{
public:
	void onEvent(const HmiEvent &sEvent);
	void onQueueOverrun() override
	{
		clearOverrun();
		Qul::PlatformInterface::log("\r\nHMI receiver queue overrun\r\n");
	}

	void onEventDiscarded(HmiEvent *&event) {
		Qul::PlatformInterface::log("\r\nonEventDiscarded\r\n");
	}
};

namespace UI {
void sendToUI(int eEvent, void *pEventParam);
}

#endif // HMIHANDLER_H
