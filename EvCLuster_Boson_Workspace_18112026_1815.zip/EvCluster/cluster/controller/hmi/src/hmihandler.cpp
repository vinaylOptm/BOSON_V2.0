#include <hmihandler.h>
#include "fsl_debug_console.h"
#include "cluster_common.h"
#include <string>
#include <cstdint>



HmiHandler::HmiHandler()
{

}

void HmiHandler::updatePlatform(int eEvent, void* pEventParam)
{

}

void HmiHandler::updateUI(int eEvent, void* pEventParam)
{
	switch ((ClusterEvents_t)(eEvent))
	{
		case Event_Motor:
		{
			sMotorInfo_t  sParam = {0};
			memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sMotorInfo_t));
			motorInfoChanged((int)sParam.iSpeed,(int)sParam.iRpm,(int)sParam.iOdo,
							 (int)sParam.iTripA,(int)sParam.iTripB,(int)sParam.iWheelDrive,
							 (int)sParam.iOprHrs,(int)sParam.bOprHrEnable,(int)sParam.iSpeedUnit,
							 (int)sParam.iSoc);
		}
		break;
//		case Event_Battery:
//		{
//			sBatteryInfo_t  sParam = {0};
//			memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sBatteryInfo_t));
//			battInfoChanged((int)sParam.iSoc, (int)sParam.iRange,(int)sParam.iTemp,
//							(int)sParam.iVoltage,(int)sParam.iCurrent);
//		}
//		break;
		case Event_HwIndicator:
		{
			sHwInputs_t sParam = {0};
			memcpy((char *)(&sParam),(char *)(pEventParam),sizeof(sHwInputs_t));
			hwStatusChanged(sParam.bInput1,sParam.bInput2,
					sParam.bInput3,sParam.bInput4,
					sParam.bInput5,sParam.bInput6,
					sParam.bInput7,sParam.bInput8,
					sParam.bInput9,sParam.bInput10);
		}
		break;
		case Event_Message:
		{
			sTextInfo_t  sParam = {0};
			memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sTextInfo_t));
			messageChanged(sParam.iTextCode);
		}
		break;
		case Event_NavSwitch:
		{
			sNavSwitch_t  sParam = {0};
			memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sNavSwitch_t));
			navSwitchStatusChanged(sParam.iVal,sParam.iModeSel,sParam.iModeVal);
		}
		break;

		case Event_DeviceStatus:
		{
			sDeviceStatus_t  sParam = {0};
			memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sDeviceStatus_t));
			deviceStatusChanged(sParam.iId,sParam.iStatus);
		}
		break;

		case Event_Time:
		{
			sTimeInfo_t sParam = {0};
			memcpy((char *)(&sParam),(char *)(pEventParam),sizeof(sTimeInfo_t));
			dateTimeChanged((int)sParam.iDay,(int)sParam.iMonth,(int)sParam.iYear,
					(int)sParam.iHour,(int)sParam.iMinute, sParam.bPM,
					(int)sParam.iIsEdit,(int)sParam.iState,sParam.bEnable);
		}
		break;
		case Event_Charge:
		{
			sChargeInfo_t  sParam = {0};
			memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sChargeInfo_t));
			chargeInfoChanged((int)sParam.iStatus,(int)sParam.iTime,(int)sParam.bTtcEnable,
					(int)sParam.bChargeEnable,(int)(sParam.bLowSoc));
		}
		break;

		case Event_DriveMode:
		{
			sDriveMode_t  sParam = {0};
			memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sDriveMode_t));
			driveModeChanged(sParam.iDriveVal,sParam.iGearVal);
		}
		break;

		case Event_Alert:
		{
			sAlertInfo_t sParam;
			memcpy((char *)(&sParam),(char *)(pEventParam),sizeof(sAlertInfo_t));
			alertInfoChanged((int)sParam.iId,(int)sParam.iCode);
		}
		break;
#if 0
		case Event_Fault:
		{
			sFault_t sParam = {0};
			memcpy((char *)(&sParam) ,(char *)(pEventParam),sizeof(sFault_t));
			sErrorMsg.setValue ((sParam.sMsg));
			faultmessageChanged((bool)sParam.bEnable);
		}
		break;
#endif
		case Event_Adc:
		{
			sAdc_t sParam;
			memcpy((char *)(&sParam),(char *)(pEventParam),sizeof(sAdc_t));
			lvStatusChanged(sParam.bLVBattery);
		}
		break;
		case Event_Status0:
		{
			sStatus0_t sParam;
			memcpy((char *)(&sParam),(char *)(pEventParam),sizeof(sStatus0_t));
			status0InfoChanged((int)sParam.bPowerTrain,(int)sParam.bBatteryFault,
								(int)sParam.bService,(int)sParam.bPark,
								(int)sParam.bHazard,(int)sParam.bConnectivity,
								(int)sParam.bCellular,(int)sParam.bInternet);
		}
		break;
		case Event_DeviceVersion:
		{
			sSystemInfo_t sParam = {0};
			memcpy((char *)(&sParam),(char *)(pEventParam),sizeof(sSystemInfo_t));
			sSwVer.setValue(sParam.sSwVer);
			sHwVer.setValue(sParam.sHwVer);
			sSerialNum.setValue(sParam.sSlNum);
			deviceVersionChanged(sParam.bEnable);
		}
		break;
		case Event_MultiFault:
		{
			sMultiFault_t sParam = {0};
			memcpy((char *)(&sParam),(char *)(pEventParam),sizeof(sMultiFault_t));

			sMultiHeader.setValue(sParam.sHeader);
			sMultiMsg.setValue(sParam.sMsg);

			multiFaultInfoChanged(sParam.bHdrEnable, sParam.bMsgEnable);
		}
		break;
		default:
			PRINTF("\r\n updateUI:Default : event:%d \r\n",eEvent);
		break;
	}
}

void HmiEventQueue::onEvent(const HmiEvent &sEvent)
{
	HmiHandler::instance().updateUI(sEvent.command, (void*)sEvent.sData);
}

static HmiEventQueue hEventQueue;


void UI::sendToUI(int iEventVal, void* pEventParam)
{
	HmiEvent sEvent;
	sEvent.command = iEventVal;
	memcpy(sEvent.sData, pEventParam, HMI_EVENT_DATA_SIZE);
	hEventQueue.postEvent(sEvent);
}
