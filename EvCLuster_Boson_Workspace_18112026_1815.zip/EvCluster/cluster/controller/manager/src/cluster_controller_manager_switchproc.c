/*-----------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										   *
 *	Copyright (C) OptM Media Solutions Pvt Ltd - All Rights Reserved.	   	   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from OptM Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_controller_manager_switchproc.c					   *
 *  version		: 											              	   *
 *  Date		:	03-Mar-2023												   *
 *  Description :  				 										 	   *
 *                               						                       *
 *-----------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------*
 * Include Headers				           	                             	   *
 *-----------------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
#include "timers.h"
#include "fsl_debug_console.h"
#include "clock_config.h"
#include "fsl_gpt.h"
#include "fsl_gpio.h"

#include "cluster_common.h"
#include "cluster_controller_hal.h"
#include "cluster_controller_manager_switchproc.h"
#include "cluster_controller_manager_rtcproc.h"
#include "cluster_controller_manager_canproc.h"
#include "cluster_controller_manager_systeminfo.h"
/*----------------------------------------------------------------------------*
 * Macro ,Structure and Enum definitions           				              *
 *-----------------------------------------------------------------------------*/
#define MAX_QUEUE_MSG_COUNT				10
#define NAV_SWITCH_COUNT				3
#define MSG_BUFFER_SIZE					sizeof(sMessage_t)
#define MSG_QUEUE_BUFFER_SIZE 			(MSG_BUFFER_SIZE + 16)
#define SWITCH_QUEUE_WAITTIME			portMAX_DELAY
#define SWITCHPROC_GPTIMER              GPT2
#define GPT_TICKS_PER_MS    			24000U
#define BUTTON_HOLD_MS      			5000U
#define BUTTON_REPEAT_MS    			300U
#define BUTTON_STUCK_MS     			8000U
#define BUTTON_RTC_MS       			3000U

typedef struct
{
	bool            bIsTimerEnabled;
	uint32_t       iRefTime;
}SwitchTimer_t;

typedef struct
{
	bool                bIsRtcSetEnabled;
	bool                bIsRtcTimeStarted;
	bool                bIsTripResetEnabled;
	bool                bIsIgnitionOn;
	uint8_t 			iSpeedUnit;
	uint8_t 			iNavSel;
	uint8_t             iCurNavgStatus;
	uint8_t             iIsDevInfoEnabled;
	uint8_t				iSwitchVal;
	int32_t     		iIsInitialised;
	uint32_t            iCurStructCode;
	uint32_t            iTripStartTime;
	uint32_t            iLeftBounceStart;
	uint32_t            iLeftBounceStartTime;
	uint32_t            iRightBounceStart;
	uint32_t            iRightBounceStartTime;
	uint32_t            iOkBounceStart;
	uint32_t            iOkBounceStartTime;
	uint32_t            iInfoStartTime;
	QueueHandle_t       qRxMsg;
	QueueHandle_t       qRtcMsg;
	QueueHandle_t  	    qHmiMsg;
	TaskHandle_t 	    hRxThread;
	sNavSwitch_t        sNav;
	sHwInputs_t         sHwStatus;
	sAlertInfo_t        sKeyAlertInfo;
	SwitchTimer_t       sTimer[NAV_SWITCH_COUNT];
}SwitchProc_t;

/*----------------------------------------------------------------------------*
 * Static and global variable definition	                         		  *
 *----------------------------------------------------------------------------*/
static SwitchProc_t hSProc = {0};
/*----------------------------------------------------------------------------*
 * Local function definition	                         				      *
 *----------------------------------------------------------------------------*/
static void SwitchProc_CleanUp(void* arg);
static void SwitchProc_MessageHandler(void *arg);
static void SwitchProc_TripReset_TimerConfigure(void);
static void SwitchProc_SendAlertInfo(SwitchProc_t* pHan);
static int32_t SwitchProc_UpdateDeviceInfo(SwitchProc_t* pHan);
static void SwitchProc_UpdateSwitchStruckStatus(SwitchProc_t* pHan);
static void SwitchProc_SendInfoToRtcProc(SwitchProc_t* pHan, uint8_t iKeyVal);
static void SwitchProc_CheckSwitchStuck(SwitchProc_t * pHan,uint8_t iSwStatus);
static uint32_t SwitchProc_GetTimeDiff(	SwitchProc_t* pHan, uint32_t  iPrevTime);
static void SwitchProc_SendProductInfo(SwitchProc_t * pHan, sSystemInfo_t * pInfo);
static void SwitchProc_ExtInput_SendInfo(SwitchProc_t * pHan, sHwInputs_t* pStatus);
static void SwitchProc_Navigation_ParseData(SwitchProc_t * pHan, uint8_t iSwStatus);
static void SwitchProc_Navigation_Process_OkButton(SwitchProc_t * pHan,uint8_t iStatus);
static void SwitchProc_Navigation_Process_RightButton(SwitchProc_t * pHan,uint8_t iStatus);
#if NAV_MULTIFUNCTION == 0
static void SwitchProc_Navigation_Process_LeftButton(SwitchProc_t * pHan,uint8_t iStatus);
#endif

/*----------------------------------------------------------------------------*
 * Function	    :		Cluster_Controller_Manager_SwitchProc_Init 	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SwitchProc_Init(QueueHandle_t QueueId)
{
	int32_t iRval = BCU_NOK;
	if(hSProc.iIsInitialised == 0)
	{
		uint16_t iStackSize =0;
		memset(&hSProc, 0 ,sizeof(hSProc));
		hSProc.qHmiMsg = QueueId;
		hSProc.iCurNavgStatus=0x00;

		Cluster_Controller_Hal_ConfigGetStackSize(&iStackSize);

		hSProc.qRxMsg = xQueueCreate(MAX_QUEUE_MSG_COUNT,MSG_QUEUE_BUFFER_SIZE);

		if(hSProc.qRxMsg != 0)
		{
			if (xTaskCreate(SwitchProc_MessageHandler,
					"SwProc",
					iStackSize,
					&hSProc,
					CLUSTER_TASK_PRIORITY_DATA,
					&hSProc.hRxThread) == pdPASS)
			{
				iRval = Cluster_Controller_Hal_SetReceiveQueueHandle(eModule_Switch ,
						hSProc.qRxMsg);
				if(iRval == BCU_OK)
				{
					hSProc.iIsInitialised = 1;
					SwitchProc_TripReset_TimerConfigure();
				}
				else
				{
					Cluster_Controller_Manager_SwitchProc_DeInit();
				}
			}
			else
			{
				iRval = BCU_NOK;
				PRINTF("SWITCHPROC:Error: SWITCH_receive_Thread create failed \n");
				SwitchProc_CleanUp(NULL);
			}
		}
		else
		{
			iRval = BCU_NOK;
			PRINTF("SWITCHPROC:Error: xQueueCreate  failed \n");
		}
	}
	return (iRval);
}
/*----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Manager_SwitchProc_DeInit	 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
void Cluster_Controller_Manager_SwitchProc_DeInit(void)
{
	if(hSProc.iIsInitialised)
	{
		hSProc.iIsInitialised = 0;
		if(hSProc.hRxThread != NULL)
		{
			vTaskDelete(hSProc.hRxThread);
			hSProc.hRxThread = NULL;
		}
		SwitchProc_CleanUp(NULL);
		memset(&hSProc, 0, sizeof(SwitchProc_t));
	}
}
/*----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_SwitchProc_SetReceiveQueueHandle		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_SwitchProc_SetReceiveQueueHandle(QueueHandle_t qRxMsg)
{
	int32_t iRval = BCU_OK;

	if(hSProc.iIsInitialised == 1)
	{
		hSProc.qRtcMsg = qRxMsg;
	}

	return (iRval);
}
/*----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_SwitchProc_GetHwStatus		 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_SwitchProc_GetHwStatus(sHwInputs_t* pStatus)
{
	int32_t iRval = BCU_OK;

	if(hSProc.iIsInitialised == 1)
	{
		memcpy(pStatus,&(hSProc.sHwStatus),sizeof(sHwInputs_t));
	}

	return (iRval);
}

/*----------------------------------------------------------------------------*
 * Function	    :		Cluster_Controller_SwitchProc_RtcSetMode	 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_SwitchProc_RtcSetMode(bool bSetMode)
{
	int32_t iRval = BCU_OK;
	if(bSetMode == false)
	{
		hSProc.bIsRtcSetEnabled = false;
		hSProc.bIsRtcTimeStarted = false;
	}
	Cluster_Controller_Hal_RtcSetMode(bSetMode);
	return (iRval);
}

/*-----------------------------------------------------------------------------*
 * Function	    :			SwitchProc_MessageHandler		        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
static void SwitchProc_MessageHandler(void *arg)
{
	SwitchProc_t * pHan = (SwitchProc_t *)(arg);
	char sBuf[MSG_QUEUE_BUFFER_SIZE];
	sMessage_t pSwMsg ;
	sNavSwitch_t  sNavInput ={0};
	sHwInputs_t  sInputs = {0};
	while (1)
	{
		memset(&sBuf[0],0, sizeof(sBuf));
		memset(&sInputs,0, sizeof(sHwInputs_t));
		memset(&sNavInput,0, sizeof(sNavSwitch_t));

		if(pdPASS == xQueueReceive(pHan->qRxMsg,(char*)&sBuf[0],SWITCH_QUEUE_WAITTIME))
		{
			memcpy ((char *)&pSwMsg, &(sBuf[0]), sizeof(sMessage_t));
			if(pSwMsg.iEventId == EXTERNAL_SW)
			{
				memcpy((char*)(&sInputs),(char *)pSwMsg.sData,sizeof(sHwInputs_t));
#if CLUSTER_KEYIGNITION_SUPPORTED
				if(pHan->sHwStatus.bInput1 != sInputs.bInput1)
				{
					if(sInputs.bInput1 == 1)
					{
						SwitchProc_ExtInput_SendInfo(pHan,&sInputs);
						Cluster_Controller_Hal_CanSleep(false);

						Cluster_Controller_Manager_CanProc_IgnitionStatus(sInputs.bInput1);
						pHan->bIsIgnitionOn = sInputs.bInput1;
					}
					else
					{
						SwitchProc_ExtInput_SendInfo(pHan,&sInputs);
						Cluster_Controller_Manager_CanProc_IgnitionStatus(sInputs.bInput1);
						pHan->bIsIgnitionOn = sInputs.bInput1;
					}
				}
#else
				Cluster_Controller_Hal_CanSleep(false);
				pHan->bIsIgnitionOn  = true;
				Cluster_Controller_Manager_CanProc_IgnitionStatus(true);
				sInputs.bInput1 = true;
#endif
				if( (pHan->sHwStatus.bInput2 != sInputs.bInput2) ||
						(pHan->sHwStatus.bInput3 != sInputs.bInput3) ||
						(pHan->sHwStatus.bInput4 != sInputs.bInput4) ||
						(pHan->sHwStatus.bInput5 != sInputs.bInput5) ||
						(pHan->sHwStatus.bInput6 != sInputs.bInput6) ||
						(pHan->sHwStatus.bInput7 != sInputs.bInput7) ||
						(pHan->sHwStatus.bInput8 != sInputs.bInput8) ||
						(pHan->sHwStatus.bInput9 != sInputs.bInput9) ||
						(pHan->sHwStatus.bInput10 != sInputs.bInput10) ||
#if CLUSTER_KEYIGNITION_SUPPORTED					
						(pHan->sHwStatus.bInput1 != sInputs.bInput1) ||
#endif				
						(sInputs.bRefresh ==1) )
				{
					SwitchProc_ExtInput_SendInfo(pHan,&sInputs);
					memcpy((char*)(&(pHan->sHwStatus)),(char *)pSwMsg.sData,sizeof(sHwInputs_t));

				}
			}
			else if(pSwMsg.iEventId == NAVIGATION_SW)
			{
				if(pHan->bIsIgnitionOn)
				{
					memcpy((char*)(&sNavInput),(char *)pSwMsg.sData,sizeof(sNavSwitch_t));
					SwitchProc_Navigation_ParseData(pHan,sNavInput.iVal);
				}
				else
				{
					if(pHan->bIsRtcSetEnabled == 1)
					{
						SwitchProc_SendInfoToRtcProc(pHan,(uint8_t)(eRtc_Save));
					}
					pHan->bIsRtcSetEnabled = false;
					pHan->bIsRtcTimeStarted = false;
					pHan->bIsTripResetEnabled = false;
					pHan->iIsDevInfoEnabled = 0;
				}
			}
			else
			{
				PRINTF("\r\n SWITCH_PROC EVENTID ERROR \r\n");
			}
		}
		taskYIELD();
	}
}
/*----------------------------------------------------------------------------*
 * Function	    :			SwitchProc_CleanUp			        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void SwitchProc_CleanUp(void* arg)
{
	(void)(arg);
	if(hSProc.qRxMsg != NULL)
	{
		vQueueDelete(hSProc.qRxMsg);
		hSProc.qRxMsg = NULL;
	}
}
/*----------------------------------------------------------------------------*
 * Function	    :			SwitchProc_ExtInput_SendInfo        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void SwitchProc_ExtInput_SendInfo(SwitchProc_t * pHan, sHwInputs_t* pStatus)
{
	sMessage_t	  sMsg		= {0};

	if(pHan->qHmiMsg !=NULL)
	{
		sMsg.iEventId 			= eEvent_HwIndicator;
		memcpy((char *)sMsg.sData,(char*)(pStatus),sizeof(sHwInputs_t));
		xQueueSend(pHan->qHmiMsg, &sMsg, pdMS_TO_TICKS(1000U));
	}
}
/*----------------------------------------------------------------------------*
 * Function	    :			SwitchProc_SendNavigIndicatorInfo      	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void SwitchProc_SendNavigIndicatorInfo(SwitchProc_t* pHan)
{
	sMessage_t	  sMsg		= {0};

	if(pHan->qHmiMsg !=NULL)
	{
		sMsg.iEventId 			= eEvent_NavSwitch;
		memcpy((char *)sMsg.sData,(char*)(&(pHan->sNav)),sizeof(sNavSwitch_t));
		xQueueSend(pHan->qHmiMsg, &sMsg, pdMS_TO_TICKS(1000U));
	}
}
/*----------------------------------------------------------------------------*
 * Function	    :			SwitchProc_Navigation_ParseData        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void SwitchProc_Navigation_ParseData(SwitchProc_t * pHan, uint8_t iSwStatus)
{
	if(pHan != NULL)
	{
		SwitchProc_CheckSwitchStuck(pHan,iSwStatus);
#if NAV_MULTIFUNCTION == 0
		SwitchProc_Navigation_Process_LeftButton(pHan, iSwStatus);
#endif
		SwitchProc_Navigation_Process_OkButton(pHan, iSwStatus);
		SwitchProc_Navigation_Process_RightButton(pHan, iSwStatus);
		pHan->iCurNavgStatus = iSwStatus;
	}
}

/*----------------------------------------------------------------------------*
 * Function	      	:	SwitchProc_TripReset_TimerConfigure	          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void SwitchProc_TripReset_TimerConfigure(void)
{
	gpt_config_t gptConfig = {
			.clockSource = kGPT_ClockSource_Periph,
			.divider = 1,
			.enableRunInStop = false,
			.enableMode =true
	};

	GPT_Init(SWITCHPROC_GPTIMER, &gptConfig);
	GPT_StopTimer(SWITCHPROC_GPTIMER);
	GPT_StartTimer(SWITCHPROC_GPTIMER);
}
/*----------------------------------------------------------------------------*
 * Function	    :			SwitchProc_SendInfoToRtcProc        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void SwitchProc_SendInfoToRtcProc(SwitchProc_t* pHan, uint8_t iKeyVal)
{
	sMessage_t	  sMsg		= {0};
	pHan->sNav.iVal  	= iKeyVal;
	sMsg.iEventId 		= eEvent_NavSwitch;
	memcpy((char *)sMsg.sData,(char*)(&(pHan->sNav)),sizeof(sNavSwitch_t));

	if((pHan->qRtcMsg !=NULL) && (sMsg.iEventId > 0))
	{
		xQueueSend(pHan->qRtcMsg, &sMsg, (TickType_t)(5000));
	}
}
/*----------------------------------------------------------------------------*
 * Function	    :			SwitchProc_SendProductInfo	        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void SwitchProc_SendProductInfo(SwitchProc_t * pHan, sSystemInfo_t * pInfo)
{
	sMessage_t	  sMsg		= {0};
	if(pHan->qHmiMsg !=NULL)
	{
		sMsg.iEventId 			= eEvent_DeviceVersion;
		memcpy((char *)sMsg.sData,(char*)(pInfo),sizeof(sSystemInfo_t));
		xQueueSend(pHan->qHmiMsg, &sMsg, pdMS_TO_TICKS(1000U));
	}
}
/*----------------------------------------------------------------------------*
 * Function	    :			SwitchProc_UpdateDeviceInfo	        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static int32_t SwitchProc_UpdateDeviceInfo(SwitchProc_t* pHan)
{
	int32_t iRval = BCU_NOK;
	sDeviceInfo_t  sInfo = {0};
	sSystemInfo_t  sSysInfo = {0};
	char sSlno[12] = {0};

	iRval = Cluster_Controller_Manager_SystemInfo_GetVehicleSpecInfo(&sInfo);
	if(iRval == BCU_OK)
	{
		Cluster_Controller_Hal_ConfigGetSwHwVersion(&sSysInfo.sSwVer[0], &sSysInfo.sHwVer[0]);

		sprintf(sSysInfo.sSlNum,"OM5NL0");
		snprintf(sSlno,sizeof(sSlno),"%ld",sInfo.iSlNum);

		strcat(sSysInfo.sSlNum,sSlno);

		sSysInfo.bEnable = true;
		SwitchProc_SendProductInfo(pHan, &sSysInfo);
	}
	else
	{
		sSysInfo.bEnable = false;
		SwitchProc_SendProductInfo(pHan, &sSysInfo);
	}
	return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	    :		SwitchProc_UpdateSwitchStruckStatus        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void SwitchProc_UpdateSwitchStruckStatus(SwitchProc_t* pHan)
{
	pHan->sKeyAlertInfo.iId = (uint16_t)eAlert_Switch;

	if(pHan->sKeyAlertInfo.iCode != pHan->iCurStructCode)
	{
		SwitchProc_SendAlertInfo(pHan);
		pHan->iCurStructCode = pHan->sKeyAlertInfo.iCode;
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	SwitchProc_SendAlertInfo 				          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void SwitchProc_SendAlertInfo(SwitchProc_t* pHan)
{
	sMessage_t	  sMsg		= {0};
	sMsg.iEventId 			= eEvent_Alert;
	memcpy((char *)sMsg.sData,(char*)(&(pHan->sKeyAlertInfo)),sizeof(sAlertInfo_t));
	if((pHan->qHmiMsg !=NULL) && (sMsg.iEventId >0))
	{
		xQueueSend(pHan->qHmiMsg, &sMsg, (TickType_t)(1000));
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	SwitchProc_GetTimeDiff	 				          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static uint32_t SwitchProc_GetTimeDiff(	SwitchProc_t* pHan,uint32_t  iRefTime)
{
	uint32_t iMaxTime = 0xFFFFFFFFU;   /* GPT is a 32-bit counter */
	(void)(pHan);
	uint32_t  iCurTime;
	uint32_t  iTimeDiff;
	iCurTime  = GPT_GetCurrentTimerCount(SWITCHPROC_GPTIMER);

	if(iCurTime > iRefTime)
	{
		iTimeDiff = (iCurTime - iRefTime) / GPT_TICKS_PER_MS;
	}
	else if(iCurTime < iRefTime)
	{
		iTimeDiff =   (uint32_t)(((iMaxTime - iRefTime) + iCurTime) / GPT_TICKS_PER_MS);
	}
	else
	{
		iTimeDiff = 0;
	}
	return iTimeDiff;
}

#if NAV_MULTIFUNCTION == 1
/*----------------------------------------------------------------------------*
 * Function	    :		SwitchProc_Navigation_Process_RightButton  	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void SwitchProc_Navigation_Process_RightButton(SwitchProc_t *pHan, uint8_t iSwStatus)
{
	uint32_t iTimeDiff = 0U;

	if ((pHan->iCurStructCode & (uint32_t)(eKey_Right)) == 0U)
	{
		pHan->sNav.iVal = eKey_Right;
		uint8_t iStatus = iSwStatus & eKey_Right;

		if ((pHan->iCurNavgStatus & eKey_Right) != iStatus)
		{
			//RIGHT KEY PRESSED
			if(iStatus == eKey_Right)
			{
				pHan->iSwitchVal = (pHan->iSwitchVal | eKey_Right);
				Cluster_Controller_Manager_CanProc_UpdateNavKeyInfo(pHan->iSwitchVal,1U);
				if (pHan->iIsDevInfoEnabled == 0U)
				{
					pHan->iInfoStartTime = GPT_GetCurrentTimerCount(SWITCHPROC_GPTIMER);
					pHan->iIsDevInfoEnabled = 1U;
				}
			}
			else
			{
				if (pHan->iIsDevInfoEnabled == 1U)
				{
					iTimeDiff = SwitchProc_GetTimeDiff(pHan, pHan->iInfoStartTime);

					if (iTimeDiff >= BUTTON_HOLD_MS)
					{
						SwitchProc_UpdateDeviceInfo(pHan);

						PRINTF("\r\nSwitchProc_UpdateDeviceInfo\r\n");
					}
					else
					{
						pHan->iNavSel++;

						if (pHan->iNavSel >= eNavSel_Max)
						{
							pHan->iNavSel = eNavSel_Time;
						}

						if((pHan->iNavSel >= eNavSel_SpeedUnit) && (pHan->bIsRtcSetEnabled = 1))
						{
							SwitchProc_SendInfoToRtcProc(pHan,(uint8_t)eRtc_Exit);
							pHan->bIsRtcSetEnabled = 0;
							pHan->bIsRtcTimeStarted = 0U;
						}

						switch (pHan->iNavSel)
						{
						case eNavSel_Time:
						{
							pHan->bIsRtcSetEnabled = 1U;
							pHan->bIsRtcTimeStarted = 0U;
							SwitchProc_SendInfoToRtcProc(pHan,(uint8_t)eRtc_Init);
							pHan->sNav.iModeSel = eNavSel_Time;
						}
						break;
						case eNavSel_SpeedUnit:
						case eNavSel_Odo:
						case eNavSel_TripA:
						case eNavSel_TripB:
						{
							pHan->sNav.iModeSel = pHan->iNavSel;
						}
						break;
						default:
							break;
						}

						pHan->sNav.iVal = eKey_Right;
						SwitchProc_SendNavigIndicatorInfo(pHan);
					}
				}
				pHan->iIsDevInfoEnabled = 0U;
				pHan->iSwitchVal = (pHan->iSwitchVal | eKey_Right);
				Cluster_Controller_Manager_CanProc_UpdateNavKeyInfo(pHan->iSwitchVal,0U);
				pHan->iSwitchVal = 0;
			}
		}
	}
	else
	{
		pHan->iIsDevInfoEnabled = 0U;
	}
}
/*----------------------------------------------------------------------------*
 * Function	    :		SwitchProc_Navigation_Process_OkButton   	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void SwitchProc_Navigation_Process_OkButton(SwitchProc_t *pHan, uint8_t iSwStatus)
{
	uint32_t iTimeDiff = 0U;

	if ((pHan->iCurStructCode & (uint32_t)eKey_Ok) == 0U)
	{
		pHan->sNav.iVal = eKey_Ok;

		uint8_t iStatus = iSwStatus & eKey_Ok;

		if ((pHan->iCurNavgStatus & eKey_Ok) != iStatus)
		{
			if (iStatus == eKey_Ok)
			{
				pHan->iSwitchVal = (pHan->iSwitchVal | eKey_Ok);
				Cluster_Controller_Manager_CanProc_UpdateNavKeyInfo(pHan->iSwitchVal,1U);
				if (pHan->sNav.iModeSel  == eNavSel_Time)
				{
					if (pHan->bIsRtcSetEnabled == 1U)
					{
						if (pHan->iOkBounceStart == 0U)
						{
							pHan->iOkBounceStartTime = GPT_GetCurrentTimerCount(SWITCHPROC_GPTIMER);
							pHan->iOkBounceStart = 1U;
						}
					}
				}
				else if ((pHan->sNav.iModeSel == eSelect_TripA) || (pHan->sNav.iModeSel == eSelect_TripB))
				{
					if (pHan->bIsTripResetEnabled == 0U)
					{
						pHan->iTripStartTime = GPT_GetCurrentTimerCount(SWITCHPROC_GPTIMER);
						pHan->bIsTripResetEnabled = 1U;
					}
				}

			}
			else
			{
				if (pHan->sNav.iModeSel == eNavSel_Time)
				{
					if ((pHan->bIsRtcSetEnabled == 1U))
					{
						if (pHan->iOkBounceStart == 0U)
						{
							pHan->iOkBounceStartTime = GPT_GetCurrentTimerCount(SWITCHPROC_GPTIMER);
							pHan->iOkBounceStart = 1U;
						}
						iTimeDiff = SwitchProc_GetTimeDiff(pHan, pHan->iOkBounceStartTime);
						if (iTimeDiff >= BUTTON_RTC_MS)
						{
							pHan->bIsRtcTimeStarted = 1U;
							SwitchProc_SendInfoToRtcProc(pHan, (uint8_t)eRtc_State);
						}
						else
						{
							if(pHan->bIsRtcTimeStarted == 1)
							{
								SwitchProc_SendInfoToRtcProc(pHan, (uint8_t)eRtc_Param);
							}
						}

						pHan->iOkBounceStart = 0U;
					}
				}
				else if (pHan->sNav.iModeSel == eNavSel_SpeedUnit)
				{
					if (pHan->iSpeedUnit == 0)
					{
						pHan->iSpeedUnit = 1;
					}
					else
					{
						pHan->iSpeedUnit = 0;
					}
					pHan->sNav.iVal = eKey_Ok;
					pHan->sNav.iModeVal = pHan->iSpeedUnit;

					Cluster_Controller_Manager_CanProc_UpdateUnit(pHan->iSpeedUnit);

					SwitchProc_SendNavigIndicatorInfo(pHan);
				}
				else if (pHan->sNav.iModeSel == eNavSel_Odo)
				{
					pHan->sNav.iModeVal = eNavSel_Odo;
					pHan->sNav.iVal = eKey_Ok;
					SwitchProc_SendNavigIndicatorInfo(pHan);
				}
				else if (pHan->sNav.iModeSel == eNavSel_TripA)
				{
					if (pHan->bIsTripResetEnabled == 1U)
					{
						if (pHan->iOkBounceStart == 0U)
						{
							pHan->iOkBounceStartTime = GPT_GetCurrentTimerCount(SWITCHPROC_GPTIMER);
							pHan->iOkBounceStart = 1U;
						}
						iTimeDiff = SwitchProc_GetTimeDiff(pHan, pHan->iTripStartTime);

						if (iTimeDiff >= BUTTON_HOLD_MS)
						{
							Cluster_Controller_Manager_CanProc_ResetTrip(0);
						}
						else
						{
							pHan->sNav.iModeVal = eSelect_TripA;
							pHan->sNav.iVal = eKey_Ok;
							SwitchProc_SendNavigIndicatorInfo(pHan);
						}
					}
				}
				else if (pHan->sNav.iModeSel == eNavSel_TripB)
				{
					if (pHan->bIsTripResetEnabled == 1U)
					{
						iTimeDiff = SwitchProc_GetTimeDiff(pHan, pHan->iTripStartTime);

						if (iTimeDiff >= BUTTON_HOLD_MS)
						{
							Cluster_Controller_Manager_CanProc_ResetTrip(1);
						}
						else
						{
							pHan->sNav.iModeVal = eSelect_TripB;
							pHan->sNav.iVal = eKey_Ok;
							SwitchProc_SendNavigIndicatorInfo(pHan);
						}
					}
				}
				pHan->bIsTripResetEnabled = 0U;
				pHan->iOkBounceStart = 0U;
				pHan->iSwitchVal = (pHan->iSwitchVal | eKey_Ok);
				Cluster_Controller_Manager_CanProc_UpdateNavKeyInfo(pHan->iSwitchVal,0U);
				pHan->iSwitchVal = 0;
			}
		}
	}
	else
	{
		pHan->iOkBounceStart = 0U;
		pHan->bIsTripResetEnabled = 0U;
	}
}

#else
/*----------------------------------------------------------------------------*
 * Function	    :		SwitchProc_Navigation_Process_RightButton  	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void SwitchProc_Navigation_Process_RightButton(SwitchProc_t *pHan, uint8_t iSwStatus)
{
	uint32_t iTimeDiff = 0U;

	if ((pHan->iCurStructCode & (uint32_t)(eKey_Right)) == 0U)
	{
		pHan->sNav.iVal = eKey_Right;
		uint8_t iStatus = iSwStatus & eKey_Right;

		if ((pHan->iCurNavgStatus & eKey_Right) != iStatus)
		{
			//RIGHT KEY PRESSED
			if(iStatus == eKey_Right)
			{
				if (pHan->iIsDevInfoEnabled == 0U)
				{
					pHan->iInfoStartTime = GPT_GetCurrentTimerCount(SWITCHPROC_GPTIMER);
					pHan->iIsDevInfoEnabled = 1U;
				}
			}
			else
			{
				if (pHan->iIsDevInfoEnabled == 1U)
				{
					iTimeDiff = SwitchProc_GetTimeDiff(pHan, pHan->iInfoStartTime);

					if (iTimeDiff >= BUTTON_HOLD_MS)
					{
						SwitchProc_UpdateDeviceInfo(pHan);

						PRINTF("\r\nSwitchProc_UpdateDeviceInfo\r\n");
					}
					else
					{
						if(pHan->iRightBounceStart == 0)
						{
							pHan->iRightBounceStartTime  = GPT_GetCurrentTimerCount(SWITCHPROC_GPTIMER);
							pHan->iRightBounceStart = 1;
						}
						pHan->iNavSel++;

						if (pHan->iNavSel >= eNavSel_Max)
						{
							pHan->iNavSel = eNavSel_Time;
						}

						if((pHan->iNavSel >= eNavSel_SpeedUnit) && (pHan->bIsRtcSetEnabled = 1))
						{
							SwitchProc_SendInfoToRtcProc(pHan,(uint8_t)eRtc_Exit);
							pHan->bIsRtcSetEnabled = 0;
							pHan->bIsRtcTimeStarted = 0U;
						}

						switch (pHan->iNavSel)
						{
						case eNavSel_Time:
						{
							pHan->bIsRtcSetEnabled = 1U;
							pHan->bIsRtcTimeStarted = 0U;
							SwitchProc_SendInfoToRtcProc(pHan,(uint8_t)eRtc_Init);
							pHan->sNav.iModeSel = eNavSel_Time;
						}
						break;
						case eNavSel_SpeedUnit:
						case eNavSel_Odo:
						case eNavSel_TripA:
						case eNavSel_TripB:
						{
							pHan->sNav.iModeSel = pHan->iNavSel;
						}
						break;
						default:
							break;
						}

						pHan->sNav.iVal = eKey_Right;
						SwitchProc_SendNavigIndicatorInfo(pHan);
					}
				}
				pHan->iIsDevInfoEnabled = 0U;
			}
		}
	}
	else
	{
		pHan->iIsDevInfoEnabled = 0U;
	}
}
/*----------------------------------------------------------------------------*
 * Function	    :		SwitchProc_Navigation_Process_OkButton   	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void SwitchProc_Navigation_Process_OkButton(SwitchProc_t *pHan, uint8_t iSwStatus)
{
	uint32_t iTimeDiff = 0U;

	if ((pHan->iCurStructCode & (uint32_t)eKey_Ok) == 0U)
	{
		pHan->sNav.iVal = eKey_Ok;

		uint8_t iStatus = iSwStatus & eKey_Ok;

		if ((pHan->iCurNavgStatus & eKey_Ok) != iStatus)
		{
			if (iStatus == eKey_Ok)
			{
				if (pHan->sNav.iModeSel  == eNavSel_Time)
				{
					if (pHan->bIsRtcSetEnabled == 1U)
					{
						if (pHan->iOkBounceStart == 0U)
						{
							pHan->iOkBounceStartTime = GPT_GetCurrentTimerCount(SWITCHPROC_GPTIMER);
							pHan->iOkBounceStart = 1U;
						}
					}
				}
				else if ((pHan->sNav.iModeSel == eSelect_TripA) || (pHan->sNav.iModeSel == eSelect_TripB))
				{
					if (pHan->bIsTripResetEnabled == 0U)
					{
						pHan->iTripStartTime = GPT_GetCurrentTimerCount(SWITCHPROC_GPTIMER);
						pHan->bIsTripResetEnabled = 1U;
					}
				}
			}
			else
			{
				if (pHan->sNav.iModeSel == eNavSel_Time)
				{
					if ((pHan->bIsRtcSetEnabled == 1U))
					{
						if(pHan->iOkBounceStart == 0)
						{
							pHan->iOkBounceStartTime  = GPT_GetCurrentTimerCount(SWITCHPROC_GPTIMER);
							pHan->iOkBounceStart = 1;
						}
						iTimeDiff = SwitchProc_GetTimeDiff(pHan, pHan->iOkBounceStartTime);
						if (iTimeDiff >= BUTTON_RTC_MS)
						{
							pHan->bIsRtcTimeStarted = 1U;
							SwitchProc_SendInfoToRtcProc(pHan, (uint8_t)eRtc_State);
						}
						pHan->iOkBounceStart = 0U;
					}
				}
				else if (pHan->sNav.iModeSel == eNavSel_SpeedUnit)
				{
					if(pHan->iOkBounceStart == 0)
					{
						pHan->iOkBounceStartTime  = GPT_GetCurrentTimerCount(SWITCHPROC_GPTIMER);
						pHan->iOkBounceStart = 1;
					}
					if (pHan->iSpeedUnit == 0)
					{
						pHan->iSpeedUnit = 1;
					}
					else
					{
						pHan->iSpeedUnit = 0;
					}

					pHan->sNav.iVal = eKey_Ok;
					pHan->sNav.iModeVal = pHan->iSpeedUnit;

					Cluster_Controller_Manager_CanProc_UpdateUnit(pHan->iSpeedUnit);

					SwitchProc_SendNavigIndicatorInfo(pHan);


				}
				else if (pHan->sNav.iModeSel == eNavSel_Odo)
				{
					if(pHan->iOkBounceStart == 0)
					{
						pHan->iOkBounceStartTime  = GPT_GetCurrentTimerCount(SWITCHPROC_GPTIMER);
						pHan->iOkBounceStart = 1;
					}
					pHan->sNav.iModeVal = eNavSel_Odo;
					pHan->sNav.iVal = eKey_Ok;
					SwitchProc_SendNavigIndicatorInfo(pHan);
				}
				else if (pHan->sNav.iModeSel == eNavSel_TripA)
				{
					if (pHan->bIsTripResetEnabled == 1U)
					{

						iTimeDiff = SwitchProc_GetTimeDiff(pHan, pHan->iTripStartTime);

						if (iTimeDiff >= BUTTON_HOLD_MS)
						{
							Cluster_Controller_Manager_CanProc_ResetTrip(0);
						}
						else
						{
							pHan->sNav.iModeVal = eSelect_TripA;
							pHan->sNav.iVal = eKey_Ok;
							SwitchProc_SendNavigIndicatorInfo(pHan);
						}
					}
				}
				else if (pHan->sNav.iModeSel == eNavSel_TripB)
				{
					if (pHan->bIsTripResetEnabled == 1U)
					{
						iTimeDiff = SwitchProc_GetTimeDiff(pHan, pHan->iTripStartTime);

						if (iTimeDiff >= BUTTON_HOLD_MS)
						{
							Cluster_Controller_Manager_CanProc_ResetTrip(1);
						}
						else
						{
							pHan->sNav.iModeVal = eSelect_TripB;
							pHan->sNav.iVal = eKey_Ok;
							SwitchProc_SendNavigIndicatorInfo(pHan);
						}
					}
				}

				pHan->bIsTripResetEnabled = 0U;
				pHan->iOkBounceStart = 0U;
			}
		}
	}
	else
	{
		pHan->iOkBounceStart = 0U;
		pHan->bIsTripResetEnabled = 0U;
	}
}

/*----------------------------------------------------------------------------*
 * Function	    :		SwitchProc_Navigation_Process_LeftButton   	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void SwitchProc_Navigation_Process_LeftButton(SwitchProc_t * pHan,uint8_t iSwStatus)
{
	uint32_t iTimeDiff = 0;

	if((pHan->iCurStructCode & (uint32_t)(eKey_Left)) == 0)
	{
		uint8_t iStatus  = iSwStatus & eKey_Left;

		if((pHan->iCurNavgStatus & eKey_Left)  != iStatus)
		{
			if(iStatus == eKey_Left)
			{
				if(pHan->iLeftBounceStart == 0)
				{
					pHan->iLeftBounceStartTime  = GPT_GetCurrentTimerCount(SWITCHPROC_GPTIMER);
					SwitchProc_SendInfoToRtcProc(pHan,(uint8_t)(eRtc_Param));
					pHan->iLeftBounceStart = 1;
				}
				else
				{
					iTimeDiff =  SwitchProc_GetTimeDiff(pHan,pHan->iLeftBounceStartTime);
					if(iTimeDiff >= BUTTON_REPEAT_MS)
					{
						SwitchProc_SendInfoToRtcProc(pHan,(uint8_t)(eRtc_Param));
						pHan->iLeftBounceStartTime = GPT_GetCurrentTimerCount(SWITCHPROC_GPTIMER);
					}
				}
			}
		}
	}
	else
	{
		pHan->bIsTripResetEnabled = false;
	}
}
#endif

/*----------------------------------------------------------------------------*
 * Function	    :			SwitchProc_CheckSwitchStuck	        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void SwitchProc_CheckSwitchStuck(SwitchProc_t *pHan, uint8_t iSwStatus)
{
	uint8_t iKeyval = 0x01;
	int32_t iCurKeyStatus = 0;

	if(pHan->bIsIgnitionOn == 0)
	{
		pHan->sTimer[0].bIsTimerEnabled = 0;
		pHan->sTimer[1].bIsTimerEnabled = 0;
		pHan->sTimer[2].bIsTimerEnabled = 0;
	}
	else
	{
		pHan->sKeyAlertInfo.iCode = 0;

		for(int i = 0; i < NAV_SWITCH_COUNT; i++)
		{
			iCurKeyStatus = (iSwStatus & (iKeyval << i));
			if(iCurKeyStatus)
			{
				if(pHan->sTimer[i].bIsTimerEnabled == 0)
				{
					pHan->sTimer[i].iRefTime = GPT_GetCurrentTimerCount(SWITCHPROC_GPTIMER);
					pHan->sTimer[i].bIsTimerEnabled = 1;
				}
				else
				{
					uint32_t iTimeDiff = 0;
					iTimeDiff = SwitchProc_GetTimeDiff(pHan,pHan->sTimer[i].iRefTime);
					if(iTimeDiff >= BUTTON_STUCK_MS)
					{

						switch(i)
						{
#if NAV_MULTIFUNCTION == 0
							case 0:
							{
								pHan->sKeyAlertInfo.iCode |= (uint32_t)(eKey_Left);
							}
							break;
#endif
							case 1:
							{
								pHan->sKeyAlertInfo.iCode |= (uint32_t)(eKey_Ok);
							}
							break;
							case 2:
							{
								pHan->sKeyAlertInfo.iCode |= (uint32_t)(eKey_Right);
							}
							break;
							default:
								break;
						}

					}
				}
			}
			else
			{
				pHan->sTimer[i].bIsTimerEnabled = 0;
			}
		}
		SwitchProc_UpdateSwitchStruckStatus(pHan);
	}
}
