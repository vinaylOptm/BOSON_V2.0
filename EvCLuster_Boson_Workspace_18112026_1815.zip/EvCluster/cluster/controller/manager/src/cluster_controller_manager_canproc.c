/*-----------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										   *
 *	Copyright (C) OptM Media Solutions Pvt Ltd - All Rights Reserved.	   	   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from OptM Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_controller_manager_canproc.c					   *
 *  version		: 											              	   *
 *  Date		:	03-Mar-2023												   *
 *  Description :  				 										 	   *
 *                               						                       *
 *-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------*
 * Include Headers				           	                             	   *
 *-----------------------------------------------------------------------------*/
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
#include "timers.h"
#include "fsl_debug_console.h"
#include "clock_config.h"
#include "fsl_flexcan.h"
#include "fsl_gpt.h"
#include "cluster_common.h"
#include "cluster_controller_hal.h"
#include "cluster_controller_hal_can.h"
#include "cluster_controller_manager_canproc.h"
#include "cluster_controller_manager_systeminfo.h"
#include "cluster_controller_manager_rtcproc.h"
#include "cluster_controller_manager_switchproc.h"

/*----------------------------------------------------------------------------*
 * Macro ,Structure and Enum definitions                        				  *
 *-----------------------------------------------------------------------------*/
#define CAN_MAX_QUEUE_MSG_COUNT			(150U)
#define CAN_MSG_BUFFER_SIZE				sizeof(sCanMsg_t)
#define MSG_RECEIVE_INIT_WAIT			(2000U)
#define READY_STATE_WAIT_TIME           (3000U)
#define MSG_RECEIVE_ERROR_WAIT          (10000U)
#define MSG_RECEIVE_DEFAULT_WAIT		(5000U)
#define MSG_SEND_DEFAULT_WAIT			(5000U)
#define CAN_SEND_MBID					(25U)
#define SPEED_CACHE_SIZE				(2U)

#define CANPROC_GPTIMER                 GPT1

#define FLASH_MODE                      0xF1
#define RTC_SET_TIME                    0xF2
#define FACTORY_RESET                   0xF3
#define BACKLIGHT_SET                   0xF4
#define READ_SWHW_VERSION               0xF6
#define VINFO_WRITE_START           	0xF8
#define VINFO_WRITE_CONTINUE			0xF9
#define VINFO_WRITE_END     			0xFA
#define VINFO_READ     			        0xFB
#define PRODUCT_SWHW_VERSION            0xF7
#define SET_ODO                         0xFE
#define SLN_NUMBER                      0x01
#define VINFO_READ_CONTINUE  				0xFC
#define VINFO_READ_END       				0xFD
#define SET_ODO                             0xFE


#define UIUPDATE_MAX_QUEUE_COUNT		(5U)
#define UIUPDATE_BUFFER_SIZE			(256U)
#define UIUPDATE_QUEUE_BUFFER_SIZE 		(UIUPDATE_BUFFER_SIZE + 16U)


#define OBD_CODE_STR_SIZE   			(6U)
#define OBD_MSG_MAX_LEN     			(16U)
#define OBD_CODE_DATA_LEN   			(5U)

#define UPDATE_STATE_SPEED       		(0U)
#define UPDATE_STATE_CHARGE      		(1U)
//#define UPDATE_STATE_BATTERY     		(2U)
#define UPDATE_STATE_STATUS0     		(2U)
#define UPDATE_STATE_DRIVE  	 		(3U)
#define UPDATE_STATE_OBD         		(4U)
#define UPDATE_STATE_MAX         		(5U)
#define DATA_IDX_NEW         			(0U)
#define DATA_IDX_CUR         			(1U)


#define SLN_NUMBER                           0x01
#define VIN                                 0x02
#define DATE                                0x04


typedef struct
{
	bool	        	bIsOdoCached;
	bool				bCanError;
	bool                bIsResetDist;
	bool     			bInitialised;
	bool     			bScreenOnCmd;
	uint8_t             iCurIgnStatus;
	uint8_t             sInfoCacheData[32];
	uint32_t			iOnCount;
	uint8_t				iMode;
	uint32_t			iSpeedUnit;
	uint32_t 			iGearMode;
	uint32_t			iDriveMode;
	uint32_t  			iCurTime;
	uint32_t   			iPrevTime;
	uint32_t	        iCurIndex;
	uint32_t			iSpeed[SPEED_CACHE_SIZE];
	uint64_t			iTimeOffset[SPEED_CACHE_SIZE];
	uint64_t			iCurTripA;
	uint64_t			iCurTripB;
	uint64_t 			iCurOdo;
	uint64_t 			iCurOdoA;
	uint64_t 			iCurOdoB;
	uint64_t 			iInitialOdo;
	uint64_t 			iInitialOdoA;
	uint64_t 			iInitialOdoB;
	uint64_t 			iPrevOdo;
	uint64_t 			iPrevOdoA;
	uint64_t 			iPrevOdoB;
	uint64_t 			iCurOdoDiff;
	QueueHandle_t		qCmdMsg;
	QueueHandle_t   	qRxMsg;
	QueueHandle_t   	qHmiMsg;
	QueueHandle_t   	qUpdateMsg;
	TaskHandle_t 		hUpdateThread;
	TaskHandle_t 		hRxThread;
	TaskHandle_t 		hCmdThread;
	sDeviceInfo_t       sSysInfo;
	sStatus0_t			sStatus0[2];
	sMotorInfo_t 		sMotor[2];
	sDriveMode_t  		sDriveMode[2];
	sMultiFault_t		sObd[2];
	sChargeInfo_t     	sCharge[2];
	sBatteryInfo_t 		sBattery[2];

	sDeviceInfo_t       sSysInfoCache;
}CanProc_t;
/*----------------------------------------------------------------------------*
 * Static and global variaCan definition	                         		  *
 *----------------------------------------------------------------------------*/
static CanProc_t hCanProc = {0};
/*----------------------------------------------------------------------------*
 * Local function definition	                         				      *
 *----------------------------------------------------------------------------*/
static void CanProc_CleanUp(void* arg);
static void CanProc_TimerConfigure(void);
static void CanProc_DataHandler(void *arg);
static int32_t CanProc_ProductionReset(void);
static void CanProc_UIUpdateHandler(void *args);
static void CanProc_SendObdInfo(CanProc_t* pHan);
static void CanProc_SendCommandHandler(void *arg);
static uint32_t CanProc_GetCurrentTimestamp(void);
static int32_t CanProc_SetOdoInfo(CanProc_t* pHan);
static void CanProc_SendMotorInfo(CanProc_t* pHan);
static void CanProc_Send_DummyData(CanProc_t* pHan);
static void CanProc_SendStatus0Info(CanProc_t* pHan);
static void CanProc_SendChargingInfo(CanProc_t* pHan);
static int32_t CanProc_UpdateDistance(CanProc_t* pHan);
static int32_t CanProc_GetCachedData(CanProc_t* pHan);
static int32_t CanProc_UpdateChargeInfo(CanProc_t* pHan);
static int32_t CanProc_UpdateStatus0Info(CanProc_t * pHan);
static int32_t CanProc_UpdateDriveModeInfo(CanProc_t* pHan);
static int32_t CanProc_ResetDistanceParams(CanProc_t* pHan);
static int32_t CanProc_CalculateSpeedParams(CanProc_t* pHan);
static int  CanProc_ComposeRespCommnd(uint8_t * pCmd, void * vpData);
static void CanProc_TripReset(CanProc_t* pHan,uint8_t iSelTrip);
static void CanProc_UpdateSystemInfo(CanProc_t* pHan, uint32_t iMode);
static int32_t CanProc_UpdateSpeedInfo(CanProc_t* pHan, uint32_t iMode);
static void CanProc_DataParse(CanProc_t * pHan, flexcan_frame_t* pMsg);
static void CanProc_UpdateInfo(CanProc_t* pHan, uint64_t iOdoDiff,uint32_t iMode);
static void CanProc_SendTextMsgInfo(CanProc_t* pHan, eAlertId_t iId, uint32_t iCode);
static int32_t CanProc_PackVCUInfo(CanProc_t * pHan);
static int32_t CanProc_ProcessNavKeyInfo(CanProc_t* pHan, uint8_t iKey, uint8_t iStatus);
static int32_t  CanProc_SendCommand(int32_t iCanId,uint32_t iLen,uint8_t *pdata,
									uint8_t mbIdx,uint8_t iFormat);
//  Customer specific
static void CanProc_ProcessStatus0(CanProc_t* pHan ,flexcan_frame_t* pFrame);
static void CanProc_ProcessObdMsg0(CanProc_t* pHan ,flexcan_frame_t* pFrame);
static void CanProc_ProcessObdMsg1(CanProc_t* pHan ,flexcan_frame_t* pFrame);
static void CanProc_ProcessObdHeader(CanProc_t* pHan ,flexcan_frame_t* pFrame);
static void CanProc_ProcessChargeInfo(CanProc_t* pHan ,flexcan_frame_t* pFrame);
static void CanProc_ProcessDriveModeInfo(CanProc_t* pHan ,flexcan_frame_t* pFrame);
static void CanProc_ResetAllData(CanProc_t* pHan);
static void CanProc_Buzzer_Update(CanProc_t* pHan,flexcan_frame_t* pFrame);
#if CLUSTER_SWITCH_WAKE
static void CanProc_UpdateSleepMode(CanProc_t* pHan);
#endif
/*----------------------------------------------------------------------------*
 * Function	    :		Cluster_Controller_Manager_CanProc_Init    	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_Init(QueueHandle_t hAppQueueId)
{
	int32_t iRval = BCU_OK;
	BaseType_t iTaskRetval = 0;
	if(hCanProc.bInitialised == 0)
	{
		memset(&hCanProc, 0 ,sizeof(hCanProc));

		hCanProc.qHmiMsg = hAppQueueId;

		hCanProc.qRxMsg = xQueueCreate( CAN_MAX_QUEUE_MSG_COUNT,
										CAN_MSG_BUFFER_SIZE);

		hCanProc.qCmdMsg = xQueueCreate(1,8);
		if((hCanProc.qRxMsg != 0) && (hCanProc.qCmdMsg != 0))
		{
			uint16_t iStackSize = 0;

			Cluster_Controller_Hal_ConfigGetStackSize(&iStackSize);

			iTaskRetval = xTaskCreate( CanProc_DataHandler,
										"CANP",
										iStackSize*2,
										&hCanProc, CLUSTER_TASK_PRIORITY_DATA,
										&hCanProc.hRxThread);
			if (iTaskRetval == pdPASS)
			{
				iTaskRetval = xTaskCreate(CanProc_SendCommandHandler,
											"SCMD",
											iStackSize,
											&hCanProc,
											CLUSTER_TASK_PRIORITY_BACKGROUND,
											&hCanProc.hCmdThread);
				hCanProc.qUpdateMsg = xQueueCreate(UIUPDATE_MAX_QUEUE_COUNT, UIUPDATE_QUEUE_BUFFER_SIZE);

				iTaskRetval = xTaskCreate(CanProc_UIUpdateHandler,
											"UPDATE",
											iStackSize*2,
											&hCanProc,
											CLUSTER_TASK_PRIORITY_BACKGROUND,
											&hCanProc.hUpdateThread);

				if (iTaskRetval == pdPASS)
				{
					hCanProc.bInitialised = 1;
					CanProc_TimerConfigure();
				}
				else
				{
					iRval = BCU_NOK;
					Cluster_Controller_Manager_CanProc_DeInit();
					PRINTF("\r\nError: CanProc_DataHandler: Thread create failed \r\n");
				}
			}
			else
			{
				iRval = BCU_NOK;
				Cluster_Controller_Manager_CanProc_DeInit();
				PRINTF("\r\nError: CanProc_DataHandler: Thread create failed \r\n");
			}
		}
		else
		{
			iRval = BCU_NOK;
			PRINTF("\r\nError:CanProc: xQueueCreate  failed \r\n");
		}
	}
	return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	    :		Cluster_Controller_Manager_CanProc_DeInit	 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
void Cluster_Controller_Manager_CanProc_DeInit(void)
{
	if(hCanProc.bInitialised)
	{
		vTaskSuspend(hCanProc.hRxThread);
		CanProc_CleanUp(NULL);
	}
	memset(&hCanProc, 0, sizeof(CanProc_t));
}
/*----------------------------------------------------------------------------*
 * Function	    :		Cluster_Controller_Manager_CanProc_Stop		 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_Start(void)
{
	int32_t iRval = BCU_NOK;

	if((hCanProc.bInitialised) && (hCanProc.qRxMsg != NULL))
	{
		iRval = Cluster_Controller_Hal_SetReceiveQueueHandle(eModule_Can ,
				hCanProc.qRxMsg);
	}
	return  iRval;
}
/*----------------------------------------------------------------------------*
 * Function	    :		Cluster_Controller_Manager_CanProc_Stop		 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_Stop(void)
{
	return 0;
}

/*------------------------------------------------------------------------------*
 * Function	    :  		Cluster_Controller_Manager_CanProc_IngStatus			*
 * Params	    :		Void			                                      	*
 * Return value	:		Void		                                            *
 * Description	:																*
 *                                                                              *
 *------------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_IgnitionStatus(uint8_t iStatus)
{
	int32_t iRval = BCU_OK;

	if (hCanProc.bInitialised)
	{
		if (hCanProc.iCurIgnStatus != iStatus)
		{
#if 0
			uint64_t iOdoDiff = (uint64_t)((hCanProc.iCurOdo - hCanProc.iPrevOdo)/100ULL);

			if ((iStatus == 0) && (hCanProc.iCurIgnStatus == 1) && (iOdoDiff > 300))
			{
				//CanProc_UpdateSystemInfo(&hCanProc,eSpeedInfo);
				PRINTF("\r\n Ignition off: iOdoDiff : %d \r\n",iOdoDiff);
			}
#endif
			hCanProc.iCurIgnStatus = iStatus;
		}
	}
	return iRval;

}
/*------------------------------------------------------------------------------*
 * Function	    :  		Cluster_Controller_Manager_CanProc_UpdateUnit			*
 * Params	    :		Void			                                      	*
 * Return value	:		Void		                                            *
 * Description	:																*
 *                                                                              *
 *------------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_UpdateUnit(uint32_t iUnit)
{
	if(hCanProc.sMotor[DATA_IDX_NEW].iSpeedUnit != iUnit )
	{
		hCanProc.sMotor[DATA_IDX_NEW].iSpeedUnit = iUnit;
		CanProc_UpdateSystemInfo(&hCanProc,eSpeedInfo);
		CanProc_SendMotorInfo(&hCanProc);
	}
	return 0;
}
/*------------------------------------------------------------------------------*
 * Function	    :  		Cluster_Controller_Manager_CanProc_ResetTrip			*
 * Params	    :		Void			                                      	*
 * Return value	:		Void		                                            *
 * Description	:																*
 *                                                                              *
 *------------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_ResetTrip(uint8_t iSelTrip)
{
	int32_t iRval = BCU_OK;
	if(hCanProc.bInitialised)
	{
		CanProc_TripReset(&hCanProc,iSelTrip);
	}
	return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	Cluster_Controller_Manager_CanProc_SendButtonInfo		    		          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/

int32_t Cluster_Controller_Manager_CanProc_UpdateNavKeyInfo(uint8_t iKey,uint8_t iStatus)
{
	int32_t iRval = BCU_OK;
	if(hCanProc.bInitialised)
	{
		CanProc_ProcessNavKeyInfo(&hCanProc,iKey,iStatus);
	}
	return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	Cluster_Controller_Manager_CanProc_ProductionReset		    		          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_CanProc_ProductionReset(void)
{
	return CanProc_ProductionReset();
}


/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_TimerConfigure				          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_TimerConfigure()
{
	gpt_config_t gptConfig = {
			.clockSource = kGPT_ClockSource_Periph,
			.divider = 1,
			.enableRunInStop = false,
			.enableMode =true
	};

	GPT_Init(CANPROC_GPTIMER, &gptConfig);
	GPT_StopTimer(CANPROC_GPTIMER);
	GPT_StartTimer(CANPROC_GPTIMER); /*start timer*/
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_DataHandler						          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_DataHandler(void *arg)
{
	int32_t iDelay = READY_STATE_WAIT_TIME;
	int32_t iRval = BCU_NOK;
	CanProc_t *  pHan = (CanProc_t *)(arg);

	int32_t iCount  = 0;
	sCanMsg_t sMsg;

	CanProc_ResetDistanceParams(pHan);

	CanProc_Send_DummyData(pHan);
	xQueueReceive(pHan->qRxMsg,(void *)(&sMsg),(TickType_t)(iDelay));
	iRval  = Cluster_Controller_Hal_CanEnable();
	iDelay = MSG_RECEIVE_INIT_WAIT;

	if(iRval == BCU_OK)
	{
		while (1)
		{
			memset(&sMsg, 0, sizeof(sCanMsg_t));
			if(pdPASS == xQueueReceive(pHan->qRxMsg,(void *)(&sMsg),(TickType_t)(iDelay)))
			{
				if(sMsg.iEventId == 0)
				{
					if( pHan->bCanError == 1)
					{
						CanProc_SendTextMsgInfo(pHan,eAlert_CAN,eCAN_Working);
						pHan->bCanError = 0;
						CanProc_ResetDistanceParams(pHan);
					}
					iCount = 0;

					CanProc_DataParse(pHan,&(sMsg.sRxFrame));

					if(pHan->bIsOdoCached == 0)
					{
						CanProc_Send_DummyData(pHan);
					}
					iDelay = MSG_RECEIVE_DEFAULT_WAIT;
				}
				else
				{
					Cluster_Controller_Hal_CanReset(false);
					iDelay = MSG_RECEIVE_ERROR_WAIT;

					if(pHan->bCanError == 0)
					{
						pHan->iCurTime = 0;
						pHan->iPrevTime = 0;
						PRINTF("\r\nCAN ERROR :ID = %d, Code= %d\r\n",sMsg.iErrId,sMsg.iEventId);
						PRINTF("\r\nCAN : HMI Update with reset value \r\n");

						CanProc_ResetAllData(pHan);
						pHan->bIsOdoCached = 1;
						iCount = 1;
						CanProc_SendTextMsgInfo(pHan,eAlert_CAN,eCAN_Error);
					}
					pHan->bCanError = 1;
				}
			}
			else
			{
				if(iDelay != MSG_RECEIVE_ERROR_WAIT)
				{
					if(iCount == 0)
					{
						PRINTF("\r\nCAN : HMI Update with reset value \r\n");
						CanProc_ResetAllData(pHan);
						CanProc_Send_DummyData(pHan);
						pHan->bIsOdoCached = 1;
						iCount = 1;
					}
					CanProc_SendTextMsgInfo(pHan,eAlert_CAN,eCAN_NoData);
					pHan->bCanError = 1;
				}
				iDelay = MSG_RECEIVE_DEFAULT_WAIT;
			}
		}
	}
	else
	{
		CanProc_SendTextMsgInfo(pHan,eAlert_CAN,eCAN_NoData);
		pHan->bCanError = 1;

		PRINTF("\r\n Error: CanProc_DataHandler : Cluster_Controller_Hal_CanEnable Failed\r\n");
	}
}

/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_SendCommandHandler						      *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_SendCommandHandler(void *arg)
{
	CanProc_t *  pHan = (CanProc_t *)(arg);
	flexcan_frame_t rxFrame;
	int32_t iDelay = 100;
	int32_t iRetVal = BCU_OK;

	xQueueReceive(pHan->qCmdMsg,(void *)(&rxFrame),(TickType_t)(4000));
	while (1)
	{
		memset(&rxFrame, 0, sizeof(flexcan_frame_t));

		xQueueReceive(pHan->qCmdMsg,(void *)(&rxFrame),(TickType_t)(iDelay));

		iRetVal = CanProc_PackVCUInfo(pHan);

		if(iRetVal == BCU_OK)
		{
			iDelay = 100;
		}
		else
		{
			iDelay = 1000;
		}
	}
}
/*----------------------------------------------------------------------------*
  Function	      	:	CanProc_ComposeRespCommnd
  Params	    	:
  Return value		:
  Description		:
 *----------------------------------------------------------------------------*/
static int  CanProc_ComposeRespCommnd(uint8_t * pCmd, void * vpData)
{
	int32_t iRval = BCU_NOK;

	uint8_t i = 2;
	uint8_t k = 0;

	if(pCmd[0] != SLN_NUMBER)
	{
		char * pData = (char *)vpData;

		for(uint8_t j = 0; j < 12; j++)
		{
			pCmd[i] = pData[j];

			i += 1;

			if(i == 8)
			{
				i = 2;

				k += 1;

				if(k == 2)
				{
					pCmd[1] = VINFO_READ_END;
				}

				for (uint8_t m = 0; m < 8; m++)
				{
					PRINTF("%02X ", pCmd[m]);
				}

				iRval = CanProc_SendCommand(eCANID_Internal,8,&pCmd[0],15,0);

				if(iRval != BCU_OK)
				{
					PRINTF("\r\nError: CAN_PROC READ_SWHW_VERSION CAN Send failed\r\n");
				}
			}
		}
	}
	else
	{
		uint32_t * pData = (uint32_t *)vpData;

		pCmd[2] = (uint8_t)((*pData >> 24) & 0xFF);
		pCmd[3] = (uint8_t)((*pData >> 16) & 0xFF);
		pCmd[4] = (uint8_t)((*pData >> 8) & 0xFF);
		pCmd[5] = (uint8_t)(*pData & 0xFF);

		for (uint8_t m = 0; m < 8; m++)
		{
			PRINTF("%02X ", pCmd[m]);
		}

		iRval = CanProc_SendCommand(eCANID_Internal,8,&pCmd[0],15,0);

		if(iRval != BCU_OK)
		{
			PRINTF("\r\nError: CAN_PROC READ_SWHW_VERSION CAN Send failed\r\n");
		}
	}
	return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_CleanUp							          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_CleanUp(void* arg)
{
	(void)(arg);
	if(hCanProc.qRxMsg != 0)
	{
		vQueueDelete(hCanProc.qRxMsg);
	}
	if(hCanProc.qCmdMsg != 0)
	{
		vQueueDelete(hCanProc.qCmdMsg);
	}
	if(hCanProc.qUpdateMsg != 0)
	{
		vQueueDelete(hCanProc.qUpdateMsg);
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_DataParse						          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_DataParse(CanProc_t *pHan, flexcan_frame_t *pFrame)
{
    int32_t iRetVal = BCU_OK;
    int32_t iCanId = 0;
    int32_t iLen = 0;

    if (pFrame != NULL)
    {
        if (pFrame->format == kFLEXCAN_FrameFormatStandard)
        {
            iCanId = pFrame->id >> CAN_ID_STD_SHIFT;
        }
        else
        {
            iCanId = pFrame->id >> CAN_ID_EXT_SHIFT;
        }

        iLen = pFrame->length;

        switch (iCanId)
        {
            case eCANID_Frame1:
            {
                if (iLen == 8)
                {
                    if (pHan->bIsOdoCached == 0)
                    {
                        iRetVal = CanProc_GetCachedData(pHan);

                        if (iRetVal == BCU_OK)
                        {
                            pHan->bIsOdoCached = 1;
                        }
                    }

                    pHan->sMotor[DATA_IDX_NEW].iSpeed = (uint32_t)(((pFrame->dataByte1) << 8) | (pFrame->dataByte0));
                    if (pHan->sMotor[DATA_IDX_NEW].iSpeed > 200)
                    {
                    	pHan->sMotor[DATA_IDX_NEW].iSpeed = 200;
                    }

				pHan->sMotor[DATA_IDX_NEW].iSoc   = (uint32_t)(pFrame->dataByte2);
				if(pHan->sMotor[DATA_IDX_NEW].iSoc > 100)
				{
					pHan->sMotor[DATA_IDX_NEW].iSoc = 100;
				}

				CanProc_ProcessChargeInfo(pHan,pFrame);
				CanProc_CalculateSpeedParams(pHan);
			}
		}
		break;
		case eCANID_Frame2:
		{
			if(iLen == 8)
			{
				pHan->sMotor[DATA_IDX_NEW].bOprHrEnable = ((pFrame->dataByte2) & 0x01) ? true : false;
				pHan->sMotor[DATA_IDX_NEW].iOprHrs = (uint32_t)(((pFrame->dataByte1) << 8)|(pFrame->dataByte0));

				pHan->sMotor[DATA_IDX_NEW].iWheelDrive = 0;
				bool  bWdEnable = ((pFrame->dataByte3) & 0x01) ? true : false;

				if(bWdEnable)
				{
					bool bDriveMode0 = ((pFrame->dataByte4) & 0x01) ? true : false;	//4x4 Mode
					bool bDriveMode1 = ((pFrame->dataByte4) & 0x02) ? true : false;	//4x2 Mode

					if(bDriveMode1)
					{
						pHan->sMotor[DATA_IDX_NEW].iWheelDrive = 2;
					}
					else 
					{	
						pHan->sMotor[DATA_IDX_NEW].iWheelDrive = (bDriveMode0)?1:0;
					}					
				}
			}
		}
		break;
		case eCANID_Frame3:
		{
			if(iLen == 8)
			{
				CanProc_Buzzer_Update(pHan,pFrame);
				CanProc_ProcessDriveModeInfo(pHan,pFrame);
				CanProc_ProcessStatus0(pHan ,pFrame);
			}
		}
		break;
		case eCANID_Frame4:
		{
			if(iLen == 8)
			{
				CanProc_ProcessObdHeader(pHan ,pFrame);
			}
		}
		break;
		case eCANID_Frame5:
		{
			if(iLen == 8)
			{
				CanProc_ProcessObdMsg0(pHan ,pFrame);
			}
		}
		break;
		case eCANID_Frame6:
		{
			if(iLen == 8)
			{
				CanProc_ProcessObdMsg1(pHan ,pFrame);
			}
		}
		break;
		case eCANID_Internal:
		{
			if(iLen == 8)
			{
				switch(pFrame->dataByte0)
				{
				case FLASH_MODE:
				{
					Cluster_Controller_Hal_FirmwareDownload_Init();
				}
				break;
				case RTC_SET_TIME:
				{
					sTimeInfo_t sRTCInfo = {0};

					sRTCInfo.iSecond = pFrame->dataByte1;
					sRTCInfo.iMinute = pFrame->dataByte2;
					sRTCInfo.iHour = pFrame->dataByte3;
					sRTCInfo.iDay = pFrame->dataByte4;
					sRTCInfo.iMonth = pFrame->dataByte5;
					sRTCInfo.iYear = pFrame->dataByte6;

					Cluster_Controller_Manager_RtcProc_CheckForValidData(&sRTCInfo);

					PRINTF("\r\n The RTC frame: [%x %x %x %x %x %x]",sRTCInfo.iSecond,sRTCInfo.iMinute,sRTCInfo.iHour,sRTCInfo.iDay,sRTCInfo.iMonth,sRTCInfo.iYear);

					Cluster_Controller_Hal_RtcSetDateTime(&sRTCInfo);
				}
				break;
				case FACTORY_RESET:
				{
					int32_t iRtval = BCU_NOK;

					iRtval = CanProc_ProductionReset();
					if(iRtval == BCU_OK)
					{
						pHan->sMotor[DATA_IDX_NEW].iTripA = 0;
						pHan->sMotor[DATA_IDX_NEW].iTripB = 0;
						pHan->sMotor[DATA_IDX_NEW].iOdo  = 0;
						pHan->iInitialOdo  = 0;
						pHan->iInitialOdoA = 0;
						pHan->iInitialOdoB = 0;
						pHan->iPrevOdo 	   = 0;
						pHan->iPrevOdoA    = 0;
						pHan->iPrevOdoB    = 0;
						pHan->iCurOdo 	   = 0;
						pHan->iCurOdoA 	   = 0;
						pHan->iCurOdoB 	   = 0;
						pHan->iCurTripA    = 0;
						pHan->iCurTripB    = 0;
						pHan->iSpeedUnit   = 0;
						CanProc_ResetDistanceParams(pHan);
						CanProc_SendMotorInfo(pHan);
						PRINTF("\r\nThe Production Reset successful\r\n");
					}
				}
				break;
				case BACKLIGHT_SET:
				{
#if ENABLE_PWM_CONTROL
					uint32_t iRval = BCU_NOK;
					sClusterInfo_t sUpdateinfo = {0};

					sUpdateinfo.iBrightness = pFrame->dataByte1;

					iRval = Cluster_Controller_UpdateSystemInfo(&sUpdateinfo, eBrightnessInfo);
					if(iRval == BCU_OK)
					{
						Cluster_Controller_Hal_BacklightSetBrightness(sUpdateinfo.iBrightness);
					}
#endif
				}
				break;
				case READ_SWHW_VERSION:
				{
					int32_t iRval = BCU_NOK;
					uint8_t sData[8] = {0};
					uint32_t iSwVersion = 0;
					uint32_t iHwVersion = 0;
					Cluster_Controller_Hal_ConfigGetVersion(&iSwVersion, &iHwVersion);
					sData[0] = (uint8_t)iSwVersion;
					sData[1] = (uint8_t)iHwVersion;
					iRval = CanProc_SendCommand(eCANID_Internal,8,&sData[0],15,0);
					if(iRval != BCU_OK)
					{
						PRINTF("\r\nError: CAN_PROC READ_SWHW_VERSION CAN Send failed\r\n");
					}
				}
				break;
				case VINFO_WRITE_START:
				{
					Cluster_Controller_Manager_SystemInfo_GetVehicleSpecInfo(&(pHan->sSysInfoCache));
					pHan->sInfoCacheData[0] = pFrame->dataByte2;
					pHan->sInfoCacheData[1] = pFrame->dataByte3;
					pHan->sInfoCacheData[2] = pFrame->dataByte4;
					pHan->sInfoCacheData[3] = pFrame->dataByte5;
					pHan->sInfoCacheData[4] = pFrame->dataByte6;
					pHan->sInfoCacheData[5] = pFrame->dataByte7;
				}
				break;
				case VINFO_WRITE_CONTINUE:
				case VINFO_WRITE_END:
				{
					pHan->sInfoCacheData[6] = pFrame->dataByte2;
					pHan->sInfoCacheData[7] = pFrame->dataByte3;
					pHan->sInfoCacheData[8] = pFrame->dataByte4;
					pHan->sInfoCacheData[9] = pFrame->dataByte5;
					pHan->sInfoCacheData[10] = pFrame->dataByte6;
					pHan->sInfoCacheData[11] = pFrame->dataByte7;

					memcpy(&(pHan->sSysInfo),&(pHan->sSysInfoCache),sizeof(pHan->sSysInfo));

					if(pFrame->dataByte1 & SLN_NUMBER) //SlNum.
					{
						pHan->sSysInfo.iSlNum = ((uint32_t)pHan->sInfoCacheData[3] << 24) |
								((uint32_t)pHan->sInfoCacheData[2] << 16) |
								((uint32_t)pHan->sInfoCacheData[1] << 8)  |
								(uint32_t)pHan->sInfoCacheData[0];

						pHan->sSysInfoCache.iSlNum = pHan->sSysInfo.iSlNum;

						/*memcpy(pHan->sSysInfo.iSlNum,pHan->sInfoCacheData, sizeof(pHan->sSysInfo.iSlNum));

											memcpy(pHan->sSysInfoCache.iSlNum,pHan->sSysInfo.iSlNum, sizeof(pHan->sSysInfo.iSlNum));*/

					}
					else if(pFrame->dataByte1 & VIN) //VIN.
					{
						memcpy(pHan->sSysInfo.sVin, pHan->sInfoCacheData, sizeof(pHan->sSysInfo.sVin));

						memcpy(pHan->sSysInfoCache.sVin,pHan->sSysInfo.sVin, sizeof(pHan->sSysInfo.sVin));
					}

					Cluster_Controller_Manager_SystemInfo_SetVehicleSpecInfo(&(pHan->sSysInfo), eProductInfo);

					memset(&(pHan->sSysInfo), 0 , sizeof(pHan->sSysInfo));
					memset(pHan->sInfoCacheData, 0 , sizeof(pHan->sInfoCacheData));
				}
				break;
				case VINFO_READ:
				{
					uint8_t sData[8] = {0};

					sDeviceInfo_t sInfo = {0};

					Cluster_Controller_Manager_SystemInfo_GetVehicleSpecInfo(&sInfo);

					if((sInfo.iSlNum == 0xFFFFFFFF) && ((unsigned char) sInfo.sVin[0] == 0xFF))
					{
						DbgConsole_Printf("\r\nThe Device is New Set the Device details\r\n");
					}
					else
					{
						if((pFrame->dataByte1 & SLN_NUMBER) == SLN_NUMBER)
						{
							sData[0] = SLN_NUMBER;
							sData[1] = VINFO_READ_END;

							CanProc_ComposeRespCommnd(sData,&sInfo.iSlNum);
						}
						else if((pFrame->dataByte1 & VIN) == VIN)
						{
							sData[0] = VIN;
							sData[1] = VINFO_READ_CONTINUE;

							CanProc_ComposeRespCommnd(sData,sInfo.sVin);
						}
					}
				}
				break;
				case SET_ODO:
				{
					pHan->sMotor[DATA_IDX_NEW].iOdo = (uint32_t)(
							((uint32_t)(pFrame->dataByte4) << 24) |
							((uint32_t)(pFrame->dataByte3) << 16) |
							((uint32_t)(pFrame->dataByte2) << 8) |
							(uint32_t)(pFrame->dataByte1)
					);
					pHan->iInitialOdo  		= (uint64_t)(pHan->sMotor[DATA_IDX_NEW].iOdo * 100ULL);
					pHan->iPrevOdo 	   		= (uint64_t)(pHan->iInitialOdo);
					pHan->iCurOdo 	   		= (uint64_t)(pHan->iInitialOdo);
					pHan->iInitialOdoA  	= (uint64_t)(pHan->iInitialOdo);
					pHan->iPrevOdoA 	   	= (uint64_t)(pHan->iInitialOdo);
					pHan->iCurOdoA 	   		= (uint64_t)(pHan->iInitialOdo);
					pHan->iInitialOdoB  	= (uint64_t)(pHan->iInitialOdo);
					pHan->iPrevOdoB 	   	= (uint64_t)(pHan->iInitialOdo);
					pHan->iCurOdoB 	   		= (uint64_t)(pHan->iInitialOdo);
					pHan->iCurTripA 		= (uint64_t)(pHan->sMotor[DATA_IDX_NEW].iTripA*100ULL);
					pHan->iCurTripB 		= (uint64_t)(pHan->sMotor[DATA_IDX_NEW].iTripB*100ULL);
					CanProc_SetOdoInfo(pHan);
					CanProc_SendMotorInfo(pHan);
				}
				break;
				default:
					break;
				}
			}
		}
		break;

		default:
			PRINTF("\r\n DataParse Default CAN ID: 0x%x\r\n",iCanId);
			break;
		}
	}
}
/*----------------------------------------------------------------------------*
  Function	      	:	CanProc_ProcessChargeInfo
  Params	    	:

  Return value		:
  Description		:
 *----------------------------------------------------------------------------*/
static void  CanProc_ProcessChargeInfo(CanProc_t* pHan ,flexcan_frame_t* pFrame)
{
	uint32_t iHours = (uint32_t)(pFrame->dataByte4);

	if(iHours > 23)
	{
		iHours = 23;
	}

	uint32_t iMinutes = (uint32_t)(pFrame->dataByte5);
	if(iMinutes > 59)
	{
		iMinutes = 59;
	}
	pHan->sCharge[DATA_IDX_NEW].iTime  = (uint32_t)((iHours*60)+iMinutes);

	pHan->sCharge[DATA_IDX_NEW].bTtcEnable = ((pFrame->dataByte3) & 0x08) ? true : false;
	pHan->sCharge[DATA_IDX_NEW].bLowSoc  = ((pFrame->dataByte3) & 0x10) ? true : false;
	pHan->sCharge[DATA_IDX_NEW].bChargeEnable  = ((pFrame->dataByte3) & 0x01) ? true : false;

	if(pFrame->dataByte3 & 0x04)
	{
		pHan->sCharge[DATA_IDX_NEW].iStatus = eChargestate_Complete;
	}
	else if (pFrame->dataByte3 & 0x02)
	{
		pHan->sCharge[DATA_IDX_NEW].iStatus = eChargestate_Charging;
	}
	else
	{
		pHan->sCharge[DATA_IDX_NEW].iStatus = eChargestate_Idle;
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateChargeInfo			          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int32_t CanProc_UpdateChargeInfo(CanProc_t* pHan)
{
	int32_t iRetVal =0;
	if((pHan->sCharge[DATA_IDX_CUR].iStatus != pHan->sCharge[DATA_IDX_NEW].iStatus) ||
			(pHan->sCharge[DATA_IDX_CUR].iTime != pHan->sCharge[DATA_IDX_NEW].iTime) ||
			(pHan->sCharge[DATA_IDX_CUR].bTtcEnable != pHan->sCharge[DATA_IDX_NEW].bTtcEnable) ||
			(pHan->sCharge[DATA_IDX_CUR].bLowSoc != pHan->sCharge[DATA_IDX_NEW].bLowSoc) ||
			(pHan->sCharge[DATA_IDX_CUR].bChargeEnable != pHan->sCharge[DATA_IDX_NEW].bChargeEnable) ||
			(pHan->sCharge[DATA_IDX_NEW].iCount > 100))
	{
		pHan->sCharge[DATA_IDX_NEW].iCount = 0;
		pHan->sCharge[DATA_IDX_CUR] = pHan->sCharge[DATA_IDX_NEW];

		CanProc_SendChargingInfo(pHan);
		iRetVal = 1;
	}
	else
	{
		pHan->sCharge[DATA_IDX_NEW].iCount = pHan->sCharge[DATA_IDX_NEW].iCount + 1;
	}
	return iRetVal;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_SendChargingInfo			          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_SendChargingInfo(CanProc_t* pHan)
{
	sMessage_t	  sMsg		= {0};

	if(pHan->qHmiMsg != NULL)
	{
		sMsg.iEventId 			= eEvent_Charge;
		memcpy((char *)sMsg.sData,(char*)(&(pHan->sCharge[DATA_IDX_NEW])),sizeof(sChargeInfo_t));
		xQueueSend(pHan->qHmiMsg, &sMsg, pdMS_TO_TICKS(1000U));  
	}
}

/*----------------------------------------------------------------------------*
 * Function	    :		CanProc_Buzzer_Update		        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void CanProc_Buzzer_Update(CanProc_t* pHan,flexcan_frame_t* pFrame)
{
	bool bEnable = ((pFrame->dataByte4) & 0x01) ? true:false;

	if(bEnable)
	{
		uint8_t iMode = (uint8_t)((pFrame->dataByte4 >> 1) & 0x7F);

		if(iMode != pHan->iMode)
		{
			uint32_t iDuration = 1000;
			switch( iMode)
			{
				case 1:
					iDuration = 0;		//Continuous
				break;
				case 2:
					iDuration = 1000;	//1kHz
				break;
				case 3:
					iDuration = 2000;	//2kHz
				break;
				default:
					iDuration = 0;		//Continuous
				break;
			}

			Cluster_Controller_Hal_BuzzerEnable(1,1,iDuration,0);
			pHan->iMode = iMode;
		}
	}
	else
	{
		Cluster_Controller_Hal_BuzzerEnable(0,0,0,0);
		pHan->iMode = 0xFF;
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_Process_UpdateGearMode				          *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_ProcessDriveModeInfo(CanProc_t* pHan ,flexcan_frame_t* pFrame)
{
	uint32_t iGearVal  = (uint32_t)(pFrame->dataByte0 & 0x07);  // byte0: bit 0,1,2
	uint32_t iDriveVal = (uint32_t)(pFrame->dataByte6 & 0x03); // byte6: bit 0,1

	if (pHan->iDriveMode != iDriveVal)
	{
		//DriveMode
		switch (iDriveVal)
		{
			case 0x00:
			{
				pHan->sDriveMode[DATA_IDX_NEW].iDriveVal = eDriveMode_None;
			}
			break;
			case 0x01:
			{
				pHan->sDriveMode[DATA_IDX_NEW].iDriveVal = eDriveMode_Eco;
			}
			break;
			case 0x02:
			{
				pHan->sDriveMode[DATA_IDX_NEW].iDriveVal = eDriveMode_Power;
			}
			break;
			default:
			{
				pHan->sDriveMode[DATA_IDX_NEW].iDriveVal = eDriveMode_Invalid;
			}
			break;
		}
		pHan->iDriveMode = iDriveVal;
	}
	if(pHan->iGearMode != iGearVal)
	{
		//GearMode
		switch (iGearVal)
		{
			case 0x00:
			{
				pHan->sDriveMode[DATA_IDX_NEW].iGearVal = eGearmode_None;
			}
			break;
			case 0x01:
			{
				pHan->sDriveMode[DATA_IDX_NEW].iGearVal = eGearmode_Forward;	//Drive
			}
			break;
			case 0x02:
			{
				pHan->sDriveMode[DATA_IDX_NEW].iGearVal = eGearmode_Reverse;
			}
			break;
			case 0x04:
			{
				pHan->sDriveMode[DATA_IDX_NEW].iGearVal = eGearmode_Neutral;
			}
			break;
			default:
			{
				pHan->sDriveMode[DATA_IDX_NEW].iGearVal = eGearmode_Invalid;
			}
			break;
		}
		pHan->iGearMode = iGearVal;
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateDriveModeInfo				        		  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int32_t CanProc_UpdateDriveModeInfo(CanProc_t* pHan)
{
	int32_t iRetVal =0;
	if((pHan->sDriveMode[DATA_IDX_CUR].iGearVal != pHan->sDriveMode[DATA_IDX_NEW].iGearVal) ||
	   (pHan->sDriveMode[DATA_IDX_CUR].iDriveVal != pHan->sDriveMode[DATA_IDX_NEW].iDriveVal) ||
	   (pHan->sDriveMode[DATA_IDX_NEW].iCount > 100))
	{
		pHan->sDriveMode[DATA_IDX_NEW].iCount = 0;
		pHan->sDriveMode[DATA_IDX_CUR] = pHan->sDriveMode[DATA_IDX_NEW];

		sMessage_t	  sMsg		= {0};
		if(pHan->qHmiMsg != NULL)
		{
			sMsg.iEventId 			= eEvent_DriveMode;
			memcpy((char *)sMsg.sData,(char*)(&(pHan->sDriveMode)),sizeof(sDriveMode_t));
			xQueueSend(pHan->qHmiMsg, &sMsg, (TickType_t)(MSG_SEND_DEFAULT_WAIT));
		}
		iRetVal = 1;
	}
	else
	{
		pHan->sDriveMode[DATA_IDX_NEW].iCount = pHan->sDriveMode[DATA_IDX_NEW].iCount + 1;
	}
	return iRetVal;
}

/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateSpeedInfo				        		  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int32_t CanProc_UpdateSpeedInfo(CanProc_t* pHan, uint32_t iMode)
{
	int32_t iRetVal = 0;
	uint64_t iOdoDiff = (uint64_t)((pHan->iCurOdo - pHan->iPrevOdo)/100ULL);

	if((pHan->sMotor[DATA_IDX_CUR].iSpeed != pHan->sMotor[DATA_IDX_NEW].iSpeed) ||
		(pHan->sMotor[DATA_IDX_CUR].iSoc != pHan->sMotor[DATA_IDX_NEW].iSoc) ||
		(pHan->sMotor[DATA_IDX_CUR].iSpeedUnit != pHan->sMotor[DATA_IDX_NEW].iSpeedUnit)||
		(pHan->sMotor[DATA_IDX_CUR].bOprHrEnable != pHan->sMotor[DATA_IDX_NEW].bOprHrEnable) ||
		(pHan->sMotor[DATA_IDX_CUR].iOprHrs != pHan->sMotor[DATA_IDX_NEW].iOprHrs) ||
		(pHan->sMotor[DATA_IDX_CUR].iWheelDrive != pHan->sMotor[DATA_IDX_NEW].iWheelDrive) ||
		((iOdoDiff - pHan->iCurOdoDiff) > 100)||
		(pHan->sMotor[DATA_IDX_NEW].iCount > 100))
	{
		pHan->sMotor[DATA_IDX_NEW].iCount = 0;

		pHan->sMotor[DATA_IDX_CUR]  = pHan->sMotor[DATA_IDX_NEW];

		pHan->iCurOdoDiff	 = iOdoDiff;

		CanProc_UpdateInfo(pHan,iOdoDiff,iMode);
		CanProc_SendMotorInfo(pHan);

		iRetVal = 1;
	}
	else
	{
		pHan->sMotor[DATA_IDX_NEW].iCount = pHan->sMotor[DATA_IDX_NEW].iCount + 1;
	}
	return iRetVal;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateInfo					          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_UpdateInfo(CanProc_t* pHan, uint64_t iOdoDiff,uint32_t iMode)
{
	if ((pHan->sMotor[DATA_IDX_NEW].iSpeed < 5) && (iOdoDiff > 300))
	{
		CanProc_UpdateSystemInfo(pHan,iMode);
		pHan->iCurTime = 0;
		pHan->iPrevTime = 0;
	}
	else if((pHan->sMotor[DATA_IDX_NEW].iSpeed > 10) && (pHan->sMotor[DATA_IDX_NEW].iSpeed <= 30) && (iOdoDiff > 1000))
	{
		CanProc_UpdateSystemInfo(pHan,iMode);
	}
	else if((pHan->sMotor[DATA_IDX_NEW].iSpeed > 30) && (pHan->sMotor[DATA_IDX_NEW].iSpeed <= 50) && (iOdoDiff > 2000))
	{
		CanProc_UpdateSystemInfo(pHan,iMode);
	}
	else if((pHan->sMotor[DATA_IDX_NEW].iSpeed > 50) && (iOdoDiff > 3000))
	{
		CanProc_UpdateSystemInfo(pHan,iMode);
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_CalculateSpeedParams			          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int32_t CanProc_CalculateSpeedParams(CanProc_t* pHan)
{
	int32_t iRetVal = BCU_OK;

	iRetVal = CanProc_UpdateDistance(pHan);
	if(iRetVal == BCU_OK)
	{
		if(pHan->iCurOdo >= pHan->iInitialOdo)
		{
			if(pHan->iCurOdoA >= pHan->iInitialOdoA)
			{
				uint64_t iTripDiff  = (pHan->iCurOdoA - pHan->iInitialOdoA);
				pHan->sMotor[DATA_IDX_NEW].iTripA = (uint32_t)round((uint32_t)((pHan->iCurTripA + iTripDiff)/100ULL));// in meters
			}
			if(pHan->iCurOdoB >= pHan->iInitialOdoB)
			{
				uint64_t iTripDiff  = (pHan->iCurOdoB - pHan->iInitialOdoB);
				pHan->sMotor[DATA_IDX_NEW].iTripB = (uint32_t)round((uint32_t)((pHan->iCurTripB + iTripDiff)/100ULL));// in meters
			}
			iRetVal = BCU_OK;
		}
		else
		{
			PRINTF("\r\n ERROR: Initial Odo %d is greater than New Odo %d :\r\n",pHan->iInitialOdo,pHan->iCurOdo);
		}
	}
	return iRetVal;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_ResetDistanceParams		          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int32_t CanProc_ResetDistanceParams(CanProc_t* pHan)
{
	int32_t iRetVal = BCU_OK;

	if(pHan->bIsResetDist == 0)
	{
		for (uint32_t i = 0; i < SPEED_CACHE_SIZE; i++)
		{
			pHan->iSpeed[i] = 0;
			pHan->iTimeOffset[i] = 0;
		}
		pHan->iCurIndex = 0;
		pHan->iCurTime = 0;
		pHan->bIsResetDist = 1;
	}

	return iRetVal;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateDistance		          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int32_t CanProc_UpdateDistance(CanProc_t* pHan)
{
	int32_t iRetVal = BCU_NOK;
	uint64_t iSum = 0;
	uint64_t TimeOffset = 0;
	uint64_t iTimeDiff =0;
	uint64_t iAvgSpeed =0;
	uint64_t iAvgTime  = 0;
	uint64_t iDistance = 0;

	uint64_t iMaxTime = 0xFFFFFFFF;

	if(pHan->iCurTime == 0)
	{
		CanProc_ResetDistanceParams(pHan);
		pHan->iCurTime = CanProc_GetCurrentTimestamp();
		pHan->iPrevTime = pHan->iCurTime;
	}
	else
	{
		pHan->iCurTime  = CanProc_GetCurrentTimestamp();

		if(pHan->iCurTime > pHan->iPrevTime)
		{
			iTimeDiff = (uint64_t)(pHan->iCurTime - pHan->iPrevTime);
		}
		else if(pHan->iCurTime < pHan->iPrevTime)
		{
			iTimeDiff =   (uint64_t)((iMaxTime - pHan->iPrevTime) + pHan->iCurTime);
		}
		else
		{
			iTimeDiff = 0;
		}

		if((iTimeDiff/24000) > 1000)
		{
			CanProc_ResetDistanceParams(pHan);
			pHan->iCurTime = CanProc_GetCurrentTimestamp();
			pHan->iPrevTime = pHan->iCurTime;
			PRINTF("\r\n Speed data timeout, Time Diff  = %d\r\n",(uint32_t)(iTimeDiff/24000));
		}
		else
		{
			pHan->bIsResetDist = 0;

			pHan->iTimeOffset[pHan->iCurIndex] = (iTimeDiff)/24000;
			pHan->iSpeed[pHan->iCurIndex] =pHan->sMotor[DATA_IDX_NEW].iSpeed;
			pHan->iCurIndex++;
			pHan->iCurIndex = pHan->iCurIndex % SPEED_CACHE_SIZE;

			for (uint32_t i = 0; i < SPEED_CACHE_SIZE; i++)
			{
				iSum = iSum + pHan->iSpeed[i];
				TimeOffset = TimeOffset + pHan->iTimeOffset[i];
			}

			iAvgSpeed = (iSum / SPEED_CACHE_SIZE);
			iAvgTime  = (TimeOffset / SPEED_CACHE_SIZE);

			iDistance = (uint64_t)(round(((double)iAvgSpeed * 1.0 * (double)iAvgTime)/36.0)); // distance in cm
			pHan->iCurOdo = (pHan->iCurOdo + iDistance);
			pHan->iCurOdoA = (pHan->iCurOdoA + iDistance);	//cms
			pHan->iCurOdoB = (pHan->iCurOdoB + iDistance);	//cms
			pHan->sMotor[DATA_IDX_NEW].iOdo = (uint32_t)round((double)pHan->iCurOdo / 100.0);
			pHan->iPrevTime = pHan->iCurTime;
		}
		iRetVal = BCU_OK;
	}
	return (iRetVal);
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_Send_DummyData					          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_Send_DummyData(CanProc_t* pHan)
{
	int32_t iRtval = CanProc_GetCachedData(pHan);

	if(iRtval == BCU_OK)
	{
		CanProc_SendMotorInfo(pHan);
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_GetCurrentTimestamp				          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static uint32_t CanProc_GetCurrentTimestamp()
{
	uint32_t lmsec  =0;

	lmsec = GPT_GetCurrentTimerCount(CANPROC_GPTIMER);

	return (lmsec);
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_TripReset		    		          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_TripReset(CanProc_t* pHan,uint8_t iSelTrip)
{

	if((iSelTrip == 0) && (pHan->sMotor[DATA_IDX_NEW].iTripA != 0))
	{
		pHan->iCurTripA 	= 0;
		pHan->sMotor[DATA_IDX_NEW].iTripA 	= 0;
		pHan->iInitialOdoA 	= pHan->iCurOdoA;
		pHan->iPrevOdoA 	= pHan->iCurOdoA;
	}
	else if((iSelTrip == 1) && (pHan->sMotor[DATA_IDX_NEW].iTripB != 0))
	{
		pHan->iCurTripB 	= 0;
		pHan->sMotor[DATA_IDX_NEW].iTripB 	= 0;
		pHan->iInitialOdoB 	= pHan->iCurOdoB;
		pHan->iPrevOdoB 	= pHan->iCurOdoB;
	}

	pHan->sMotor[DATA_IDX_NEW].iOdo 	  = (uint32_t)(pHan->iCurOdo/100ULL);
	pHan->iInitialOdo 	  = pHan->iCurOdo;
	pHan->iPrevOdo 		  = pHan->iCurOdo;
	pHan->iCurOdoDiff 	  = 0;


	CanProc_SendMotorInfo(pHan);
	if(iSelTrip == 0)
	{
		CanProc_UpdateSystemInfo(pHan,eResetTripA);
	}
	else if(iSelTrip == 1)
	{
		CanProc_UpdateSystemInfo(pHan,eResetTripB);
	}
	CanProc_SendTextMsgInfo(pHan,eAlert_Trip,1);
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_ProductionReset		    		          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int32_t CanProc_ProductionReset(void)
{
	int32_t iRtval = BCU_NOK;
	if(hCanProc.iCurIgnStatus)
	{

		sClusterInfo_t sUpdateinfo = {0};

		iRtval = Cluster_Controller_Manager_SystemInfo_SetSystemInfo(&sUpdateinfo,eResetInfo);
		if(iRtval == BCU_NOK)
		{
			PRINTF("\r\n ERROR: CanProc_ProductionReset\r\n");
		}
	}
	else
	{
		PRINTF("\r\n ERROR: ProductionReset---->Ignition Is OFF\r\n");
	}
	return iRtval;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_SetOdoInfo			    		          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int32_t CanProc_SetOdoInfo(CanProc_t* pHan)
{
	int32_t iRtval = BCU_NOK;

	if(pHan->iCurIgnStatus)
	{
		sClusterInfo_t sUpdateinfo = {0};

		sUpdateinfo.iOdoVal = pHan->sMotor[DATA_IDX_NEW].iOdo;
		sUpdateinfo.iCurTripA = pHan->sMotor[DATA_IDX_NEW].iTripA;
		sUpdateinfo.iCurTripB = pHan->sMotor[DATA_IDX_NEW].iTripB;
		sUpdateinfo.iSpeedUnit = pHan->sMotor[DATA_IDX_NEW].iSpeedUnit;
		iRtval = Cluster_Controller_Manager_SystemInfo_SetSystemInfo(&sUpdateinfo,eSetOdo);
		if(iRtval == BCU_NOK)
		{
			PRINTF("\r\n ERROR: CanProc_SetOdoInfo\r\n");
		}
	}
	return iRtval;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_SendMotorInfo    				          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_SendMotorInfo(CanProc_t* pHan)
{
	sMessage_t	  sMsg		= {0};

	sMsg.iEventId 			= eEvent_Motor;
	memcpy((char *)sMsg.sData,(char*)(&(pHan->sMotor[DATA_IDX_NEW])),sizeof(sMotorInfo_t));

	if((pHan->qHmiMsg != NULL) && (sMsg.iEventId >0))
	{
		xQueueSend(pHan->qHmiMsg, &sMsg, pdMS_TO_TICKS(1000U));
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_SendTextMsgInfo  				          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_SendTextMsgInfo(CanProc_t* pHan, eAlertId_t iId, uint32_t iCode)
{
	sMessage_t	  sMsg		= {0};
	sAlertInfo_t sAlertInfo = {0};

	if(pHan->qHmiMsg != NULL)
	{
		sMsg.iEventId 		  = eEvent_Alert;
		sAlertInfo.iId   = iId;
		sAlertInfo.iCode = iCode;
		memcpy((char *)sMsg.sData,(char*)(&(sAlertInfo)),sizeof(sAlertInfo_t));
		xQueueSend(pHan->qHmiMsg, &sMsg, pdMS_TO_TICKS(1000U));
	}
}

/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_GetCachedData				          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int32_t CanProc_GetCachedData(CanProc_t* pHan)
{
	int32_t iRval = BCU_NOK;
	sClusterInfo_t sInfo = {0};

	if(pHan->bIsOdoCached == 0)
	{
		pHan->sMotor[DATA_IDX_NEW].iOdo   = 0;
		pHan->sMotor[DATA_IDX_NEW].iTripA  = 0;
		pHan->sMotor[DATA_IDX_NEW].iTripB  = 0;
		pHan->sMotor[DATA_IDX_NEW].iSpeedUnit = 0;
		Cluster_Controller_Hal_RtcUpdateDateTime();

		iRval = Cluster_Controller_Manager_SystemInfo_GetInfo(&sInfo);

		if(iRval == BCU_OK)
		{
			if((sInfo.iOdoVal != 0xFFFFFFFF)&& ((sInfo.iCurTripA != 0xFFFFFFFF) || (sInfo.iCurTripB != 0xFFFFFFFF)) )
			{
				pHan->sMotor[DATA_IDX_NEW].iSpeed = 0 ;

				pHan->sMotor[DATA_IDX_NEW].iOdo   = sInfo.iOdoVal ;
				pHan->sMotor[DATA_IDX_NEW].iTripA  = sInfo.iCurTripA;
				pHan->sMotor[DATA_IDX_NEW].iTripB  = sInfo.iCurTripB;
				pHan->sMotor[DATA_IDX_NEW].iSpeedUnit = sInfo.iSpeedUnit;

				pHan->iCurTripA 	= (uint64_t)(pHan->sMotor[DATA_IDX_NEW].iTripA*100ULL); // in cm
				pHan->iCurTripB 	= (uint64_t)(pHan->sMotor[DATA_IDX_NEW].iTripB*100ULL); // in cm
				pHan->iCurOdo 		= (uint64_t)(pHan->sMotor[DATA_IDX_NEW].iOdo*100ULL);
				pHan->iCurOdoA 		= (uint64_t)(pHan->sMotor[DATA_IDX_NEW].iOdo*100ULL);
				pHan->iCurOdoB 		= (uint64_t)(pHan->sMotor[DATA_IDX_NEW].iOdo*100ULL);
				pHan->iInitialOdo 	= (uint64_t)(pHan->sMotor[DATA_IDX_NEW].iOdo*100ULL);
				pHan->iInitialOdoA 	= (uint64_t)(pHan->sMotor[DATA_IDX_NEW].iOdo*100ULL);
				pHan->iInitialOdoB 	= (uint64_t)(pHan->sMotor[DATA_IDX_NEW].iOdo*100ULL);
				pHan->iPrevOdo 		= (uint64_t)(pHan->sMotor[DATA_IDX_NEW].iOdo*100ULL);
				pHan->iPrevOdoA 	= (uint64_t)(pHan->sMotor[DATA_IDX_NEW].iOdo*100ULL);
				pHan->iPrevOdoB 	= (uint64_t)(pHan->sMotor[DATA_IDX_NEW].iOdo*100ULL);
				pHan->iCurOdoDiff 	= 0;
				pHan->bIsOdoCached  = 1;
			}
			else
			{
				memset(&sInfo,0,sizeof(sInfo));
			}
		}
		else
		{
			PRINTF("\r\n Error : Failed to get Cached Data \r\n");
		}
	}
	else
	{
		pHan->sMotor[DATA_IDX_NEW].iSpeed = 0 ;
		pHan->iCurOdoDiff = 0;
		iRval = BCU_OK;
	}
	return iRval;
}

/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateSystemInfo			          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_UpdateSystemInfo(CanProc_t* pHan, uint32_t iMode)
{
	sClusterInfo_t sUpdateinfo = {0};

	sUpdateinfo.iOdoVal = pHan->sMotor[DATA_IDX_NEW].iOdo;
	sUpdateinfo.iCurTripA = pHan->sMotor[DATA_IDX_NEW].iTripA;
	sUpdateinfo.iCurTripB = pHan->sMotor[DATA_IDX_NEW].iTripB;
	sUpdateinfo.iSpeedUnit = pHan->sMotor[DATA_IDX_NEW].iSpeedUnit;

	Cluster_Controller_Manager_SystemInfo_UpdateInfo(&sUpdateinfo,iMode);

	pHan->iPrevOdo = pHan->iCurOdo;
	pHan->iPrevOdoA = pHan->iCurOdoA;
	pHan->iPrevOdoB = pHan->iCurOdoB;
	pHan->iCurOdoDiff =0;
}
/*----------------------------------------------------------------------------*
  Function	      	:	CanProc_SendCommnd
  Params	    	:
  Return value		:
  Description		:
 *----------------------------------------------------------------------------*/
static int32_t  CanProc_SendCommand(int32_t iCanId,uint32_t iLen,uint8_t *pdata,uint8_t mbIdx,uint8_t iFormat)
{
	int32_t iRetVal = BCU_OK;

	sCanMessage_t CanMsg;

	CanMsg.iCanId = iCanId;
	CanMsg.iFormat = iFormat;
	CanMsg.iDataLen = iLen;

	memcpy(CanMsg.sData,pdata,sizeof(CanMsg.sData));

	iRetVal = Cluster_Controller_Hal_CanSendMessage(&CanMsg,mbIdx);

	return iRetVal;
}

/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_ProcessStatus0						          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_ProcessStatus0(CanProc_t* pHan ,flexcan_frame_t* pFrame)
{
	pHan->sStatus0[DATA_IDX_NEW].bPowerTrain		= ((pFrame->dataByte1) & 0x01) ? true:false;
	pHan->sStatus0[DATA_IDX_NEW].bBatteryFault 		= ((pFrame->dataByte1) & 0x02) ? true:false;
	pHan->sStatus0[DATA_IDX_NEW].bService 			= ((pFrame->dataByte1) & 0x04) ? true:false;
	pHan->sStatus0[DATA_IDX_NEW].bPark				= ((pFrame->dataByte1) & 0x08) ? true:false;
	pHan->sStatus0[DATA_IDX_NEW].bHazard 			= ((pFrame->dataByte1) & 0x10) ? true:false;	//Malfunction

	pHan->sStatus0[DATA_IDX_NEW].bConnectivity  	= ((pFrame->dataByte2) & 0x01) ? true:false;	//TBD
	pHan->sStatus0[DATA_IDX_NEW].bInternet  		= ((pFrame->dataByte3) & 0x01) ? true:false;	//Wifi
	pHan->sStatus0[DATA_IDX_NEW].bCellular  		= ((pFrame->dataByte3) & 0x02) ? true:false;
//	pHan->sStatus0[DATA_IDX_NEW].bScreenOnCmd		= ((pFrame->dataByte5) & 0x01) ? false:true;

	pHan->bScreenOnCmd = ((pFrame->dataByte5) & 0x01) ? true:false;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProcStatus_UpdateStatus0Info						  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int32_t CanProc_UpdateStatus0Info(CanProc_t * pHan)
{
	int32_t iRetVal =0;
	if((pHan->sStatus0[DATA_IDX_CUR].bPowerTrain 	!= pHan->sStatus0[DATA_IDX_NEW].bPowerTrain) ||
			(pHan->sStatus0[DATA_IDX_CUR].bBatteryFault != pHan->sStatus0[DATA_IDX_NEW].bBatteryFault) ||
			(pHan->sStatus0[DATA_IDX_CUR].bService 		!= pHan->sStatus0[DATA_IDX_NEW].bService) ||
			(pHan->sStatus0[DATA_IDX_CUR].bPark 		!= pHan->sStatus0[DATA_IDX_NEW].bPark) ||
			(pHan->sStatus0[DATA_IDX_CUR].bHazard 		!= pHan->sStatus0[DATA_IDX_NEW].bHazard) ||
			(pHan->sStatus0[DATA_IDX_CUR].bConnectivity != pHan->sStatus0[DATA_IDX_NEW].bConnectivity) ||
			(pHan->sStatus0[DATA_IDX_CUR].bInternet 	!= pHan->sStatus0[DATA_IDX_NEW].bInternet) ||
			(pHan->sStatus0[DATA_IDX_CUR].bCellular 	!= pHan->sStatus0[DATA_IDX_NEW].bCellular) ||
//			(pHan->sStatus0[DATA_IDX_CUR].bScreenOnCmd 	!= pHan->sStatus0[DATA_IDX_NEW].bScreenOnCmd) ||
			(pHan->sStatus0[DATA_IDX_NEW].iCount > 100))
	{
		pHan->sStatus0[DATA_IDX_NEW].iCount = 0;
		pHan->sStatus0[DATA_IDX_CUR]  	= pHan->sStatus0[DATA_IDX_NEW];

		CanProc_SendStatus0Info(pHan);

		iRetVal = 1;
	}
	else
	{
		pHan->sStatus0[DATA_IDX_NEW].iCount = pHan->sStatus0[DATA_IDX_NEW].iCount + 1;
	}
	return iRetVal;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_SendStatus0Info			          	          *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_SendStatus0Info(CanProc_t* pHan)
{
	sMessage_t	  sMsg		= {0};

	sMsg.iEventId 			= eEvent_Status0;
	memcpy((char *)sMsg.sData,(char*)(&(pHan->sStatus0[DATA_IDX_NEW])),sizeof(sStatus0_t));

	if((pHan->qHmiMsg != NULL) && (sMsg.iEventId >0))
	{
		xQueueSend(pHan->qHmiMsg, &sMsg, (TickType_t)(MSG_SEND_DEFAULT_WAIT));
	}
}

/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_IsPrintableAscii						          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static inline bool CanProc_IsPrintableAscii(uint8_t cVal)
{
	return ((cVal >= 0x20U) && (cVal <= 0x7EU));
}

/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_ValidateChar						          *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static inline char CanProc_ValidateChar(uint8_t cVal) {
	char retVal;

	if (CanProc_IsPrintableAscii(cVal))
	{
		retVal = (char)cVal;
	}
	else
	{
		retVal = ' ';
	}

	return retVal;
}

/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_ProcessObdHeader						          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_ProcessObdHeader(CanProc_t*  pHan,  flexcan_frame_t*  pFrame)
{
	if ((pHan != NULL) && (pFrame != NULL))
	{
		pHan->sObd[DATA_IDX_NEW].bHdrEnable = ((pFrame->dataByte0 & 0x01U) != 0U);

		if (pHan->sObd[DATA_IDX_NEW].bHdrEnable)
		{
			pHan->sObd[DATA_IDX_NEW].sHeader[0] = CanProc_ValidateChar(pFrame->dataByte1);
			pHan->sObd[DATA_IDX_NEW].sHeader[1] = CanProc_ValidateChar(pFrame->dataByte2);
			pHan->sObd[DATA_IDX_NEW].sHeader[2] = CanProc_ValidateChar(pFrame->dataByte3);
			pHan->sObd[DATA_IDX_NEW].sHeader[3] = CanProc_ValidateChar(pFrame->dataByte4);
			pHan->sObd[DATA_IDX_NEW].sHeader[4] = CanProc_ValidateChar(pFrame->dataByte5);
			pHan->sObd[DATA_IDX_NEW].sHeader[5] = '\0';
		}
		else
		{
			pHan->sObd[DATA_IDX_NEW].sHeader[0] = '\0';
		}
	}
}

/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_ProcessObdMsg0					              *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_ProcessObdMsg0(CanProc_t* pHan ,flexcan_frame_t* pFrame)
{
	uint8_t iLen = (pFrame->dataByte0);

	if ((iLen == 0) || (iLen > 15))
	{
		pHan->sObd[DATA_IDX_NEW].sMsg[0] = '\0';
		pHan->sObd[DATA_IDX_NEW].iLen = 0;
		pHan->sObd[DATA_IDX_NEW].bMsgEnable = false;
		return;
	}
	else
	{
		pHan->sObd[DATA_IDX_NEW].bMsgEnable = true;
	}

	pHan->sObd[DATA_IDX_NEW].sMsg[0] = (char)CanProc_ValidateChar(pFrame->dataByte1);
	pHan->sObd[DATA_IDX_NEW].sMsg[1] = (char)CanProc_ValidateChar(pFrame->dataByte2);
	pHan->sObd[DATA_IDX_NEW].sMsg[2] = (char)CanProc_ValidateChar(pFrame->dataByte3);
	pHan->sObd[DATA_IDX_NEW].sMsg[3] = (char)CanProc_ValidateChar(pFrame->dataByte4);
	pHan->sObd[DATA_IDX_NEW].sMsg[4] = (char)CanProc_ValidateChar(pFrame->dataByte5);
	pHan->sObd[DATA_IDX_NEW].sMsg[5] = (char)CanProc_ValidateChar(pFrame->dataByte6);
	pHan->sObd[DATA_IDX_NEW].sMsg[6] = (char)CanProc_ValidateChar(pFrame->dataByte7);

	if(iLen < 8)
	{
		pHan->sObd[DATA_IDX_NEW].sMsg[iLen] = '\0';
	}
	else
	{
		pHan->sObd[DATA_IDX_NEW].iLen = iLen;
		pHan->sObd[DATA_IDX_NEW].sMsg[7] = '\0';
	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_ProcessObdMsg1						          *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_ProcessObdMsg1(CanProc_t* pHan ,flexcan_frame_t* pFrame)
{
	if ((pHan->sObd[DATA_IDX_NEW].iLen >= 8) && (pHan->sObd[DATA_IDX_NEW].iLen <= 15))
	{
		uint8_t iLen = pHan->sObd[DATA_IDX_NEW].iLen;

		pHan->sObd[DATA_IDX_NEW].sMsg[7]  = (char)CanProc_ValidateChar(pFrame->dataByte0);
		pHan->sObd[DATA_IDX_NEW].sMsg[8]  = (char)CanProc_ValidateChar(pFrame->dataByte1);
		pHan->sObd[DATA_IDX_NEW].sMsg[9]  = (char)CanProc_ValidateChar(pFrame->dataByte2);
		pHan->sObd[DATA_IDX_NEW].sMsg[10] = (char)CanProc_ValidateChar(pFrame->dataByte3);
		pHan->sObd[DATA_IDX_NEW].sMsg[11] = (char)CanProc_ValidateChar(pFrame->dataByte4);
		pHan->sObd[DATA_IDX_NEW].sMsg[12] = (char)CanProc_ValidateChar(pFrame->dataByte5);
		pHan->sObd[DATA_IDX_NEW].sMsg[13] = (char)CanProc_ValidateChar(pFrame->dataByte6);
		pHan->sObd[DATA_IDX_NEW].sMsg[14] = (char)CanProc_ValidateChar(pFrame->dataByte7);
		pHan->sObd[DATA_IDX_NEW].sMsg[iLen] = '\0';

	}
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateObdInfo					          	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int32_t CanProc_UpdateObdInfo(CanProc_t* const pHan)
{
	int32_t iRetVal = 0;

	if (pHan != NULL)
	{
		bool bIsInfoChanged = false;
		uint32_t i=0;

		if ((pHan->sObd[DATA_IDX_NEW].bHdrEnable != pHan->sObd[DATA_IDX_CUR].bHdrEnable) ||
			(pHan->sObd[DATA_IDX_NEW].bMsgEnable != pHan->sObd[DATA_IDX_CUR].bMsgEnable))
		{
			bIsInfoChanged = true;
		}
		else
		{
			for (i = 0U; i < OBD_CODE_STR_SIZE; i++)
			{
				if (pHan->sObd[DATA_IDX_NEW].sHeader[i] != pHan->sObd[DATA_IDX_CUR].sHeader[i])
				{
					bIsInfoChanged = true;
					break;
				}
			}

			if (bIsInfoChanged == false)
			{
				if (pHan->sObd[DATA_IDX_NEW].iLen != pHan->sObd[DATA_IDX_CUR].iLen)
				{
					bIsInfoChanged = true;
				}
				else
				{
					for (i = 0U; i < OBD_MSG_MAX_LEN; i++)
					{
						if (pHan->sObd[DATA_IDX_NEW].sMsg[i] != pHan->sObd[DATA_IDX_CUR].sMsg[i])
						{
							bIsInfoChanged = true;
							break;
						}
					}
				}
			}
		}

		if (bIsInfoChanged == true)
		{
			pHan->sObd[DATA_IDX_CUR] = pHan->sObd[DATA_IDX_NEW];
			CanProc_SendObdInfo(pHan);
			iRetVal = 1;
		}
	}

	return iRetVal;
}
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_SendObdInfo				    		  		  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_SendObdInfo(CanProc_t* pHan)
{
	sMessage_t	  sMsg		= {0};
	sMsg.iEventId 			= eEvent_MultiFault;

	memcpy((char *)sMsg.sData,(char *)(&(pHan->sObd[DATA_IDX_NEW])),sizeof(sMultiFault_t));
	if((pHan->qHmiMsg !=NULL) && (sMsg.iEventId >0))
	{
		xQueueSend(pHan->qHmiMsg, &sMsg, (TickType_t)(MSG_SEND_DEFAULT_WAIT));
	}
}

/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_ResetAllData			    		  		  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_ResetAllData(CanProc_t* pHan)
{

	pHan->sMotor[DATA_IDX_NEW].iSpeed = 0;
	pHan->sMotor[DATA_IDX_NEW].bOprHrEnable = 0;
	pHan->sMotor[DATA_IDX_NEW].iWheelDrive = 0;
	pHan->sMotor[DATA_IDX_NEW].iOprHrs = 0;

	memset(&pHan->sBattery[DATA_IDX_NEW],0,sizeof(sBatteryInfo_t));
	memset(&pHan->sStatus0[DATA_IDX_NEW],0,sizeof(sStatus0_t));
	memset(&pHan->sDriveMode[DATA_IDX_NEW],0,sizeof(sDriveMode_t));
	memset(&pHan->sObd[DATA_IDX_NEW],0,sizeof(sMultiFault_t));
	memset(&pHan->sCharge[DATA_IDX_NEW],0,sizeof(sChargeInfo_t));
}


/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UIUpdateHandler			    		  		  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_UIUpdateHandler(void * const args)
{
	CanProc_t * const pHan = (CanProc_t *)args;

	uint8_t sBuf[UIUPDATE_QUEUE_BUFFER_SIZE];

	uint32_t iState = UPDATE_STATE_SPEED;

	const TickType_t sWaitTicks = pdMS_TO_TICKS(50U);

	if (pHan != NULL)
	{
		while (true)
		{
			if (xQueueReceive(pHan->qUpdateMsg, (void *)&sBuf, sWaitTicks) != pdPASS)
			{
				bool bIsEventSent = false;
				uint32_t iLoopCount = 0U;

				while ((!bIsEventSent) && (iLoopCount < UPDATE_STATE_MAX))
				{
					int32_t iRetVal = 0U;

					switch (iState)
					{
						case UPDATE_STATE_SPEED:
						{
							iRetVal = CanProc_UpdateSpeedInfo(pHan, eSpeedInfo);
						}
						break;
						case UPDATE_STATE_CHARGE:
						{
							iRetVal = CanProc_UpdateChargeInfo(pHan);
						}
						break;
						case UPDATE_STATE_STATUS0:
						{
							iRetVal = CanProc_UpdateStatus0Info(pHan);
						}
						break;
						case UPDATE_STATE_DRIVE:
						{
							iRetVal = CanProc_UpdateDriveModeInfo(pHan);
						}
						break;

						case UPDATE_STATE_OBD:
						{
							iRetVal = CanProc_UpdateObdInfo(pHan);
						}
						break;

						default:
						{
							iState = UPDATE_STATE_SPEED;
							iRetVal = 0U;
						}
						break;
					}
					iState++;
					if (iState >= UPDATE_STATE_MAX)
					{
						iState = UPDATE_STATE_SPEED;
					}

					iLoopCount++;

					if (iRetVal != 0)
					{
						bIsEventSent = true;
					}
					else
					{
						// continue
					}
				}
#if CLUSTER_SWITCH_WAKE
				CanProc_UpdateSleepMode(pHan);
#endif
			}
		}
	}
}

 /*----------------------------------------------------------------------------*
  * Function	      	:	CanProc_PackVCUInfo				          	  	  *
  * Params	    	:								       		              *
  * Return value		:								                          *
  * Description		:							                              *
  *----------------------------------------------------------------------------*/
 static int32_t CanProc_PackVCUInfo(CanProc_t* pHan)
 {
	 uint8_t pData[8] = {0};
	 int32_t iRetVal = BCU_OK;

	 uint32_t i0doVal = (uint32_t)pHan->sMotor[DATA_IDX_NEW].iOdo/1000ULL;
	 uint32_t iTripAVal = (uint32_t)pHan->sMotor[DATA_IDX_NEW].iTripA/1000ULL;
	 uint32_t iTriBAVal =(uint32_t) pHan->sMotor[DATA_IDX_NEW].iTripB/1000ULL;

	 pData[0] = (uint8_t)(i0doVal & 0xFF);
	 pData[1] = (uint8_t)((i0doVal >> 8) & 0xFF);
	 pData[2] = (uint8_t)((i0doVal >> 16) & 0xFF);
	 pData[3] = (uint8_t)((i0doVal >> 24) & 0xFF);
	 pData[4] = (uint8_t)((iTripAVal) & 0xFF);
	 pData[5] = (uint8_t)(((iTripAVal) >> 8) & 0xFF);
	 pData[6] = (uint8_t)((iTriBAVal) & 0xFF);
	 pData[7] = (uint8_t)(((iTriBAVal) >>8)& 0xFF);


	 iRetVal = CanProc_SendCommand(eCANID_Frame7,8,&pData[0],16,0);

	 return iRetVal;
 }

/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_ProcessNavKeyInfo				          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static int32_t CanProc_ProcessNavKeyInfo(CanProc_t* pHan, uint8_t iKey, uint8_t iStatus)
{
	(void)(pHan);
	uint8_t pData[8] = {0};
	int32_t iRetVal = BCU_OK;

	pData[0] = (uint8_t)((((iKey) & 0x0F) <<4) | ( iStatus & 0x0F)) ;

	iRetVal = CanProc_SendCommand(eCANID_Frame8,8,&pData[0],17,0);

	return iRetVal;
}
#if CLUSTER_SWITCH_WAKE
/*----------------------------------------------------------------------------*
 * Function	      	:	CanProc_UpdateSleepMode				          	  	  *
 * Params	    	:								       		              *
 * Return value		:								                          *
 * Description		:							                              *
 *----------------------------------------------------------------------------*/
static void CanProc_UpdateSleepMode(CanProc_t* pHan)
{

	if(pHan->bScreenOnCmd == true)
	{
		if(pHan->iOnCount > 100)
		{
			Cluster_Controller_HalSwitch_EnableSleep(pHan->bScreenOnCmd);
			pHan->bScreenOnCmd = false;
			pHan->iOnCount = 0;
		}
		else
		{
			pHan->iOnCount++;
		}

	}
	else
	{
		pHan->iOnCount = 0;
	}
	(void)(pHan);
}
#endif
