/*-----------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										   *
 *	Copyright (C) OptM Media Solutions Pvt Ltd - All Rights Reserved.	   	   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from OptM Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_controller_hal_display.c 						   *
 *  version		: 											              	   *
 *  Date		:	03-Mar-2023												   *
 *  Description :  				 										 	   *
 *                               						                       *
 *-----------------------------------------------------------------------------*/
#include "cluster_controller_hal_display.h"
#include "FreeRTOS.h"
#include "task.h"
#include "fsl_display.h"
#include "fsl_gpio.h"
#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_common.h"
#include "fsl_iomuxc.h"
#include "pin_mux.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define Display_DelayMs VIDEO_DelayMs

#define Platform_DelayMs(ms) ((xTaskGetSchedulerState() != taskSCHEDULER_RUNNING) ? \
                             SDK_DelayAtLeastUs((ms) * 1000U, SystemCoreClock) :   \
                             Display_DelayMs(ms))
#if CLUSTER_DISPLAY_INTERFACE							 
static void Display_InitMipiPanelPins(void) ;
#endif
/*******************************************************************************
 * Variables
 ******************************************************************************/
const display_operations_t optm_ops = {
    .init   = Cluster_Controller_Hal_Display_Init,
    .deinit = Cluster_Controller_Hal_Display_Deinit,
    .start  = Cluster_Controller_Hal_Display_Start,
    .stop   = Cluster_Controller_Hal_Display_Stop,
};


typedef struct
{
	bool				bIsOn;
	bool 				bIsMuxInitialised;
	int32_t 			iIsInitialised;
	display_handle_t 	*pHandle;
	mipi_dsi_device_t 	*pDsiDevice;
	const display_config_t *pDispconfig;
}HalDisplay_t;

//static HalDisplay_t   hDisplay= {0};

/*----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Hal_Display_Init					      *
 * Params	    :	display_handle_t *handle, const display_config_t *config  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
status_t Cluster_Controller_Hal_Display_Init(display_handle_t *handle, const display_config_t *config)
{
    status_t status                   = kStatus_Success;
#if CLUSTER_DISPLAY_INTERFACE
    if((handle != NULL) && (config!= NULL))
    {
		const display_resource_t *resource = (const display_resource_t *)(handle->resource);

		memset(&hDisplay, 0 ,sizeof(HalDisplay_t));

		hDisplay.pHandle = handle;
		hDisplay.pDsiDevice = resource->dsiDevice;
		hDisplay.pDispconfig = config;
		if (hDisplay.pDispconfig->resolution == FSL_VIDEO_RESOLUTION(CLUSTER_PANEL_WIDTH, CLUSTER_PANEL_HEIGHT))
		{
			Display_InitMipiPanelPins();
			Platform_DelayMs(200);
#if CLUSTER_KEYIGNITION_SUPPORTED
			//status = Cluster_Controller_Hal_Display_Enable(0);
#else
			status = Cluster_Controller_Hal_Display_Enable(1);
#endif

			hDisplay.iIsInitialised = 1;
		}
		else
		{
			status= kStatus_InvalidArgument;
		}
    }
#else
    (void)(handle);
    (void)(config);
#if CLUSTER_KEYIGNITION_SUPPORTED
			status = Cluster_Controller_Hal_Display_Enable(0);
#else
			status = Cluster_Controller_Hal_Display_Enable(1);
#endif

#endif
    return status;
}
/*----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Hal_Display_Deinit				      *
 * Params	    :	display_handle_t *handle			        		      *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
status_t Cluster_Controller_Hal_Display_Deinit(display_handle_t *handle)
{
    if(handle == NULL) { return kStatus_InvalidArgument; }
    const display_resource_t *resource = (const display_resource_t *)(handle->resource);
    mipi_dsi_device_t *dsiDevice      = resource->dsiDevice;

    (void)MIPI_DSI_DCS_EnterSleepMode(dsiDevice, true);

    resource->pullResetPin(false);
    resource->pullPowerPin(false);

    return kStatus_Success;
}
/*----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Hal_Display_Start				      *
 * Params	    :	display_handle_t *handle			        		      *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
status_t Cluster_Controller_Hal_Display_Start(display_handle_t *handle)
{
	(void)(handle);
    status_t status                   = kStatus_Success;
#if 0
    if(handle == NULL) { return kStatus_InvalidArgument; }


    const display_resource_t *resource = (const display_resource_t *)(handle->resource);
    mipi_dsi_device_t *dsiDevice      = resource->dsiDevice;

    if(hDisplay.bIsOn)
    {
    	status = MIPI_DSI_DCS_SetDisplayOn(dsiDevice, true);
    }
#endif
    return status;
}

/*----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Hal_Display_Enable				      *
 * Params	    :	bool bOnOff 			        		                  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
status_t Cluster_Controller_Hal_Display_Enable( bool bOnOff)
{
	status_t status = kStatus_Success;
#if CLUSTER_DISPLAY_INTERFACE
	if((hDisplay.pHandle != NULL) &&
	   (hDisplay.pDsiDevice != NULL))
	{
		hDisplay.bIsOn = bOnOff;
		if(bOnOff)
		{
			GPIO_PinWrite(CLUSTER_DISPLAY_BL_GPIO, CLUSTER_DISPLAY_BL_PIN, 0);
			GPIO_PinWrite(CLUSTER_DISPLAY_RST_GPIO, CLUSTER_DISPLAY_RST_PIN, 1);
			GPIO_PinWrite(CLUSTER_DISPLAY_STB_GPIO, CLUSTER_DISPLAY_STB_PIN, 1);


			GPIO_PinWrite(CLUSTER_DISPLAY_DRIVER_GPIO, CLUSTER_DISPLAY_DRIVER_PIN, 1);
			Platform_DelayMs(10);

			GPIO_PinWrite(CLUSTER_DISPLAY_RST_GPIO, CLUSTER_DISPLAY_RST_PIN, 0);
			Platform_DelayMs(20); // Hardware sync gap

			GPIO_PinWrite(CLUSTER_DISPLAY_STB_GPIO, CLUSTER_DISPLAY_STB_PIN, 0);
			Platform_DelayMs(70); // Recovery gap for internal bias blocks

			status = MIPI_DSI_GenericWrite(hDisplay.pDsiDevice, (const uint8_t[]){0xB2, 0x10}, 2);
			status = MIPI_DSI_GenericWrite(hDisplay.pDsiDevice, (const uint8_t[]){0x80, 0x5b}, 2);
			status = MIPI_DSI_GenericWrite(hDisplay.pDsiDevice, (const uint8_t[]){0x81, 0x47}, 2);
			status = MIPI_DSI_GenericWrite(hDisplay.pDsiDevice, (const uint8_t[]){0x82, 0x84}, 2);
			status = MIPI_DSI_GenericWrite(hDisplay.pDsiDevice, (const uint8_t[]){0x83, 0x88}, 2);
			status = MIPI_DSI_GenericWrite(hDisplay.pDsiDevice, (const uint8_t[]){0x84, 0x88}, 2);
			status = MIPI_DSI_GenericWrite(hDisplay.pDsiDevice, (const uint8_t[]){0x85, 0x23}, 2);
			status = MIPI_DSI_GenericWrite(hDisplay.pDsiDevice, (const uint8_t[]){0x86, 0xb6}, 2);

			status = MIPI_DSI_DCS_EnterSleepMode(hDisplay.pDsiDevice, false); // Sleep Out

			Platform_DelayMs(120);
			status = Cluster_Controller_Hal_Display_Start(hDisplay.pHandle);
			Platform_DelayMs(35);

			GPIO_PinWrite(CLUSTER_DISPLAY_BL_GPIO, CLUSTER_DISPLAY_BL_PIN, 1);
		}
		else
		{
			GPIO_PinWrite(CLUSTER_DISPLAY_BL_GPIO, CLUSTER_DISPLAY_BL_PIN, 0);
			GPIO_PinWrite(CLUSTER_DISPLAY_STB_GPIO, CLUSTER_DISPLAY_STB_PIN, 1); // Display STB = Low

			status = Cluster_Controller_Hal_Display_Stop(hDisplay.pHandle);

			status = MIPI_DSI_DCS_EnterSleepMode(hDisplay.pDsiDevice, true);
			Platform_DelayMs(120);

			GPIO_PinWrite(CLUSTER_DISPLAY_RST_GPIO, CLUSTER_DISPLAY_RST_PIN, 1); // Display RST = Low
			Platform_DelayMs(20);

			GPIO_PinWrite(CLUSTER_DISPLAY_DRIVER_GPIO, CLUSTER_DISPLAY_DRIVER_PIN, 0);
			Platform_DelayMs(20);
		}
	}
	else
	{
		PRINTF("\n\r Cluster_Controller_Hal_Display_Enable Invalid State \n\r");
	}
#else
		GPIO_PinWrite(CLUSTER_DISPLAY_BL_GPIO, CLUSTER_DISPLAY_BL_PIN, 0);
		Display_DelayMs(10);


		GPIO_PinWrite(CLUSTER_DISPLAY_STB_GPIO, CLUSTER_DISPLAY_STB_PIN, bOnOff);     //Standby
		Display_DelayMs(300);

		GPIO_PinWrite(CLUSTER_DISPLAY_DRIVER_GPIO, CLUSTER_DISPLAY_DRIVER_PIN, bOnOff);      	//Data Enable
		Display_DelayMs(10);

		GPIO_PinWrite(CLUSTER_DISPLAY_BL_GPIO, CLUSTER_DISPLAY_BL_PIN, bOnOff);       //back light
		Display_DelayMs(50);
#endif
	return status;
}
/*----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Hal_Display_Stop				          *
 * Params	    :	display_handle_t *handle		        		          *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
status_t Cluster_Controller_Hal_Display_Stop(display_handle_t *handle)
{
    if(handle == NULL) { return kStatus_InvalidArgument; }
    const display_resource_t *resource = (const display_resource_t *)(handle->resource);
    mipi_dsi_device_t *dsiDevice      = resource->dsiDevice;

    return MIPI_DSI_DCS_SetDisplayOn(dsiDevice, false);
}
#if CLUSTER_DISPLAY_INTERFACE
static void Display_InitMipiPanelPins(void) {

	CLOCK_EnableClock(kCLOCK_Iomuxc);
	CLOCK_EnableClock(kCLOCK_Iomuxc_Lpsr);
	const gpio_pin_config_t pinConfig = {kGPIO_DigitalOutput, 0, kGPIO_NoIntmode};

	const gpio_pin_config_t pinConfig_2 = {kGPIO_DigitalOutput, 1, kGPIO_NoIntmode};

	IOMUXC_SetPinMux(CLUSTER_DISPLAY_BL_BANK,0U);  //backlight
	IOMUXC_SetPinConfig(CLUSTER_DISPLAY_BL_BANK, 0U);
	GPIO_PinInit(CLUSTER_DISPLAY_BL_GPIO, CLUSTER_DISPLAY_BL_PIN, &pinConfig);

	IOMUXC_SetPinMux(CLUSTER_DISPLAY_DRIVER_BANK,0U);  //display driver
	IOMUXC_SetPinConfig(CLUSTER_DISPLAY_DRIVER_BANK, 0U);
	GPIO_PinInit(CLUSTER_DISPLAY_DRIVER_GPIO, CLUSTER_DISPLAY_DRIVER_PIN, &pinConfig_2);
	Platform_DelayMs(10);

	IOMUXC_SetPinMux(CLUSTER_DISPLAY_STB_BANK,0U);   //standby
	IOMUXC_SetPinConfig(CLUSTER_DISPLAY_STB_BANK, 0x0F);
	GPIO_PinInit(CLUSTER_DISPLAY_STB_GPIO, CLUSTER_DISPLAY_STB_PIN, &pinConfig);
	Platform_DelayMs(20);

	IOMUXC_SetPinMux(CLUSTER_DISPLAY_RST_BANK,0U);  //Reset
	IOMUXC_SetPinConfig(CLUSTER_DISPLAY_RST_BANK, 0x0F);
	GPIO_PinInit(CLUSTER_DISPLAY_RST_GPIO, CLUSTER_DISPLAY_RST_PIN, &pinConfig);
	Platform_DelayMs(70);
//	GPIO_PinWrite(CLUSTER_DISPLAY_RST_GPIO, CLUSTER_DISPLAY_RST_PIN, 0);
//	Platform_DelayMs(20); // Hardware sync gap
//
//	GPIO_PinWrite(CLUSTER_DISPLAY_STB_GPIO, CLUSTER_DISPLAY_STB_PIN, 0);
//	Platform_DelayMs(70); // Recovery gap for internal bias blocks

	MIPI_DSI_DCS_EnterSleepMode(hDisplay.pDsiDevice, false); // Sleep Out

	 MIPI_DSI_GenericWrite(hDisplay.pDsiDevice, (const uint8_t[]){0xB2, 0x10}, 2);
	 MIPI_DSI_GenericWrite(hDisplay.pDsiDevice, (const uint8_t[]){0x80, 0x5b}, 2);
	 MIPI_DSI_GenericWrite(hDisplay.pDsiDevice, (const uint8_t[]){0x81, 0x47}, 2);
	 MIPI_DSI_GenericWrite(hDisplay.pDsiDevice, (const uint8_t[]){0x82, 0x84}, 2);
	 MIPI_DSI_GenericWrite(hDisplay.pDsiDevice, (const uint8_t[]){0x83, 0x88}, 2);
	 MIPI_DSI_GenericWrite(hDisplay.pDsiDevice, (const uint8_t[]){0x84, 0x88}, 2);
	 MIPI_DSI_GenericWrite(hDisplay.pDsiDevice, (const uint8_t[]){0x85, 0x23}, 2);
	 MIPI_DSI_GenericWrite(hDisplay.pDsiDevice, (const uint8_t[]){0x86, 0xb6}, 2);

	Cluster_Controller_Hal_Display_Stop(hDisplay.pHandle);

	MIPI_DSI_DCS_EnterSleepMode(hDisplay.pDsiDevice, true);
	Platform_DelayMs(120);

	IOMUXC_SetPinMux(CLUSTER_DISPLAY_RST_BANK,0U);  //Reset
	IOMUXC_SetPinConfig(CLUSTER_DISPLAY_RST_BANK, 0x0F);
	GPIO_PinInit(CLUSTER_DISPLAY_RST_GPIO, CLUSTER_DISPLAY_RST_PIN, &pinConfig);
	Platform_DelayMs(20);
}
#endif
