/*-----------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										   *
 *	Copyright (C) OptM Media Solutions Pvt Ltd - All Rights Reserved.	   	   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from OptM Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_controller_hal_switch.c 							   *
 *  version		: 											              	   *
 *  Date		:	03-Mar-2023												   *
 *  Description :  				 										 	   * 
 *                               						                       *
 *-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------*
 * Include Headers				           	                             	   *
 *-----------------------------------------------------------------------------*/
/* FreeRTOS kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
#include "semphr.h"

/* Freescale includes. */
#include "MIMXRT1176_cm7.h"
#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "board.h"
#include "fsl_gpio.h"
#include "fsl_gpt.h"
#include "fsl_gpc.h"
#include "fsl_lcdifv2.h"
#include "vg_lite.h"

#include "cluster_common.h"
#include "cluster_controller_hal_switch.h"
#include "cluster_controller_hal.h"

/*----------------------------------------------------------------------------* 
 * Macro ,Structure and Enum definition                   				      *
 *----------------------------------------------------------------------------*/
#define EXN_SW_GPIO                  GPIO13
#define EXN_SW_IRQ                   GPIO13_Combined_0_31_IRQn
#define EXN_SW_IRQHandler            GPIO13_Combined_0_31_IRQHandler

#define NAV_SW_GPIO                  GPIO4
#define NAV_SW_IRQ                   GPIO4_Combined_0_15_IRQn
#define NAV_SW_IRQHandler            GPIO4_Combined_0_15_IRQHandler

#define EXID_MAX                       10
#define NAVID_MAX                      3 //5

#define SWITCH_MAX_QUEUE_MSG_COUNT      10
#define SWITCH_MSG_QUEUE_BUFFER_SIZE    4

#define ANALOG_INPUT 0

#define IGNITION_DEBOUNCE_MS           50U
#define HW_INPUTS_MASK              0x1FF9U
#define WAKEUP_PIN                   0U  // 0th pin is for wakeup
#define WAKEUP_PIN_MASK              (1U << WAKEUP_PIN)

typedef struct
{
	bool				bRefresh;
	bool                bIgnitionEnabled;
	bool				bNavSleeping;
	uint8_t 			iCurStatus;
	bool                bStatusValid;
	GPIO_Type           *base;
	uint32_t * 	        pHwInput;
	uint32_t *          pNavInput;
	int32_t 			iIsInitialised;
	QueueHandle_t       qRxMsg;
	QueueHandle_t       qSwMsg;
	TaskHandle_t 		hThread;
	uint32_t            iIsrDropCount;
	uint32_t			iIntMask;
}HalSwitch_t;

/*----------------------------------------------------------------------------* 
 * Static and global variable definition	                         		  * 
 *----------------------------------------------------------------------------*/
static HalSwitch_t   hSwitch= {0};
static  sHwInputs_t sStatus ={0};
static  sNavSwitch_t  sNavInput ={0};
/*----------------------------------------------------------------------------* 
 * Local function definition	                         				      * 
 *----------------------------------------------------------------------------*/
static void Switch_ReceiveThread(void *arg);
static int32_t Switch_InitIo(HalSwitch_t *pHan);
static int32_t Switch_EnableIo(HalSwitch_t *pHan);
static int32_t Switch_Configure(HalSwitch_t *pHan);
static void Switch_ExternalInput(HalSwitch_t *pHan);
static void Switch_NavigationFunc(HalSwitch_t *pHan);
void EXN_SW_IRQHandler(void);
void NAV_SW_IRQHandler(void);
AT_QUICKACCESS_SECTION_CODE(static int32_t Switch_EnterSleepmode(HalSwitch_t *pHan,uint8_t bOnOff));
extern void Lcdifv2Layer_ResyncAfterWake(void);
extern unsigned int Lcdifv2Layer_GetCurrentFrame(void);

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_Switch_Init(void)
{
	int32_t iRval = BCU_OK;
	if(hSwitch.iIsInitialised == 0)
	{
		memset(&hSwitch, 0 ,sizeof(HalSwitch_t));

		iRval = Switch_Configure(&hSwitch);
		if(iRval == BCU_OK )
		{
			hSwitch.iIsInitialised = 1;
			hSwitch.iCurStatus = 0;
		}
	}
	return iRval;
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_Switch_DeInit(void)
{
	if(hSwitch.iIsInitialised > 0)
	{
		if( hSwitch.hThread != NULL )
		{
			vTaskDelete( hSwitch.hThread );
			hSwitch.hThread = NULL;
		}
		if(hSwitch.qRxMsg != NULL)
		{
			vQueueDelete(hSwitch.qRxMsg);
			hSwitch.qRxMsg = NULL;
		}
	}
	memset(&hSwitch, 0, sizeof(HalSwitch_t));
	return BCU_OK;
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_Switch_SetReceiveQueueHandle(QueueHandle_t  hSwitchQueue)
{
	int32_t iRval = BCU_OK;
	if (hSwitch.iIsInitialised > 0)
	{
		hSwitch.qSwMsg	= hSwitchQueue;
		iRval = BCU_OK;
	}
	return iRval;
}
/*-----------------------------------------------------------------------------*
 * Function	    :		cluster_controller_hal_switch_turnoff				*
 * Params	    :					        		                            *
 * Return value	:									                        *
 * Description	:							                                   	*
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_Switch_EnableSleep(bool bEnable)
{
	if(bEnable)
	{
		Cluster_Controller_HalDisplay_Enable(false);
		hSwitch.bNavSleeping = true;
		Switch_EnterSleepmode(&hSwitch, 1);
		Cluster_Controller_HalDisplay_Enable(true);
		hSwitch.bNavSleeping = false;
		Lcdifv2Layer_ResyncAfterWake();
		const char sWakeUpBuf[SWITCH_MSG_QUEUE_BUFFER_SIZE] = {2};
		xQueueSend(hSwitch.qRxMsg, (const char*)sWakeUpBuf, 0);
	}
	return 0;
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/

void EXN_SW_IRQHandler(void)
{
	BaseType_t bTaskWoken = pdFALSE;
	const char sExtBuf[SWITCH_MSG_QUEUE_BUFFER_SIZE] = {2};

#if(CLUSTER_HW_VERSION == 1)
	GPIO_PortClearInterruptFlags(EXN_SW_GPIO,0xFF9);
#else
	GPIO_PortClearInterruptFlags(EXN_SW_GPIO,HW_INPUTS_MASK);
#endif

	if(hSwitch.qRxMsg != NULL)
	{
		if(xQueueSendFromISR(hSwitch.qRxMsg, (char*)&sExtBuf, &bTaskWoken) != pdPASS)
		{
			hSwitch.iIsrDropCount++;
		}
	}

	portYIELD_FROM_ISR(bTaskWoken);
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
void NAV_SW_IRQHandler(void)
{
	BaseType_t bTaskWoken = pdFALSE;
	const char sNavBuf[SWITCH_MSG_QUEUE_BUFFER_SIZE] = {1};

	GPIO_PortClearInterruptFlags(NAV_SW_GPIO,0x38);

	if(hSwitch.qRxMsg != NULL)
	{
		if(xQueueSendFromISR(hSwitch.qRxMsg, (char*)&sNavBuf, &bTaskWoken) != pdPASS)
		{
			hSwitch.iIsrDropCount++;
		}
	}

	portYIELD_FROM_ISR(bTaskWoken);
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
static void Switch_ReceiveThread(void *arg)
{
	HalSwitch_t*   	pHan 		= (HalSwitch_t*)(arg);
	uint8_t iCount = 0;
	char sRxBuf[SWITCH_MSG_QUEUE_BUFFER_SIZE] = {0};
	TickType_t maxDelay = pdMS_TO_TICKS(2000);

	xQueueReceive(pHan->qRxMsg, (char*)&sRxBuf[0], pdMS_TO_TICKS(3000));
	Switch_EnableIo(pHan);

	while (1)
	{
		memset(sRxBuf, 0,SWITCH_MSG_QUEUE_BUFFER_SIZE);
		if (xQueueReceive(pHan->qRxMsg, (char*)&sRxBuf[0], maxDelay) == pdTRUE)
		{
			if(sRxBuf[0] == 1)
			{
				Switch_NavigationFunc(pHan);
			}
			else if(sRxBuf[0] == 2)
			{
				pHan->bRefresh = false;
				Switch_ExternalInput(pHan);
			}
		}
		else
		{
			pHan->bRefresh = true;
			Switch_ExternalInput(pHan);
			Switch_NavigationFunc(pHan);
			if(iCount >= 4)
			{
				maxDelay = pdMS_TO_TICKS(5000);
			}
			else
			{
				iCount++;
			}
		}
	}
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
static void Switch_ExternalInput(HalSwitch_t *pHan)
{
	sMessage_t sMsg = {0};
	uint8_t iIgnitionOff;

	memset(&sStatus,0,sizeof(sHwInputs_t));

	sStatus.bRefresh =  pHan->bRefresh;

	iIgnitionOff = (GPIO_PinRead(EXN_SW_GPIO, pHan->pHwInput[0]) != 0)?1:0;



	if(iIgnitionOff == 0)
	{
		sStatus.bInput1 = 1;
	}

	if(GPIO_PinRead(EXN_SW_GPIO, pHan->pHwInput[1]) == 0)
	{
		sStatus.bInput2 = 1;
	}

	if(GPIO_PinRead(EXN_SW_GPIO, pHan->pHwInput[2]) == 0)
	{
		sStatus.bInput3 = 1;
	}

	if(GPIO_PinRead(EXN_SW_GPIO, pHan->pHwInput[3]) == 0)
	{
		sStatus.bInput4 = 1;
	}

	if(GPIO_PinRead(EXN_SW_GPIO, pHan->pHwInput[4]) == 0)
	{
		sStatus.bInput5 = 1;
	}

	if(GPIO_PinRead(EXN_SW_GPIO, pHan->pHwInput[5]) == 0)
	{
		sStatus.bInput6 = 1;
	}

	if(GPIO_PinRead(EXN_SW_GPIO, pHan->pHwInput[6]) == 0)
	{
		sStatus.bInput7 = 1;
	}

	if(GPIO_PinRead(EXN_SW_GPIO, pHan->pHwInput[7]) == 0)
	{
		sStatus.bInput8 = 1;
	}

	if(GPIO_PinRead(EXN_SW_GPIO, pHan->pHwInput[8]) == 0)
	{
		sStatus.bInput9 = 1;
	}

	if(GPIO_PinRead(EXN_SW_GPIO, pHan->pHwInput[9]) == 0)
	{
		sStatus.bInput10 = 1;
	}

	if(hSwitch.qSwMsg != NULL)
	{
		sMsg.iEventId 			= EXTERNAL_SW;

		memcpy((char *)sMsg.sData,(char*)(&sStatus),sizeof(sHwInputs_t));

		xQueueSend(pHan->qSwMsg, &sMsg, pdMS_TO_TICKS(5000));
	}
#if CLUSTER_KEYIGNITION_SUPPORTED
	if(!pHan->bStatusValid || (pHan->iCurStatus != iIgnitionOff))
	{
		bool bIgnitionOff = (GPIO_PinRead(EXN_SW_GPIO, pHan->pHwInput[0]) != 0);
		if(bIgnitionOff)
		{
			Cluster_Controller_HalDisplay_Enable(false);
			Switch_EnterSleepmode(pHan, iIgnitionOff);
			Cluster_Controller_HalDisplay_Enable(true);
			Lcdifv2Layer_ResyncAfterWake();
			const char sWakeUpBuf[SWITCH_MSG_QUEUE_BUFFER_SIZE] = {2};
			xQueueSend(pHan->qRxMsg, (const char*)sWakeUpBuf, 0);
		}
		else
		{
			Cluster_Controller_HalDisplay_Enable(true);
		}
		pHan->iCurStatus   = iIgnitionOff;
		pHan->bStatusValid = true;
	}
#elif ((CLUSTER_KEYIGNITION_SUPPORTED == 0) &&  (CLUSTER_SWITCH_WAKE == 0))
	Cluster_Controller_Hal_CanSleep(false);
#endif
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
static void Switch_NavigationFunc(HalSwitch_t *pHan)
{
	sMessage_t sMsg = {0};

	memset(&sNavInput, 0, sizeof(sNavSwitch_t));

	if(GPIO_PinRead(NAV_SW_GPIO, pHan->pNavInput[0]) == 0)
	{
		sNavInput.iVal |= eKey_Right ;
	}

	if(GPIO_PinRead(NAV_SW_GPIO, pHan->pNavInput[1]) == 0)
	{
		sNavInput.iVal |= eKey_Ok ;
	}

	if(GPIO_PinRead(NAV_SW_GPIO, pHan->pNavInput[2]) == 0)
	{
		sNavInput.iVal |= eKey_Left ;
	}

	sMsg.iEventId 			= NAVIGATION_SW;
	memcpy((char *)sMsg.sData,(char*)(&sNavInput),sizeof(sNavSwitch_t));

	if((hSwitch.qSwMsg != NULL)&& (!hSwitch.bNavSleeping))
	{
		xQueueSend(pHan->qSwMsg, &sMsg, pdMS_TO_TICKS(5000));
	}
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
static int32_t Switch_Configure(HalSwitch_t *pHan)
{
	int32_t iRet = 0;
	int32_t iRval = BCU_OK;
	uint16_t iStackSize = 0;

	iRval = Switch_InitIo(pHan);
	if(iRval != BCU_OK)
	{
		return iRval;
	}
	pHan->qRxMsg = xQueueCreate(SWITCH_MAX_QUEUE_MSG_COUNT,SWITCH_MSG_QUEUE_BUFFER_SIZE);
	if(pHan->qRxMsg == NULL)
	{
		return BCU_NOK;
	}
	Cluster_Controller_Hal_ConfigGetStackSize(&iStackSize);

	iRet= xTaskCreate(Switch_ReceiveThread,
						"switch",
						iStackSize,
						&hSwitch,
						CLUSTER_TASK_PRIORITY_DATA,
						&hSwitch.hThread);
	if(iRet == pdPASS)
	{
		iRval = BCU_OK;
	}
	else
	{
		iRval = BCU_NOK;
	}
	return iRval;
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
static int32_t Switch_InitIo(HalSwitch_t *pHan)
{
	uint8_t i =0;

	gpio_pin_config_t sConfig = {
		        kGPIO_DigitalInput,
		        1,
				kGPIO_IntRisingOrFallingEdge,
		    };

	pHan->pHwInput    =  Cluster_Controller_Hal_ConfigSwitchGetList(0); //Externalinput

	if(pHan->pHwInput != NULL)
	{
		for( i = 0 ; i < EXID_MAX ; i++)
		{
			GPIO_PinInit(EXN_SW_GPIO,pHan->pHwInput[i], &sConfig);
		}

		NVIC_SetPriority(EXN_SW_IRQ, configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY+1);
	}

#if CLUSTER_NAVIGATION_SWITCH_ENABLE
	pHan->pNavInput =  Cluster_Controller_Hal_ConfigSwitchGetList(1); //Navigation
	
	if(pHan->pNavInput != NULL)
	{
		for( i = 0 ; i < NAVID_MAX ; i++)
		{
			GPIO_PinInit(NAV_SW_GPIO,pHan->pNavInput[i], &sConfig);
		}
		NVIC_SetPriority(NAV_SW_IRQ, configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY+1);
	}
#endif
	return BCU_OK;
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
static int32_t Switch_EnableIo(HalSwitch_t *pHan)
{
	int32_t i = 0;

	if(pHan->pHwInput == NULL)
	{
		return BCU_NOK;
	}

	pHan->bIgnitionEnabled = true;
	EnableIRQ(EXN_SW_IRQ);

	for(i = 0 ; i < EXID_MAX; i++)
	{
		GPIO_PortEnableInterrupts(EXN_SW_GPIO, 1U << pHan->pHwInput[i]);
	}

#if CLUSTER_NAVIGATION_SWITCH_ENABLE
	if(pHan->pNavInput == NULL)
	{
		return BCU_NOK;
	}
	EnableIRQ(NAV_SW_IRQ);
	for(i = 0 ; i < NAVID_MAX; i++)
	{
		GPIO_PortEnableInterrupts(NAV_SW_GPIO, 1U << pHan->pNavInput[i]);
	}
#endif
	return BCU_OK;
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/

AT_QUICKACCESS_SECTION_CODE(static int32_t Switch_EnterSleepmode(HalSwitch_t *pHan,uint8_t bOnOff))
{
	uint32_t iExnPin = (uint32_t)pHan->pHwInput[0];
	uint32_t iNavPin = (uint32_t)pHan->pNavInput[1];
	uint32_t iExnMask = (1U << iExnPin);
	uint32_t iNavMask = (1U << iNavPin);

	bool bUseExn =((CLUSTER_KEYIGNITION_SUPPORTED)&&(pHan->bNavSleeping == false));
	bool bUseNav =((CLUSTER_SWITCH_WAKE)&&(pHan->bNavSleeping));

	uint32_t iExnIntMask = EXN_SW_GPIO->IMR;
	uint32_t iNavIntMask = NAV_SW_GPIO->IMR;

	Cluster_Controller_Hal_CanSleep(true);
	EXN_SW_GPIO->IMR &= ~HW_INPUTS_MASK;
	NAV_SW_GPIO->IMR &= ~0x38U;

	GPIO_PortClearInterruptFlags(EXN_SW_GPIO, HW_INPUTS_MASK);
	GPIO_PortClearInterruptFlags(NAV_SW_GPIO, 0x38U);

	NVIC_ClearPendingIRQ(EXN_SW_IRQ);
	NVIC_ClearPendingIRQ(NAV_SW_IRQ);

	if (bUseExn)
	{
		GPIO_SetPinInterruptConfig(EXN_SW_GPIO,iExnPin,kGPIO_IntFallingEdge);
	}
	if (bUseNav)
	{
		GPIO_SetPinInterruptConfig(NAV_SW_GPIO,iNavPin,kGPIO_IntRisingOrFallingEdge);
	}
	for (uint32_t i = 0U;i < GPC_CPU_MODE_CTRL_CM_IRQ_WAKEUP_MASK_COUNT;i++)
	{
		GPC_CPU_MODE_CTRL_0->CM_IRQ_WAKEUP_MASK[i] =0xFFFFFFFFU;
	}
	if (bUseExn)
	{
		GPC_CM_EnableIrqWakeup(GPC_CPU_MODE_CTRL_0,(uint32_t)EXN_SW_IRQ,true);
	}
	if (bUseNav)
	{
		GPC_CM_EnableIrqWakeup(GPC_CPU_MODE_CTRL_0,(uint32_t)NAV_SW_IRQ,true);
	}
	if (bUseExn)
	{
#if (CLUSTER_HW_VERSION == 1)
	GPIO_PortClearInterruptFlags(EXN_SW_GPIO, 0xFF9U);
#else
	GPIO_PortClearInterruptFlags(EXN_SW_GPIO, HW_INPUTS_MASK);
#endif
	NVIC_ClearPendingIRQ(EXN_SW_IRQ);
	}

	if (bUseNav)
	{
		GPIO_PortClearInterruptFlags(NAV_SW_GPIO, 0x38U);
		NVIC_ClearPendingIRQ(NAV_SW_IRQ);
	}
	xQueueReset(pHan->qRxMsg);
	if (bUseExn)
	{
		EXN_SW_GPIO->IMR |= iExnMask;
	}
	if (bUseNav)
	{
		NAV_SW_GPIO->IMR |= iNavMask;
	}
	(void)vg_lite_finish();
	vTaskSuspendAll();
	{
		__disable_irq();
		__DSB();
		__ISB();

		GPC_CM_SetNextCpuMode(GPC_CPU_MODE_CTRL_0,kGPC_SuspendMode);
		GPC_CM_EnableCpuSleepHold(GPC_CPU_MODE_CTRL_0,true);
		SysTick->CTRL &= ~SysTick_CTRL_TICKINT_Msk;
		SCB->ICSR = SCB_ICSR_PENDSTCLR_Msk;
		SCB->SCR |= SCB_SCR_SLEEPDEEP_Msk;

		NVIC_DisableIRQ(LCDIFv2_IRQn);
		NVIC_DisableIRQ(GPU2D_IRQn);

		NVIC_ClearPendingIRQ(LCDIFv2_IRQn);
		NVIC_ClearPendingIRQ(GPU2D_IRQn);

		__DSB();
		__ISB();

		bool bIgnitionOff;
		if (bUseExn)
		{
			bIgnitionOff =(GPIO_PinRead(EXN_SW_GPIO, iExnPin) != 0U);
		}
		if (bUseNav)
		{
			bIgnitionOff =(GPIO_PinRead(NAV_SW_GPIO, iNavPin) != 0U);
		}
		if ((bOnOff == 1U) && bIgnitionOff)
		{
			__WFI();
		}
		GPC_CM_EnableCpuSleepHold(GPC_CPU_MODE_CTRL_0,false);
		SCB->SCR &= ~SCB_SCR_SLEEPDEEP_Msk;
		LCDIFV2_ClearInterruptStatus(LCDIFV2,0,kLCDIFV2_VerticalBlankingInterrupt);
		NVIC_ClearPendingIRQ(LCDIFv2_IRQn);
		NVIC_ClearPendingIRQ(GPU2D_IRQn);
		NVIC_EnableIRQ(LCDIFv2_IRQn);
		NVIC_EnableIRQ(GPU2D_IRQn);

		__enable_irq();
		__DSB();
		__ISB();
	}
	xTaskResumeAll();
	SysTick->CTRL |= SysTick_CTRL_TICKINT_Msk;
	if (bUseExn)
	{
		GPIO_SetPinInterruptConfig(EXN_SW_GPIO,iExnPin,kGPIO_IntRisingEdge);
	}
	if (bUseNav)
	{
		GPIO_SetPinInterruptConfig(NAV_SW_GPIO,iNavPin,kGPIO_IntRisingOrFallingEdge);
	}
	if (bUseExn)
	{
#if (CLUSTER_HW_VERSION == 1)
	GPIO_PortClearInterruptFlags(EXN_SW_GPIO, 0xFF9U);
#else
	GPIO_PortClearInterruptFlags(EXN_SW_GPIO, HW_INPUTS_MASK);
#endif
	NVIC_ClearPendingIRQ(EXN_SW_IRQ);

	GPC_CM_EnableIrqWakeup(GPC_CPU_MODE_CTRL_0,(uint32_t)EXN_SW_IRQ,false);
	}
	if (bUseNav)
	{
		GPIO_PortClearInterruptFlags(NAV_SW_GPIO, 0x38U);
		NVIC_ClearPendingIRQ(NAV_SW_IRQ);

		GPC_CM_EnableIrqWakeup(GPC_CPU_MODE_CTRL_0,(uint32_t)NAV_SW_IRQ,false);
	}
	GPC_CM_SetNextCpuMode(GPC_CPU_MODE_CTRL_0,kGPC_RunMode);

	EXN_SW_GPIO->IMR = iExnIntMask;
	NAV_SW_GPIO->IMR = iNavIntMask;
	Cluster_Controller_Hal_CanSleep(false);
	return BCU_OK;
}


