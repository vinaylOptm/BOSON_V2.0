/*---------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										 *
 *	Copyright (C) OptM Media Solutions Pvt Ltd - All Rights Reserved.	   	 *
 *  Dissemination of this information or reproduction or redistribution of 	 *
 *  this material is  strictly forbidden unless prior written permission is	 *
 *  obtained from OptM Media Solutions Pvt Ltd								 *
 *	File Name	:	Cluster_Controller_Hal_E2Prom.c 							 *
 *  version		: 											              	 *
 *  Date		:	23-May-2023												 *
 *  Description :  				 										 	 * 
 *                               						                     *
 *---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*
 * Include Headers				           	                             	 *
 *---------------------------------------------------------------------------*/
#include "cluster_common.h"
#include "fsl_debug_console.h"
#include "fsl_lpspi.h"
#include "cluster_controller_hal.h"
#include "cluster_controller_hal_eeprom.h"
/*----------------------------------------------------------------------------*
 * Macro ,Structure and enum definition                   				      *
 *----------------------------------------------------------------------------*/
#define LPSPI_MASTER_PCS_FOR_INIT     (kLPSPI_Pcs0)

#define EEPROM_CMD_WREN      0x06
#define EEPROM_CMD_WRITE     0x02
#define EEPROM_CMD_READ      0x03
#define EEPROM_CMD_RDSR      0x05
#define EEPROM_CMD_RDID	     0x83

#define EEPROM_PAGE_SIZE          32
#define EEPROM_MAX_TRANSFER_SIZE  256U
#define EEPROM_TRANSFER_TIMEOUT_MS 1000U
#define EEPROM_MAX_ADDR   0x03FF

typedef struct
{
	int32_t 		iIsInitialised;
	uint32_t		iCSPin;
	uint32_t		iClkPin;
	uint32_t		iSdoPin;
	uint32_t		iSdiPin;
	QueueHandle_t   qCmdMsg;
	SemaphoreHandle_t xferSema;
	LPSPI_Type 		*pSpiType;
	IRQn_Type		IRqn;
	lpspi_master_handle_t hLpSpi;
	lpspi_transfer_t xfer;
}sE2prom_t;

/*----------------------------------------------------------------------------* 
 * Static and global variable definition	                         		  * 
 *----------------------------------------------------------------------------*/
static sE2prom_t hE2prom = {0};

/*----------------------------------------------------------------------------*
 * Local function definition	                         				      *
 *----------------------------------------------------------------------------*/
static int32_t E2prom_WaitBusy(void);
static int32_t E2prom_WriteEnable(void);
static uint8_t E2prom_ReadStatus(void);
static int32_t E2prom_Configure(sE2prom_t* pHan);
static int32_t E2prom_CallBackHandler_Init(sE2prom_t * pHan);
static int32_t E2prom_WriteData(sE2prom_t* pHan, uint32_t iAddr, uint8_t *pData, uint32_t iSize);
static int32_t E2prom_ReadData(sE2prom_t* pHan, uint32_t iAddr, uint8_t* pBuf, uint32_t iSize);
static int32_t E2prom_TransferData(sE2prom_t* pHan, uint8_t *pTx, uint8_t *pRx, uint32_t iSize);
void E2prom_Callback(LPSPI_Type *pBase,
                    lpspi_master_handle_t *pHandle,
                    status_t status,
                    void *pUserData);
/*-----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Hal_E2Prom_Init			     		   *
 * Params	    :	void				        		                       *
 * Return value	:	On success return BCU_OK else it will return BCU_NOK       *
 * Description	:	In this method, Initializes secondary flash(NVM) including
 * 					GPIO's to interface the flash.				               *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_E2Prom_Init(void)
{
	int32_t iRetVal  = BCU_NOK;
	if(hE2prom.iIsInitialised == 0)
	{
		memset(&hE2prom,0,sizeof(sE2prom_t));

		iRetVal = E2prom_Configure(&hE2prom);
		if(iRetVal == BCU_OK)
		{
			hE2prom.iIsInitialised = 1;
		}
		else
		{
			PRINTF("\r\n Error: E2Prom Init Failed \r\n");
		}
	}
	return iRetVal;
}
/*-----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Hal_E2Prom_DeInit			     	   *
 * Params	    :	void				        		                       *
 * Return value	:	On success return BCU_OK else it will return BCU_NOK       *
 * Description	:	In this method, Deinitializes secondary flash(NVM).	       *
 *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_E2Prom_DeInit(void)
{
	int32_t iRetVal  = BCU_OK;
	if(hE2prom.iIsInitialised == 1)
	{
		if(hE2prom.xferSema != NULL)
		{
			vSemaphoreDelete(hE2prom.xferSema);
		}
		memset(&hE2prom, 0, sizeof(sE2prom_t));
	}
	return iRetVal;
}
 /*-----------------------------------------------------------------------------*
  * Function	    :	Cluster_Controller_Hal_E2Prom_WriteData			        *
  * Params	    	:	uint8_t* pBuf, int iSize and uint32_t iAddr				*
  * Return value	:	On success return BCU_OK else it will return BCU_NOK    *
  * Description		:	In this method, Write the data into secondary flash
  * 					(NVM) with respect to secondary flash(NVM) manufacturer
  * 					specific.				                                *
  *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_E2Prom_WriteData(uint8_t* pBuf,
 										         uint32_t iSize,
											     uint32_t iAddr)
 {
 	int32_t iRetVal = BCU_NOK;
 	if(hE2prom.iIsInitialised == 1)
 	{
 		iRetVal = E2prom_WriteData(&hE2prom,iAddr,pBuf,iSize);
 	}
 	return iRetVal;
 }

 /*-----------------------------------------------------------------------------*
  * Function	    :	Cluster_Controller_Hal_E2Prom_Erase			     		*
  * Params	   	    :	int iAddr				        		                *
  * Return value	:	On success return BCU_OK else it will return BCU_NOK    *
  * Description	    :	In this method, Erases the secondary flash(NVM) before
  * 					writing into the flash, and follows the  secondary flash
  * 					(NVM) asper manufacturer specific.				        *
  *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_E2Prom_Erase(uint32_t iAddr)
 {
 	int32_t iRetVal = BCU_OK;
 	(void)(iAddr);
 	return iRetVal;
 }
/*-----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Hal_E2Prom_ReadData	        		   *
 * Params	    :	uint8_t * pBuf,int iSize , uint32_t iAdd                   *
 * Return value	:	On success return BCU_OK else it will return BCU_NOK	   *
 * Description	:	In this method, Receives the data from the flash followed
 * 					by spi protocal and manufacturer specification.			   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_E2Prom_ReadData(uint8_t * pBuf, uint32_t iSize, uint32_t iAddr)
{
	int32_t iRetval = BCU_NOK;
 	if(hE2prom.iIsInitialised == 1)
 	{
 		iRetval = E2prom_ReadData(&hE2prom,iAddr,pBuf,iSize);
 	}
	return iRetval;
}
/*-----------------------------------------------------------------------------*
 * Function	    :	E2prom_Configure								           *
 * Params	    :	sE2prom_t* pHan				        		               *
 * Return value	:	On success return BCU_OK else it will return BCU_NOK 	   *
 * Description	:	In this method, Configure the GPIO pins asper the specif
 *                  -ication and assigning pins to sE2prom_t.		           *
 *-----------------------------------------------------------------------------*/
static int32_t E2prom_Configure(sE2prom_t* pHan)
{
	int32_t iRetVal = BCU_NOK;
	int32_t iId =0;
	uint32_t iBaud =0;
	uint32_t uSpiClkFreq = 0;
	lpspi_master_config_t sConfig;
	
	iRetVal = Cluster_Controller_Hal_ConfigSpiGetInterface(&iId,&iBaud);
	if(iRetVal == BCU_OK)
	{
		switch(iId)
		{
			case 1:
			{
				pHan->pSpiType = LPSPI1;
				pHan->IRqn = LPSPI1_IRQn;
				uSpiClkFreq =  CLOCK_GetFreqFromObs(CCM_OBS_LPSPI1_CLK_ROOT);
			}
			break;
			case 2:
			{
				pHan->pSpiType = LPSPI2;
				pHan->IRqn = LPSPI2_IRQn;
				uSpiClkFreq =  CLOCK_GetFreqFromObs(CCM_OBS_LPSPI2_CLK_ROOT);
			}
			break;
			case 3:
			{
				pHan->pSpiType = LPSPI3;
				pHan->IRqn = LPSPI3_IRQn;
				uSpiClkFreq =  CLOCK_GetFreqFromObs(CCM_OBS_LPSPI3_CLK_ROOT);
			}
			break;
			default:
			{
				pHan->pSpiType = LPSPI1;
				pHan->IRqn = LPSPI1_IRQn;
				uSpiClkFreq =  CLOCK_GetFreqFromObs(CCM_OBS_LPSPI1_CLK_ROOT);
			}
			break;
		}
		
		LPSPI_MasterGetDefaultConfig(&sConfig);
		
		sConfig.baudRate = iBaud;
		sConfig.bitsPerFrame = 8;
		sConfig.cpol = kLPSPI_ClockPolarityActiveHigh;
		sConfig.cpha = kLPSPI_ClockPhaseFirstEdge;
		sConfig.whichPcs = LPSPI_MASTER_PCS_FOR_INIT;
		
		LPSPI_MasterInit(pHan->pSpiType, &sConfig, uSpiClkFreq);

		iRetVal = E2prom_CallBackHandler_Init(pHan);
	}
	return iRetVal;
}
/*-----------------------------------------------------------------------------*
 * Function	    :	E2prom_CallBackHandler_Init				        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
static int32_t E2prom_CallBackHandler_Init(sE2prom_t * pHan)
{
	int32_t iRetVal = BCU_NOK;

	pHan->xferSema = xSemaphoreCreateBinary();
	if(pHan->xferSema == NULL)
	{
		PRINTF("\r\nERROR: EEPROM semaphore creation failed\r\n");
		return BCU_NOK;
	}

	LPSPI_MasterTransferCreateHandle(pHan->pSpiType,
	                                 &(pHan->hLpSpi),
	                                 E2prom_Callback,
	                                 pHan);

	NVIC_SetPriority(pHan->IRqn, 3);
	NVIC_ClearPendingIRQ(pHan->IRqn);
	NVIC_EnableIRQ(pHan->IRqn);

	iRetVal = BCU_OK;
	return iRetVal;
}
/*-----------------------------------------------------------------------------*
 * Function	    :	E2prom_Callback							        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
void E2prom_Callback(LPSPI_Type *pBase,
                    lpspi_master_handle_t *pHandle,
                    status_t status,
                    void *pUserData)
{
	(void)(pBase);
	(void)(pHandle);
	(void)(status);
	sE2prom_t *pHan = (sE2prom_t *)pUserData;
	BaseType_t xHigherPriorityTaskWoken = pdFALSE;
	xSemaphoreGiveFromISR(pHan->xferSema, &xHigherPriorityTaskWoken);
	portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}
/*-----------------------------------------------------------------------------*
 * Function	    :	E2prom_WriteEnable										   *
 * Params	    :	void				        		                       *
 * Return value	:	On success return BCU_OK else it will return BCU_NOK 	   *
 * Description	:	In this method, write's the write enable command, when
 * 					chip select pin is Low and after writing write enable cmd,
 * 					chip select pin should be high.	  						   *
 *-----------------------------------------------------------------------------*/
static int32_t E2prom_WriteEnable(void)
{
	int32_t iRetVal = BCU_NOK;
	if(hE2prom.iIsInitialised == 1)
	{
		uint8_t iCmd = EEPROM_CMD_WREN;
		
		E2prom_TransferData(&hE2prom,&iCmd, NULL, 1);
		iRetVal = BCU_OK;
	}
	return iRetVal;
}
/*-----------------------------------------------------------------------------*
 * Function	    :	E2prom_WriteData									       *
 * Params	    :	sE2prom_t* pHan, uint8_t * pBuf, int iSize				   *
 * Return value	:	On success return BCU_OK else it will return BCU_NOK	   *
 * Description	:	In this method, Will write the data into flash through
 * 					SDO in bit by bit along with clock synchronization		   *
 *-----------------------------------------------------------------------------*/
static int32_t E2prom_WriteData(sE2prom_t* pHan, uint32_t iAddr, uint8_t *pData, uint32_t iSize)
{
	int32_t iRetVal = BCU_NOK;

    if ((iAddr + iSize - 1) > EEPROM_MAX_ADDR)
    {
		PRINTF("\r\nERROR: EEPROM (Addr + Write) size %u exceeds Max Addr %u\r\n",
		       (unsigned)iSize, (unsigned)EEPROM_MAX_ADDR);
        return BCU_NOK;
    }

	while (iSize > 0)
    {
        uint8_t iTxBuf[EEPROM_PAGE_SIZE + 3];

        uint32_t iPageOffset = iAddr % EEPROM_PAGE_SIZE;
        uint32_t iLen = EEPROM_PAGE_SIZE - iPageOffset;
		
		if (iLen > iSize)
		{
			iLen = iSize;
		}
		E2prom_WriteEnable();

		iTxBuf[0] = EEPROM_CMD_WRITE;
		iTxBuf[1] = (uint8_t)((iAddr >> 8) & 0xFF);
		iTxBuf[2] = (uint8_t)(iAddr & 0xFF);

		memcpy(&iTxBuf[3], pData, iLen);

		iRetVal = E2prom_TransferData(pHan,iTxBuf, NULL, iLen + 3);

		if(iRetVal == BCU_OK)
		{
			E2prom_WaitBusy();
			iAddr += iLen;
			pData += iLen;
			iSize  -= iLen;
		}
		else
		{
			PRINTF("\r\nError: EEPROM WriteData Failed:");
			return BCU_NOK;
		}
	}
	return iRetVal;
}
/*-----------------------------------------------------------------------------*
 * Function	    :	E2prom_ReadData											   *
 * Params	    :	sE2prom_t* pHan,uint8_t* pBuf,uint32_t iSize 			   *
 * Return value	:	On success return BCU_OK else it will return BCU_NOK	   *
 * Description	:	In this method, Receives the data in bit by bit through
 * 					SDI	along with clock pin and converting into the byte, by
 * 					keeping the write pin 0.				                   *
 *-----------------------------------------------------------------------------*/
static int32_t E2prom_ReadData(sE2prom_t* pHan, uint32_t iAddr, uint8_t* pBuf, uint32_t iSize)
{
	int32_t iRetVal = BCU_NOK;
	static uint8_t iTxBuf[EEPROM_MAX_TRANSFER_SIZE + 3U];
	static uint8_t iRxBuf[EEPROM_MAX_TRANSFER_SIZE + 3U];

	if(iSize > EEPROM_MAX_TRANSFER_SIZE)
	{
		PRINTF("\r\nERROR: EEPROM read size %u exceeds max %u\r\n",
		       (unsigned)iSize, (unsigned)EEPROM_MAX_TRANSFER_SIZE);
		return BCU_NOK;
	}

	iTxBuf[0] = EEPROM_CMD_READ;
	iTxBuf[1] = (uint8_t)((iAddr >> 8) & 0xFF);
	iTxBuf[2] = (uint8_t)(iAddr & 0xFF);

	memset(&iTxBuf[3], 0xFF, iSize);

	iRetVal = E2prom_TransferData(pHan, iTxBuf, iRxBuf, iSize + 3U);
	if(iRetVal == BCU_OK)
	{
		memcpy(pBuf, &iRxBuf[3], iSize);
	}

	return iRetVal;
}
/*-----------------------------------------------------------------------------*
 * Function	    :	E2prom_WaitBusy										       *
 * Params	    :	void			        		                           *
 * Return value	:	On success return BCU_OK else it will return BCU_NOK	   *
 * Description	:	In this method, If flash is busy while read or write,
 * 				    zeroth index bit will be 1(set), if flash is not busy with
 * 				    read or write, zeroth index will be 0. 					   *
 *-----------------------------------------------------------------------------*/
static int32_t E2prom_WaitBusy(void)
{
	const uint32_t maxRetries = 10000U;
	uint32_t count = 0U;
	while ((E2prom_ReadStatus() & 0x01U) && (count < maxRetries))
	{
		count++;
		vTaskDelay(pdMS_TO_TICKS(1));
	}
	if(count >= maxRetries)
	{
		PRINTF("\r\nERROR: EEPROM busy timeout\r\n");
		return BCU_NOK;
	}
	return BCU_OK;
}
/*-----------------------------------------------------------------------------*
 * Function	    :	E2prom_ReadStatus									       *
 * Params	    :	void			        		                           *
 * Return value	:	On success return BCU_OK else it will return BCU_NOK	   *
 * Description	:	In this method, If flash is busy while read or write,
 * 				    zeroth index bit will be 1(set), if flash is not busy with
 * 				    read or write, zeroth index will be 0. 					   *
 *-----------------------------------------------------------------------------*/
static uint8_t E2prom_ReadStatus(void)
{
	uint8_t iTxBuf[2];
	uint8_t iRxBuf[2];

	iTxBuf[0] = EEPROM_CMD_RDSR;
	iTxBuf[1] = 0xFF;

    E2prom_TransferData(&hE2prom,iTxBuf, iRxBuf, 2);
    return iRxBuf[1];
}
/*-----------------------------------------------------------------------------*
 * Function	    :	E2prom_TransferData									       *
 * Params	    :	void			        		                           *
 * Return value	:	On success return BCU_OK else it will return BCU_NOK	   *
 * Description	:	In this method, If flash is busy while read or write,
 * 				    zeroth index bit will be 1(set), if flash is not busy with
 * 				    read or write, zeroth index will be 0. 					   *
 *-----------------------------------------------------------------------------*/
static int32_t E2prom_TransferData(sE2prom_t* pHan, uint8_t *pTx, uint8_t *pRx, uint32_t iSize)
{
	int32_t iRetVal = BCU_NOK;
	if(hE2prom.iIsInitialised == 1)
	{
		memset(&(pHan->xfer), 0, sizeof(lpspi_transfer_t));

		pHan->xfer.txData = pTx;
		pHan->xfer.rxData = pRx;
		pHan->xfer.dataSize = (size_t)(iSize);
		pHan->xfer.configFlags = kLPSPI_MasterPcs0 | kLPSPI_MasterPcsContinuous;

		status_t iStatus = LPSPI_MasterTransferNonBlocking(pHan->pSpiType, &(pHan->hLpSpi), &pHan->xfer);
		if(iStatus == kStatus_Success)
		{
			if(xSemaphoreTake(pHan->xferSema, pdMS_TO_TICKS(EEPROM_TRANSFER_TIMEOUT_MS)) == pdTRUE)
			{
				iRetVal = BCU_OK;
			}
			else
			{
				PRINTF("\r\nERROR: EEPROM SPI transfer timeout\r\n");
				LPSPI_MasterTransferAbort(pHan->pSpiType, &(pHan->hLpSpi));
			}
		}
	}
    return iRetVal;
}
