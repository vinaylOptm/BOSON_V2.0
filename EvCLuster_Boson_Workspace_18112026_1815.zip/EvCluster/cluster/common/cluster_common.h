#ifndef CLUSTER_COMMON_H_
#define CLUSTER_COMMON_H_


#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										   *
 *	Copyright (C) OptM Media Solutions Pvt. Ltd - All Rights Reserved	   	   *
 *																			   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from OptM Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_common.h
 *  version		: 											              	   *
 *  Date		:	03-Mar-2023
 *  Description :  				 										 	   *
 *                               						                       *
 *																			   *
 *-----------------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
#include "timers.h"
#include <stdbool.h>

#define  BCU_OK    0
#define  BCU_NOK   1

#define CLUSTER_TASK_PRIORITY_UI         (configMAX_PRIORITIES - 2U)
#define CLUSTER_TASK_PRIORITY_DATA       (configMAX_PRIORITIES - 3U)
#define CLUSTER_TASK_PRIORITY_BACKGROUND (configMAX_PRIORITIES - 4U)

#define  EXTERNAL_SW     0
#define  NAVIGATION_SW   1

#define  VEHICLE_CHARGESTATE_INFO  	   4
#define  VEHICLE_DTC_INFO              3
#define  VEHICLE_SPEC_INFO_MEMSEC      2
#define  CLUSTER_INFO_MEMSEC1          1
#define  CLUSTER_INFO_MEMSEC0          0

typedef enum
{
	eModule_None		= 0,
	eModule_Bt			= 1 << 0,
	eModule_Can		    = 1 << 1,
	eModule_Rtc    	    = 1 << 2,
	eModule_Switch   	= 1 << 3,
	eModule_BackLight   = 1 << 4,
	eModule_Flash       = 1 << 5,
	eModule_Adc         = 1 << 6,
	eModule_Buzzer      = 1 << 7,
}Cluster_Modules_t;

typedef enum
{
	eEvent_None				= 0,
	eEvent_Motor			= 1,
	eEvent_Battery			= 2,
	eEvent_Charge			= 3,
	eEvent_Adc				= 4,
	eEvent_Time             = 5,
	eEvent_DriveMode		= 6,
	eEvent_NavSwitch		= 7,
	eEvent_HwIndicator		= 8,
	eEvent_Message			= 9,
//BLE
	eEvent_Call				= 10,
	eEvent_BTMessage        = 11,
	eEvent_TurnByTurnNav	= 12,
	eEvent_DeviceStatus		= 13,
// Alert
	eEvent_Alert			= 14,

	eEvent_DeviceVersion    = 15,
// Mirror
	eEvent_Image			= 16,
//status
	eEvent_Status0     		= 17,
	eEvent_Status1     		= 18,
// Custom
	eEvent_MultiFault		= 19,
	eEvent_Max				= 20,
}eClusterEvents_t;

typedef enum
{
	eGearmode_None     = 0,
	eGearmode_Neutral  = 1,
	eGearmode_Forward  = 2,
	eGearmode_Reverse  = 3,
	eGearmode_Parking  = 4,
	eGearmode_Invalid  = 5,
}eGearmode_t;

typedef enum
{
	eDriveMode_None     = 0,
	eDriveMode_Eco    	= 1,
	eDriveMode_Sport    = 2,
	eDriveMode_Power  	= 3,
	eDriveMode_Normal	= 4,
	eDriveMode_Invalid  = 5,
}eDriveMode_t;

typedef enum
{
#if(CLUSTER_KEYIGNITION_SUPPORTED == 1)
	eGpioKey0		= 12U, //evk ignition via GPIO
#else
	eGpioKey0		= 0U, //mapped to wakeup
#endif
	eGpioKey1       = 3U,
	eGpioKey2		= 4U,
	eGpioKey3       = 5U,
	eGpioKey4		= 6U,
	eGpioKey5       = 7U,
	eGpioKey6       = 8U,
	eGpioKey7       = 9U,
	eGpioKey8       = 10U,
	eGpioKey9       = 11U,
}eGPIOKey_t;

typedef enum
{
	eClusterKey1    = 3U,
	eClusterKey2    = 4U,
	eClusterKey3    = 5U,
}eClusterKey_t;

typedef enum
{
	eRtc_Init     = 1,
	eRtc_State    = 2,
	eRtc_Param    = 3,
	eRtc_Save     = 4,
	eRtc_Exit	  = 5,
}eRtcSet_t;

typedef enum
{
	eKey_Left     = 1,
	eKey_Ok   	  = 1 << 1, //UP
	eKey_Right    = 1 << 2,
	eKey_Down	  = 1 << 3,
}eSwitch_t;

typedef enum
{
	eSpeedInfo 	 	 =   1,
	eBrightnessInfo  =   2,
	eResetInfo       =   3,
	eProductInfo     =   4,
	eResetTrip       =   5,
	eSetOdo		     =   6,
	eResetTripA      =   7,
	eResetTripB      =   8,
	eSpeedUnit		 =	9,
} eSystemInfo_t;

typedef struct
{
	uint32_t iId;
	uint32_t iMode;
}sCanConfig_t;

typedef struct
{
	int32_t iCanId;
	uint32_t iDataLen;
	uint8_t iFormat; //0->Std, 1 ->Extended
	uint8_t sData[8];
}sCanMessage_t;

typedef struct
{
	bool bRefresh;
	bool bInput1;
	bool bInput2;
	bool bInput3;
	bool bInput4;
	bool bInput5;
	bool bInput6;
	bool bInput7;
	bool bInput8;
	bool bInput9;
	bool bInput10;
	bool bInput11;
}sHwInputs_t;

typedef struct
{
	uint32_t iTextCode;
}sTextInfo_t;

typedef struct
{
	uint8_t iVal;
	uint8_t iModeSel;
	uint8_t iModeVal;
}sNavSwitch_t;

typedef enum
{
	eNavSel_None = 0,
	eNavSel_Time = 1,
	eNavSel_SpeedUnit = 2,
	eNavSel_Odo = 3,
	eNavSel_TripA = 4,
	eNavSel_TripB = 5,
	eNavSel_Max
}eNavSelection_t;

typedef struct
{
	bool	 bOprHrEnable;
	uint8_t  iCount;
	uint8_t	 iWheelDrive;
	uint8_t	 iSoc;
	uint32_t iSpeed;
	uint32_t iRpm;
	uint32_t iOdo;
	uint32_t iTripA;
	uint32_t iTripB;
	uint32_t iMotTemp;
	uint32_t iOprHrs;
    uint32_t iCalOdo;
	uint32_t iSpeedUnit;	//0:KMPH, 1:MPH
}sMotorInfo_t;

typedef struct
{
	uint8_t  iBlink;
	uint32_t iDriveVal;
	uint32_t iGearVal;
	uint8_t iCount;
}sDriveMode_t;

typedef struct
{
	bool bTtcEnable;
	bool bChargeEnable;
	bool bLowSoc;
	uint8_t iCount;
	uint32_t iStatus;
	uint32_t iTime;

}sChargeInfo_t;

typedef enum
{
	eChargestate_Idle     	= 0,
	eChargestate_Charging 	= 1,
	eChargestate_Discharge  = 2,
	eChargestate_Complete	= 3,
	eChargestate_Connected	= 4,
	eChargestate_Failed		= 5,
}eChargestate_t;

typedef struct
{
	uint8_t  iCount;
	uint32_t iSoc;
	uint32_t iCurrent;
	uint32_t iVoltage;
	int32_t  iTemp;
	uint32_t iRange;
}sBatteryInfo_t;

typedef struct
{
	bool    bPM;
	bool 	bEnable;
	uint8_t iDayId;
	uint8_t iDay;
	uint8_t iMonth;
	uint8_t iYear;
	uint8_t iHour;
	uint8_t iMinute;
	uint8_t iSecond;
	uint8_t iIsEdit;
	uint8_t iState;
	uint8_t iFlag;
	uint8_t iBackFcn;

}sTimeInfo_t;

typedef enum
 {
	 eStateNone		=  -1,
	 eStateDay    	=  0,
	 eStateMonth 	=  1,
	 eStateYear  	=  2,
	 eStateHour 	=  3,
	 eStateMinute  	=  4,
	 eStateMeridiem =  5,
	 eStateMax 		=  6
 }eRtcState_t;

typedef struct
{
	int32_t iId;
	int32_t iStatus;
}sDeviceStatus_t;

typedef struct
{
    int32_t iEventId;
    int8_t sData[252];
}sMessage_t;

typedef struct
{
	QueueHandle_t 		QueueId;
}sController_t;

typedef struct
{
	uint32_t	iOdoVal;
	uint32_t 	iCurTripA;
	uint32_t 	iCurTripB;
	uint32_t  	iSpeedUnit;
}sClusterInfo_t;

typedef struct
{
	uint32_t  iSlNum;
	char  sVin[32];
}sDeviceInfo_t;

typedef struct
{
	bool  		bEnable;
	uint32_t  	iSwVersion;
	uint32_t  	iHwVersion;
	uint32_t  	iSlNum;
	char  		sSwVer[64];
	char  		sHwVer[32];
	char  		sSlNum[32];
	char      	sVin[32];
	char      	sDate[32];
} sSystemInfo_t;

typedef struct
{
	uint8_t   iStatus;
	uint8_t   iSocVal;
	uint32_t  iTime;
	uint8_t   iSasStatus;
	uint32_t  iSasTime;
}sChargeAlert_t;

typedef enum
{
	eAlert_CAN        		 = 0x100,
	eAlert_Rtc          	 = 0x101,
	eAlert_Switch    		 = 0x102,
	eAlert_Trip    			 = 0x103,
	eAlert_Custom  			 = 0x104,
}eAlertId_t;

typedef struct
{
	uint32_t     iId;
	uint32_t 	iCode;
	uint32_t    iCount;
}sAlertInfo_t;

typedef enum
{
	eCAN_Working			 = 0,
	eCAN_NoData         	 = 1,
	eCAN_Error         		 = 2,
	eCAN_SpeedDataTimeOut    = 3,
}eAlertCANCode_t;

typedef enum
{
	eRTC_Working			 = 0,
	eRTC_NotWorking          = 1,
	eRTC_NotSetOrBtryWeak    = 2,
	eRTC_VDETdataloss		 =3,
	eRTC_LowVoltage			 =4

}eAlertRTCCode_t;

typedef struct
{
	uint32_t iVal;
	uint32_t iId;
	uint32_t iRpm;
	bool bLVBattery;
}sAdc_t;

// customer specific definations
typedef enum
{
	eCANID_Frame1	=  0x341,	//Speed , Range
	eCANID_Frame2	=  0x342,	//SOC Charge OprnHrs
	eCANID_Frame3	=  0x343,	//Status faults buzzer
	eCANID_Frame4	=  0x344,	//Obd Msg
	eCANID_Frame5	=  0x345,	//Obd Msg
	eCANID_Frame6	=  0x346,	//Obd Msg
	eCANID_Frame7	=  0x347,	//ODO TRIP Msg send to VCU
	eCANID_Frame8	=  0x348,	//Switch press Msg send to VCU
	eCANID_Internal =  0x195,  // Internal

}eCANFrame_t;

typedef struct
{
	bool bEnable;
	char sMsg[64];
}sFault_t;

typedef struct
{
	uint32_t    iId;  //0 ->m;  1-> bat
	uint32_t 	iCode; //Error code
	uint32_t    iCount;
	char sMsg[64];
}sFaultInfo_t;

typedef struct
{
	bool bPowerTrain;
	bool bBatteryFault;
	bool bService;
	bool bPark;
	bool bHazard;
	bool bConnectivity;
	bool bInternet;
	bool bCellular;
	uint8_t iCount;
}sStatus0_t;

typedef enum
{
	eSelect_Time = 1,
	eSelect_SpeedUnit,
	eSelect_Odo,
	eSelect_TripA ,
	eSelect_TripB ,
} eSelectUnit_t;

typedef struct
{
	bool bEnable;
	uint32_t iLength;
	char Msg[13];
}sObdMsg_t;

typedef struct
{
	bool bHdrEnable;
	bool bMsgEnable;
	uint8_t iLen;
	char sHeader[16];
	char sMsg[16];
}sMultiFault_t;

#ifdef __cplusplus
}
#endif

#endif /* CLUSTER_COMMON_H_ */
